---
lang: en-US
title: Serial Killer
prev: Pyromaniac
next: Shroud
---

# <font color="#233fcc">🔪 <b>Serial Killer</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Serial Killer, your job is to simply murder everyone to win.
* Kill Cooldown
  * Set how long the Serial Killer needs to wait to Kill
* Can Vent
  * <font color=green>ON</font>: the Serial Killer has the ability to Vent
  * <font color=red>OFF</font>: the Serial Killer cannot vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Serial Killer has the same vision as an Impostor
  * <font color=red>OFF</font>: the Serial Killer has default vision
* Has Serial Killer Buddy
  * <font color=green>ON</font>: the Serial Killer gets a teammate on their team
    * Chance to Spawn
      * Set the chance that the Serial Killer will have to get a teammate
  * <font color=red>OFF</font>: the Serial Killer will be alone
* Reflect harmful interactions
  * <font color=green>ON</font>: the Serial Killer will be immune to any harmful interactions
  * <font color=red>OFF</font>: the Serial Killer will be impacted by any harmful interactions

> From: Town of Salem 1

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
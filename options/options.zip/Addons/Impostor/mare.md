---
lang: en-US
title: Mare
prev: Madmate
next: Mimic
---

# <font color=red>🐴 <b>Mare</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

You can only kill during Lights Out. Your Kill Cooldown is shorter during Lights Out. However, during Lights Out, your name will show up as Red for everyone.
* Max
  * Set the Maximum amount of Mares that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Mare
* Kill Cooldown During Lights Out
  * Set how long the Mare has to wait to kill

::: tip Fun Fact
Mare was originally a Role, but was later changed to an Impostor debuff addon.
:::

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
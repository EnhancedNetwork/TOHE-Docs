---
lang: en-US
title: Loyal
prev: Lazy
next: Lucky
---

# <font color=#b71556>🧑‍🤝‍🧑 <b>Loyal</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Loyal, you cannot be recruited by roles such as Jackal or Cultist.<br><br>
Cannot be assigned to <font color=#7f8c8d>Neutrals</font>.
* Max
  * Set the Maximum amount of Loyals that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Loyal
* <font color=red>Impostors</font> can become Loyal
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become Loyal
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become Loyal
* <font color=#8cffff>Crewmates</font> can become Loyal
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become Loyal
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become Loyal
* <font color=#ac42f2>Coven</font> can become Loyal
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> Idea: [beep6604](#) & Coding: [Tommy-XL](https://github.com/Tommy-XL)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
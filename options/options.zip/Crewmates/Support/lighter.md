---
lang: en-US
title: Lighter
prev: Keeper
next: Mechanic
---

# <font color="#eee5be">🔦 <b>Lighter</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Lighter, you can vent to increase your vision temporarily.<br>
You have increased vision both when lights are not out and when lights are out.<br>
Use this power to catch sneaky killers!
* Light Cooldown
  * Set the amount of time it takes for the Lighter to be able to use their Ability again
* Light Duration
  * Set the amount of time the Lighter will have increased vision
* Increased Vision
  * Set the amount of increased vision the Lighter will have
* Increased Vision During Lights Out
  * Set the amount of increased vision the Lighter will have when the lights are out
* Initial Ability Use Limit
  * Set the amount of Ability Uses a Lighter has at the start of the game
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Ability Uses a Lighter gains with each Task completed (0.1 increments)

> From: TOR & Coding: [Gurge44](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Noisemaker
prev: GuardianAngel
next: Scientist
---

# <font color="#8b00d9">📢 <b>Noisemaker</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Noisemaker, whenever you die you will make a noise, and a visual indicator of your death appears on the screen so the Crewmates can run to catch the person who killed you red-handed (even if it’s not Red).
* Max
  * Set the Maximum amount of Noisemaker that can be in a match
* Impostors can receive Alert
  * <font color=green>ON</font>: the Impostors can see the Alert of Noisemaker
  * <font color=red>OFF</font>: the Impostors cannot see the Alert of Noisemaker
* Alert Duration
  * Set how long the Alert of the Noisemaker lasts

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
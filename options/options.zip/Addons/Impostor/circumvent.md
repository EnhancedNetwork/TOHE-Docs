---
lang: en-US
title: Circumvent
prev: /options/Settings/Addons.html
next: Clumsy
---

# <font color="red">🪫 <b>Circumvent</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

As the Circumvent, you lose access to the vent ability.<br><br>
Only assigned to <font color=red>Impostors</font>.
* Max
  * Set the Maximum amount of Circumvents that can be in a match
* Spawn Chance
  * Set the chance of a Circumvent spawning

> Idea: [Rudyrant](#) & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
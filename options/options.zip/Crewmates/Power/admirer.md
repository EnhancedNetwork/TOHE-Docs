---
lang: en-US
title: Admirer
prev: /options/Settings/Crewmates.html
next: Captain
---

# <font color="#ee43c3">💞 <b>Admirer</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

As the Admirer, admire a player to make them crewmate aligned.<br>
They'll win with crewmates and not their original team.<br><br>
You can only do this once.
* Max
  * Set the Maximum amount of Admirers that can be in a match
* Admire Cooldown
  * Set how long the Admirer has to wait to use their Ability
* Know the roles of Admired players
  * <font color=green>ON</font>: the Admirer will know the role of the player they Admire
  * <font color=red>OFF</font>: the Admirer will not know the role of the player they Admire
* Skill Limit
  * Set how many times the Admirer can admire players

> From: Town of Salem II & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
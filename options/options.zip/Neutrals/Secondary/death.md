---
lang: en-US
title: Death
prev: SoulCollector
next: SoulCollector
---

# <font color=#644661>💀<b>Death</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

Once the Soul Collector has collected their needed souls, they become Death. Death kills everyone and wins if Death is not ejected by the end of the next meeting.<br>
A configurable amount of extra meeting time wi be given on the meeting Death transforms to have more discussion to find Death.<br>
<b>You are invincible and your presence is announced to everyone at the meeting after you transform.</b>

> From: Marg

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Legacy. A word many of us have heard.
Oxford dictionary defines a legacy as the long-lasting impact of particular events, actions, etc. that took place in the past, or of a person’s life. So.. How did I leave behind my legacy?
Chapter 1 No you don't
I was running from a dog that was barking so loud behind me while chasing... Run Run I cant stop I cant...
Oof! And I ran into a pole... Embarrassing
"HELP HIM"
"CALL 911"
Screams from all over the area..

Chapter 2 The Pot hole
"Ugh!" I wondered where I was..
Seems... Dirty (Yea it's a Sewer Sherlock)
"Ow" He cried out in pain as his back of the head was bleeding
"BLEEP" (Censored for not getting banned)
"Hello there" Said a voice
"Who.. Are you?"
"I am no one but everyone.. I can change shapes and I am the grim reaper" Now the voice became raspy..
"Oh no.. Is it time?"
"It's time"

Chapter 3 Why dont you give me this?
Now the grim reaper was waring a mask but anyone could see the sadness inside him.. How he walked in pain..
He was growing old (Yes even death dies)
He was.. Not liking this job at all
Definitely not what he signed up for

"I'm dead I know that but do you want to kill me?"
"No! I dont want to do anything I just want to close my eyes and rest until I see The flowers and trees of my garden" He cried out
"What if you.. Give me the scythe and I take over?"
"Eh sure" As he dropped the scythe to me and dropped dead himself dusting away into nothing but a cloak..
Death.. Died?
But a new death emerges...
Chapter 4 Death... Follows... You
And you know why he gave that to me?
Because He knew I could collect souls.. I was the son Of Hades.. A powerful demigod but I was still weak and could die.. But now? I'm invincible
Until someone else comes and comforts me pushing the daemons out of my body and throwing me into space

"AAH" I screamed as I picked up the scythe

And I remembered the line
"Now I am become Death, the destroyer of worlds."

The End
> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Puppeteer
prev: Miner
next: RiftMaker
---

# <font color="red">🎭 <b>Puppeteer</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

The Puppeteer can choose a target to kill for him. The target will kill anyone as long as they are not an Impostor. Puppeteers cannot kill Normally. Lazy guy will not do your bidding.
* Max
  * Set the Maximum amount of Puppeteers that can be in a match
* Puppet dies alongside victim
  * <font color=green>ON</font>: the person they targeted will suicide
  * <font color=red>OFF</font>: the person they targeted won't suicide

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Puppeteer had always excelled at crafting puppets; it was a passion that brought her immense joy. Yet, as a child, her peculiar interest subjected her to relentless teasing and ridicule. Frustrated by the constant mockery, she decided to take matters into her own hands.

Her plan was deceptively simple: she would turn everyone around her into her puppets. Whenever she passed someone, she would swiftly attach invisible strings, compelling them to act according to her whims—completely unaware of their manipulation.

And even if they did start to suspect something was amiss, well, all puppets eventually break after too much use, don’t they? Such a pity, isn’t it?
> Submitted by: Marg
</details>
---
lang: en-US
title: Bewilder
prev: Beartrap
next: Burst
---

# <font color=#c894f5>🤪 <b>Bewilder</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

The <font color=red>Impostors</font> won't be Bewilder. Bewilder may have a smaller/bigger vision depends on the host settings. When the Bewilder is killed, the murderer's vision will become as small/big as the Bewilder.
* Max
  * Set the Maximum amount of Bewilders that can be in a match.
* Spawn Chance
  * Set the percentage players have of getting Bewilder.
* Bewilder Vision
  * Set how far players with Bewilder can see.
* Killer gets Bewilder's Vision
  * <font color=green>ON</font>: The Bewilders Killer will gain the Bewilders Vision
  * <font color=red>OFF</font>: The Bewilders Killer will not gain the Bewilders Vision
  
> From: TOHR & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
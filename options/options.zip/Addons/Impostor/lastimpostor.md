---
lang: en-US
title: Last Impostor
prev: Clumsy
next: Madmate
---

# <font color=red>🤚 <b>Last Impostor</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

This effect is given to the last surviving Impostor. Reduces their kill cooldown.
* Kill Cooldown Reduction
  * Set the percentage that the Kill Cooldown of the Last Impostor gets reduced by

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
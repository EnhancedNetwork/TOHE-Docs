---
lang: en-US
title: Sleuth
prev: Silent
next: Spurt
---

# <font color="#843434">🕵️ <b>Sleuth</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Sleuth, you can gain info from dead bodies.<br><br>
Optionally, you may also gain the killer's role.<br><br>
Not assigned to Detective or Mortician.
* Max
  * Set the Maximum amount of Sleuths that can be in a match
* Spawn Chance
  * Set the chance of a Sleuth spawning
* <font color=red>Impostors</font> can become Sleuths
  * <font color=green>ON</font>: Impostors can become Sleuths
  * <font color=red>OFF</font>: Impostors cannot become Sleuths
* <font color=#7f8c8d>Neutrals</font> can become Sleuths
  * <font color=green>ON</font>: Neutrals can become Sleuths
  * <font color=red>OFF</font>: Neutrals cannot become Sleuths
* <font color=#8cffff>Crewmates</font> can become Sleuths
  * <font color=green>ON</font>: Crewmates can become Sleuths
  * <font color=red>OFF</font>: Crewmates cannot become Sleuths
* <font color=#ac42f2>Coven</font> can become Sleuths
  * <font color=green>ON</font>: Coven can become Sleuths
  * <font color=red>OFF</font>: Coven cannot become Sleuths
* Can find the role of the killer
  * <font color=green>ON</font>: the Sleuth can find the role of the killer
  * <font color=red>OFF</font>: the Sleuth cannot find the role of the killer
  
> From: ToUR & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons/)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
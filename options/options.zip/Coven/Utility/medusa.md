---
lang: en-US
title: Medusa
prev: Harvester
next: MoonDancer
---

# <font color="#9900cc">🐍 <b>Medusa</b></font> <Badge text="Utility" type="tip" vertical="middle"/>
---

The Medusa can use their kill button on players to mark them as Stoned. When the Medusa clicks the Shapeshift button, all Stoned players will be unable to move and will have reduced vision for a configurable amount of time.<br><b>With the Necronomicon, killed players will be unreportable.</b>
* Stone Cooldown
  * Set the Medusa’s Cooldown to kill or mark a player as Stoned
* Stone Duration
  * How long Stoned players are affected by stoning
* Stoned Vision
  * Vision of Stoned players while affected by stoning

> Original "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)<br>
> Reworked Idea & Coding: [Marg](https://github.com/MargaretTheFool)


<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
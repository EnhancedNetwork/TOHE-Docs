---
lang: en-US
title: Dreamweaver
prev: /options/Settings/Coven.html
next: Illusionist
---

# <font color="#8a68f5">💭 <b>Dreamweaver</b></font> <Badge text="Trickery" type="tip" vertical="middle"/>
---

The Dreamweaver can dreamweave a player. The dreamwoven players will be notified of this during the next meeting. If the Dreamweaver is not voted out, these players be driven to insomnia and will be unable to use their abilities, and their votes will not count until the
Dreamweaver dies.
With the Necronomicon, the Dreamweaver can double-click to kill.

* Ability Cooldown
  * Set how long the Dreamweaver has to place an Dreamweaver on a player
* Neutrals can be Dreamwoven
  * <font color=green>ON</font>: Neutrals can be Dreamwoven
  * <font color=red>OFF</font>: Neutrals cannot be Dreamwoven
* Impostors can be Dreamwoven
  * <font color=green>ON</font>: Impostors can be Dreamwoven
  * <font color=red>OFF</font>: Impostors cannot be Dreamwoven

> Idea & Coding: [Marg](https://github.com/MargaretTheFool)


<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
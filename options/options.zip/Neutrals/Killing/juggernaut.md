---
lang: en-US
title: Juggernaut
prev: Jackal
next: Pelican
---

# <font color="#a41342">💪 <b>Juggernaut</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Juggernaut, your kill cooldown decreases with each kill you make.<br><br>
Kill everyone to win.
* Default kill cooldown
  * Set the Juggernauts original Kill Cooldown
* Reduce kill cooldown by
  * Set how much the Juggernauts Kill Cooldown decreases per kill
* Minimum kill cooldown
  * Set the Lowest a Juggernauts Kill Cooldown can be
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Juggernaut has the same vision as an Impostor
  * <font color=red>OFF</font>: the Juggernaut has default vision
* Can Vent
  * <font color=green>ON</font>: the Juggernaut has the ability to Vent
  * <font color=red>OFF</font>: the Juggernaut cannot vent

> From: Town of Us Reactivated & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
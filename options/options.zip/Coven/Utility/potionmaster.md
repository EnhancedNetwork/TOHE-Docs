---
lang: en-US
title: Potion Master
prev: Necromancer
next: Sacrifist
---

# <font color="#663399">🍵 <b>Potion Master</b></font> <Badge text="Utility" type="tip" vertical="middle"/>
---

The Potion Master has two potions available for their use. The Reveal potion reveals a player's role. The Barrier potion places a shield on a player for one round, the player will not be notified of this unless they are Coven as well. Click the Shapeshift button to change potions.
<br><b>With the Necronomicon, the Potion Master can double-click their kill button to kill.</b>
* Kill Cooldown
  * Set how long the Potion Master needs to wait to use their Ability
* Maximum Reveals
  * Set the Amount of times the Potion Master can reveal
* Maximum Barriers
  * Set the Amount of times the Potion Master can barrier

> Original "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)<br>
> Reworked Idea & Coding: [Marg](https://github.com/MargaretTheFool)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
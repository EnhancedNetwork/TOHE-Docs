---
lang: en-US
title: Addict
prev: /options/Settings/Crewmates.html
next: Alchemist
---

# <font color="green">💊 <b>Addict</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

As the Addict, you have a suicide timer. When it expires you kill yourself.<br>
The timer is indicated by the vent cooldown. When the vent cooldown is at 0 seconds, you still have a short time to vent.<br>
If you don't make it you die, if you make it the suicide timer is reset.<br>
Also, after you are ventilated, no one can interact with you for a defined period of time.<br>
After this period is over, you are immobilized for another defined period of time and cannot report any bodies.
* Max
  * Set the Maximum amount of Addicts that can be in a match
* Vent Cooldown
  * Set how long an Addict has to wait to Vent
* Time Until Suicide
  * Set how long an Addict has until they Suicide
* Invulnerability Time
  * Set the time the Addict is invulnerable for after venting
* Time the Addict gets frozen in place after Invulnerability
  * Set the time the Addict is stuck in place for after invulnerability

> From: Idea & Coding: [papercut](https://github.com/lars-wu) 

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
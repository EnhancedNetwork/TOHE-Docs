---
lang: en-US
title: Tired
prev: Statue
next: Unlucky
---

# <font color=#9cdff0>🛌 <b>Tired</b></font> <Badge text="Harmful" type="tip" vertical="middle"/>
---

Whenever Tired kills (or uses kill ability on) someone, alternatively whenever they complete a task, they will temporarily get lower vision & lower speed.
* Max
  * Set the Maximum amount of Tired that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Tired
* Vision when Tired
  * Set the Vision multiplier that a Tired player will have
* Speed when Tired
  * Set the Speed multiplier that a Tired player will have
* Tired Duration
  * Set how long the Tired effects will last 
* <font color=red>Impostors</font> can become Tired
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Tired
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Tired
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Tired
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
  
> From: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
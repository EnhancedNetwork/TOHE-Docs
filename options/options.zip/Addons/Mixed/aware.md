---
lang: en-US
title: Aware
prev: Avenger
next: Bloodthirst
---

# <font color=#4B0082>➕ <b>Aware</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

As Aware, you will be notified in the next meeting if a revealing role interacts with you.
* Max
  * Set the Maximum amount of Aware that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Aware
* Impostors can become Aware
  * <font color=green>ON</font>: Impostors can become Aware
  * <font color=red>OFF</font>: Impostors cannot become Aware
* Crewmates can become Aware
  * <font color=green>ON</font>: Crewmates can become Aware
  * <font color=red>OFF</font>: Crewmates cannot become Aware
* Neutrals can become Aware
  * <font color=green>ON</font>: Neutrals can become Aware
  * <font color=red>OFF</font>: Neutrals cannot become Aware
* Coven can become Aware
  * <font color=green>ON</font>: Coven can become Aware
  * <font color=red>OFF</font>: Coven cannot become Aware
* Knows the role of player
  * <font color=green>ON</font>: Aware knows the role of the player
  * <font color=red>OFF</font>: Aware does not know the role of the player

> From: [Dailyhare](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
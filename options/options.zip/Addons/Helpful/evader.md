---
lang: en-US
title: Evader
prev: Eavesdropper
next: Flash
---

# <font color=#89cf2d>🏃 <b>Evader</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

When the Evader is voted out, there is chance the Evader will not be ejected. (Chance set by host.)

* Max
  * Set the Maximum amount of Evaders that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Evader
* <font color=red>Impostors</font> can become Evader
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Evader
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Evader
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Evader
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* Max Ability Uses
  * Set the maximum times that Evader can escape getting thrown out
* Chance to not be exiled
  * Set the percentage that Evader can escape getting thrown out

> Idea: [Lime](#) & Coding: [TommyXL](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
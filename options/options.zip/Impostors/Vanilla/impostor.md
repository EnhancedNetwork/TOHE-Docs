---
lang: en-US
title: Impostor
prev: /options/Settings/Impostors.html
next: Phantom
---

# <font color="red">🔪 <b>Impostor</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Impostor, your goal is to simply kill off the crewmates.<br>
You can sabotage and vent.
* Max
  * Set the Maximum amount of Impostors that can be in a match

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Knock Knock Ugh What Now? I thought as I walked towards My door only to notice a slight footstep behind me… “Aha!” I turned around and… No one? Interesting.. “Aha! There you are… Coward” “Please Don’t hurt me… Please I’ll do anything” Said the intruder… A con artist… Tsk Tsk Tsk “Leave… Now” The Intruder got up and started walking away when suddenly he turned around and took out his gun but I was faster as I shot through his chest… First time using the gun on a real Bean… This is… Life changing but now I need more blood… More violence… Time to go to The HQ Once In the HQ I saw the nearest target and… Killed? That’s fire! But after some time I got bored… Bored of the same old routine… by then New roles were introduced and my way of playing? Killing? Was Opted into the system I… Changed Among Us… I thought as I went on writing books and stories about the roles… As I got more mature I went on to write a good ton of LOREs Of the Other roles… Including mine… The Impostor In the end… In Conclusion… I will quote from one of my favourite songs… “Remember them” “Remember them When the fire begins to fade For the fallen and afraid We are not to let them die in vain” ‘Them’ Being the Other roles… Remember Me… I am The Infamous…. Odysseus
> Submitted by: champofchamps78
</details>
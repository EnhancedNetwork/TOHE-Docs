---
lang: en-US
title: Gravestone
prev: Ghoul
next: OIIAI
---

# <font color=#2ea8e7>🪦 <b>Gravestone</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

As the Gravestone, your role is revealed to everyone when you die.
* Max
  * Set the Maximum amount of Gravestones that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Gravestone
* <font color=red>Impostors</font> can have Gravestone
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can have Gravestone
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can have Gravestone
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can have Gravestone
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> From "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Saboteur
prev: QuickShooter
next: Sniper
---

# <font color="red">🔌 <b>Saboteur</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

Saboteur can only kill during Sabotages.
* Max
  * Set the Maximum amount of Saboteurs that can be in a match
* Kill Cooldown
  * Set how long the Saboteur needs to wait to perform a kill

::: danger Fun Fact

This role was formerly a Hidden Role under [Inhibitor](Inhibitor)
:::

> Idea: [Pyro](#) & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Saboteur's Reckoning

Once upon a time, there were two impostors who were the best of friends: The Saboteur and The Inhibitor. They were notorious for their antics, working together for The Mastermind, and although The Saboteur loved to play pranks and cause chaos for The Inhibitor, they cared deeply for each other. Nothing could tear them apart—until one fateful day.

While driving to work, The Inhibitor decided to prank The Saboteur for the first time by tampering with his car. However, things took a turn for the worse when the car unexpectedly hit a mysterious figure.

The Inhibitor: “Oh no! I’m so sorry, sir! The car was sabotaged!”

Mysterious Figure: “BOTH OF YOU! You’ve caused enough trouble in this town. Now, what’s your punishment?”

Terrified, they both sped away from the scene, shaken by the encounter. After that incident, The Saboteur found himself unable to kill. Every attempt ended in failure, leaving him anxious and frustrated.

The Saboteur: “I don’t get it! This is the fifth time I’ve failed. Do you think the punishment that weird guy mentioned is real?”

The Inhibitor: “Maybe it is. This all started after that incident.”

The Saboteur: “I didn’t even sabotage my own car! Someone else must have done it, and when I find out who, they’ll regret it!”

As The Saboteur browsed the newspaper, he came across a shocking headline.

The Saboteur: “WHAT?! Did you really sabotage my car?!”

The Inhibitor: “It was supposed to be a little revenge!”

The Saboteur: “A LITTLE? I CAN’T KILL ANYMORE BECAUSE OF YOU!”

Their argument escalated until The Mastermind intervened, pulling them apart.

The Mastermind: “Enough! I’ve figured out a way for you to kill again. You can use sabotage to your advantage. Push people into the reactor, electrify them with the lights, and use the comms to create chaos.”

Now, when a sabotage occurs, it’s crucial to fix it quickly. The Saboteur can’t strike while the repairs are in progress. And who is this cunning imposter? None other than THE SABOTEUR.
> Submitted by: burgerman7286
</details>
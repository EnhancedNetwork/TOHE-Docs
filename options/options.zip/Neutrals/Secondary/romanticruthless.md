---
lang: en-US
title: Ruthless Romantic
prev: RomanticVengeful
next: Romantic
---

# <font color="#d2691e">💕 <b>Ruthless Romantic</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

You change your roles from Romantic if your partner (A neutral killer) is killed. As Ruthless Romantic, you win if you kill everyone and be the last one standing. If you win your dead partner also wins with you.
* Ruthless Romantic Kill Cooldown
  * Set the cooldown for the Ruthless Romantic's kill
* Ruthless Romantic Can Vent
  * <font color=green>ON</font>: the Ruthless Romantic can vent
  * <font color=red>OFF</font>: the Ruthless Romantic cannot vent

> From: Stellar Roles & Coding: [Gurge44](#) & [ryuk](#)
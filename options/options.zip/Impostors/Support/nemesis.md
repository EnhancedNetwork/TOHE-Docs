---
lang: en-US
title: Nemesis
prev: Morphling
next: TimeThief
---

# <font color="red">🦹 <b>Nemesis</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Nemesis you can revenge some players.

* Kill Cooldown
  * Set how long the nemesis has to wait to kill
* Max number of revenges
  * Set the Maximum amount of revenges (kills) the Nemesis can make
* Use Legacy Version
  * <font color=green>ON</font>: Legacy Nemesis will be used
  * <font color=red>OFF</font>: Legacy Nemesis will not be used

> From: TOH (Mafia) & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The nemesis was the only impostor who didn’t kill for fun but for revenge..

Chapter 1 Why ☹
The nemesis was only 5 when he met the Mastermind.. but soon when the nemesis turned 12 the Mastermind was shifted from Mira To Polus due to his father's career change...

This left a deep mark on the nemesis.. one of the only times the nemesis felt vulnerable.. He lost his oldest and only friend.

Chapter 2 Sir, No
As he needed to give the required monthly Impostor trials... He got selected? When he did not even want to… He knew how hurting and sad it is for someone friend to die so he did not want to kill..
So he went up to Mr. Sloth and DEMANDED he was reduced to crewmate… But with no fruitful result
 
I guess this is his life now..

Chapter 3 Hi
Anyone who interacted with him got the cold shoulder except for the Mastermind who was back here! This was Mind boggling he met his oldest friend again.. Crazy. Now he would talk and talk about his life how much he missed hi-
New Game Starting In 3..2..1

Chapter 4 I WONT kill
The Nemesis told Mastermind who was his Impostor buddy.. That he will NOT kill no matter what..
And Mastermind assured him that it was understandable… and went on killing but Very unfortunately… The Mastermind was stabbed by a dagger by the Juggernaut…
“NOO!” Cried the Nemesis as he fell down to his knees crying on top of his best friends body..

Wiping away the tears the Nemesis swore he would get revenge…

Chapter 5 You are Dead
The nemesis picked up the gun from his friends dead body and went on to find out the juggernaut.. and Brutally stabbed him… He went on KILLING until… People saw him killing in pure rage and voted him out but the crew still wasn’t safe..

Hades got the Nemesis and supported him.. giving him the ability to Kill while beyond the grave.. But to make it fair he could only kill twice or thrice…
The Master Mind and Nemesis finally back together
And Kill he did
The End
> Submitted by: champofchamps78
</details>
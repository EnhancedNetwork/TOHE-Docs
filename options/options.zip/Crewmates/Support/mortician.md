---
lang: en-US
title: Mortician
prev: Merchant
next: Observer
---

# <font color="#333c49">🪦 <b>Mortician</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

The Mortician will see arrows pointing to all dead bodies, and if the mortician reports a body, they will know the last player the target was in contact with.
* Max
  * Set the Maximum amount of Morticians that can be in a match
* Has Arrows pointing toward bodies
  * <font color=green>ON</font>: the Mortician will see arrows pointing to all dead bodies
  * <font color=red>OFF</font>: the Mortician will not see arrows pointing to all dead bodies

> From: [草暖](https://b23.tv/kTnVK2c) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
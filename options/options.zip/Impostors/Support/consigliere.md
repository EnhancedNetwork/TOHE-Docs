---
lang: en-US
title: Consigliere
prev: Cleaner
next: DoubleAgent
---

# <font color="red">👨‍⚖️ <b>Consigliere</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Consigiliere, you can reveal the roles of other players using your kill button.<br>
Single click: Reveal role<br>
Double click: Kill<br>
If you run out of reveal uses, your kill button functions normally.
* Max
  * Set the Maximum amount of Consiglieres that can be in a match
* Kill Cooldown
  * Set the Consigiliere’s Kill Cooldown
* Maximum Reveals
  * Set the Maximum amount of times the Consigliere can reveal a role

> From: TOHY

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Why Me? As The Consigliere went on and became older all of his peers and teachers knew he was incapable of achieving anything in life except for wasting his time everyday and the best career for him was a door to door advertiser… Chapter 1 Sir.. Please “I have a family” Said the lying salesman to the wealthy Monarch with no use.. he got tossed out of the palace and sadly… This wasn’t the only time Days went on as no one took the free food samples and he was fired from the company he worked for… What a shame… Chapter 2 Final Chance Mr. Sloth being the sympathetic person he is (except to his game developers) felt bad for the salesman and… gave him the chance to became an Impostor… The more kills he would have the more money Mr. Sloth would give him and… This was going to change his whole life Chapter 3 Try now buy Later Going around HQ the Salesman had an Idea.. what if he gave free remote Med Scans as a decoy so he could get information about the beans and… Sell a few products too :D Doing this… Many actually eagerly accepted when they heard Free but there’s nothing free in life… Chapter 4 I.. Know.. Who.. You.. Are After careful research of the specimens, Body weight, Height, Hands, Aura of the Bean the salesman knew it was a harmful Neutral.. The shaman so next meeting he guessed him… This went on and on until the crewmates started to understand the tactics… Even though they agreed eagerly due to the word “Free” but.. Chapter 5 Flaws As It takes time to scan the beans they just started to run away from the salesman and as the salesman was picking up such a heavy machine he was very tired and had insanely less vision… So in the end this idea flawed and he was finally… Caught as he had to kill a person who denied his free trials… Well, Well, Well… What a pity The Sad and Gruesome end for our Protagonist
> Submitted by: champofchamps78
</details>
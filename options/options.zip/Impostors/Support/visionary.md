---
lang: en-US
title: Visionary
prev: Vindicator
next: /options/Settings/Impostors.html
---

# <font color="red">🔭 <b>Visionary</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Visionary, you see the alignments of living players during a meeting.<br>
The following info will be displayed on the player:<br>
\- The Red star indicates the Impostors.<br>
\- The Cyan star indicates the Crewmates.<br>
\- The Gray star indicates the Neutrals.
* Max
  * Set the Maximum amount of Visionarys that can be in a match

::: danger Fun Fact
Visionary was originally called Parasight and was an Add-on for Impostors.
:::

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue "Ah! Damn it" said the visionary as he ran into a wall Chapter 1 The... Accident The Visionary was doing tasks and minding his own business when- A rogue Impostor came out and STABBED the visionary in his eye... "Ah... How am I alive" Although blinded the visionary now knew that he had a new purose in life... A holy purpose due to which Even gods protected him Chapter 2 I feel bad now Zeus watching from his tower knew the visionary was a fun guy and he used to watch him all the time, He loved the visionary's Jokes and well... Gods Repay themselves.. Guilty with using the visionary for his own entertainment Zeus went on and shielded him EVERYWHERE except- The eys Chapter 3 Here Kid Take this Zeus was RAGING around his castle replaying the visionary's accident in his mind while pacing around... He had failed But Zeus is- Prideful And he went on Giving the Visionary Insane Vision (Author Here Sorry for the pun) and well this went horribly- Again Chapter 4 Thank you... Strange Man The visionary had a... Vision (Sorry) And well.... Zeus likes being Insane I guess "A vision Of what is to come, cannot be outrun Can only be dealt with right here and now" As The visionary tried reaching out... He fell and blacked out Chapter 5 I... See... Everything The Visionary could... See? And he could see roles? This... Changes everything. Going around the map bewildered by his new eyes the visionary saw his killer How? Because he recognized his voice and the killer was... A knight "A knight... A crewmate?! AFTER ALL I HAVE DONE FOR THEM?" He now knew... He HAD to Kill... He became... A killer powered by anger and strengthened by His knowledge of everyone roles "Thanks Strange Man" he muttered again and went on killing The End? Of course not! Later on the visionary became a pacifist after a long streak of killing and became... The all knowing... All Seeing... God
> Submitted by: champofchamps78
</details>
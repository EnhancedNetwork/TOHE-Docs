---
lang: en-US
title: Time Master
prev: TimeManager
next: Ventguard
---

# <font color="#44baff">⏳ <b>Time Master</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Time Master, use the vents to mark everyone's position.<br>
When using the ability again, every alive player will be rewinded back to the marked positions.<br><br>
During the ability duration, the Time Master gains a time shield that protects them from death.
* Max
  * Set the Maximum amount of Time Masters that can be in a match
* Time Shield Cooldown
  * Set how long the Time Master has to wait to use their Ability
* Time Shield Duration
  * Set how long the Time Master can stay protected for
* (Initial) Max number of Ability Uses
  * Set the amount of Ability Uses a Time Master has at the start of the game
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Ability Uses a Time Master gains with each Task completed (0.1 increments)

> From: TOHEX

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
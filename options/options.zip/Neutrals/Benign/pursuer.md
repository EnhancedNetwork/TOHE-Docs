---
lang: en-US
title: Pursuer
prev: Provocateur
next: Revenant
---

# <font color="#617218">😘 <b>Pursuer</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

Stay alive to win, but you can make people suicide when they attempt to kill.
* Max
  * Set the Maximum amount of Pursuers that can be in a match
* Ability cooldown
  * Set how long the Pursuer needs to wait to use their Ability
* Max number of uses
  * Set the maximum times the Pursuer can use their Ability

> From: TheOtherRolesAU + "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Always pursuing a dream I have a dream I wish to Tell Anyway Back to the Story the pursuers dream was...Not normal i'm Not Sure If we can even call it a dream because it was simply making people misfire and die...weird well lucky for the pursuer their parents owned a weapon Factory selling guns to crewmates impostors and neutrals one day puruser thought they would be funny messed with lots of guns and snuck on polus the puruser was good at talking even convinced the impostor to buy a new gun...next day he tried to shoot the Snitch but got blown into Bits the puruser thought it's Hilarious and continued selling these Type of guns watching people explode until only one two Players were left the sheriff and the Impostor(He killed oiiai and forgot His role used to be a vindicator) and they both had guns from the pursuer the one who shoots First loses they chased eachother all around the map the First one to shoot was...they both Shot at the Same time and died the game broke causing No one to win and it's revealed to the puruser that this is Just a Simulation her entire reality Just got shattered she knew Secrets Not even the blackmailer knows...she knew everything but anyway this is the end for now No one wins due to no factions being alive except a neutral that cant win alone Pursuer got to Finish their dream but it came with a great cost. The end
> Submitted by: Kira (Vampire)
</details>
---
lang: en-US
title: Crusader
prev: Bodyguard
next: Deceiver
---

# <font color="#c65c39">🤺 <b>Crusader</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Crusader, use your kill button to crusade a player.<br>
If that player gets attacked, you'll kill the attacker.
* Max
  * Set the Maximum amount of Crusaders that can be in a match
* Crusade Cooldown
  * Set how long the Crusader has to wait before using their ability
* Maximum Crusades
  * Set the maximum amount of crusades the Crusader can use in a game

> From: Project Lotus

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
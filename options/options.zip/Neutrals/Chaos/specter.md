---
lang: en-US
title: Specter
prev: Solsticer
next: Terrorist
---

# <font color="#662962">👻 <b>Specter</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

Complete all of your Tasks, and Die in any order to win with the winning team. (Can steal the Win and win Solo depending on Settings) 
However you cannot win if you are alive at the end of the game, or haven't completed all of your Tasks.
* Max
  * Set the Maximum amount of Specters that can be in a match
* Can Vent
  * <font color=green>ON</font>: the Specter can Vent while they are alive
  * <font color=red>OFF</font>: the Specter cannot Vent while they are alive
* Snatches Victory
  * <font color=green>ON</font>: The Specter may steal the win if they have completed all of their Tasks and have died
  * <font color=red>OFF</font>: The Specter will win normally if they have completed all of their Tasks and have died
* Can Guess in Guesser Mode
  * <font color=green>ON</font>: the Specter can Guess people in Guesser Mode (easy way to suicide if done Tasks/to do Tasks quicker too)
  * <font color=red>OFF</font>: the Specter cannot Guess, even when Guesser Mode is enabled
* Override Specter’s Tasks
  * <font color=green>ON</font>: you can set a different amount of Tasks that a Specter needs to do over the amount a normal <font color=#8cffff>Crewmate</font> has to do
  * <font color=red>OFF</font>: the Specter does the same amount of Tasks as anyone else
    * Specter has Common Tasks
      * Set if the Specter has Common Tasks
    * Amount of Long Tasks for Specter
      * Set the amount of Long Tasks the Specter will receive
    * Amount of Short Tasks for Specter
      * Set the amount of Short Tasks the Specter will receive

> Idea: [Pyro](#) & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“Life is amazing if you greet it with open arms”
 
She only have one missio

 and she will do anything to fulfill it, they say when a ghost focus on a goal well enough they could come back to finished so they’re soul could rest in peace, well she was one of the first ones, they were just a regular crewmate, had a great job, had an amazing  life, a lot of friends and a loving husband, too bad she wouldn’t ever seen him again
 
She was an amazing crewmate and was promoted to be an engineer meaning she could use the vents for her advantage and it really did, because she was highly known to able to finished her task at a high speed, most people sometimes don’t like her for just finishing her task and doing semi stupid decisions so she could go back into doing it
 
But it was gonna be her 1000th streak so she pulled every trick in her book, all of the tips and shortcuts to finished it but because of this she missed some important evidence and information for the impostors like everyone the goes in electrical dies, she didn’t care she had 3 tasks there and will do anything to do it, then she came face to face with the impostor and while doing her task she got stabbed in the back, she was so close she can’t die now she must do the task, and she did before she died she completed it and with one more smile she finally died and rest in peace
 
The impostors won but while looking at the results of the mission, something was off it says impostors won but at the bottom it also says +Specter, know one knew who was the Specter but all they knew she apparently also won
 
Months later
 
Sci: Are you ready for this, we don’t really know if this would work
 
ALT: YEAH, LET ER RIP, or I could say let me rip
3, 2, 1
 
Spec: Wait what, what happened why is there a dead guy beside me
Sci: Greetings Specter don’t worry about him, we could used someone with your determination

> Submitted by: Pikmin 6(No.1TrickJestershipper)
</details>
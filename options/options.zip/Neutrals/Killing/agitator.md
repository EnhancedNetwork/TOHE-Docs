---
lang: en-US
title: Agitator
prev: /options/Settings/Neutrals.html
next: Arsonist
---

# <font color="#F4A460">💣 <b>Agitator</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Agitator, your premise is essentially Hot Potato.<br><br>
Use your kill button on a player to pass the bomb.<br>
This can only be done once per round.<br><br>
The player who receives the bomb will be notified when receiving said bomb, in which they need to pass it to another player by getting near a player.<br><br>
When a meeting is called, the player with the bomb dies.<br><br>
If trying to pass to Pestilence or a Veteran on alert, the bombed player dies instead.<br>
Optionally, the Agitator cannot receive the bomb.
* Max
  * Set the Maximum amount of Agitators that can be in a match
* Agitator Bomb Cooldown
  * Set how long an Agitator needs to wait to pass the bomb
* Bomb Pass Cooldown
  * Set how long a player needs to wait to pass the bomb
* Bomb Explode Cooldown
  * Set how long it takes for the bomb to explode
* Agitator can get bomb
  * <font color=green>ON</font>: the Agitator can have the bomb passed to them
  * <font color=red>OFF</font>: the Agitator cannot have the bomb passed to them

> From: TOH:TOR & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
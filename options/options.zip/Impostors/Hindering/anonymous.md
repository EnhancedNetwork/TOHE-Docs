---
lang: en-US
title: Anonymous
prev: /options/Settings/Impostors.html
next: Dazzler
---

# <font color="red">🕵️ <b>Anonymous</b></font> <Badge text="Hindering" type="tip" vertical="middle"/>
---

The Anonymous can Shapeshift into people to make them automatically report any dead body the Anonymous killed, or if no dead body, they will report themself.<br>
* Notes: 
  * Hacking ignores whether a body can be reported
  * Hacking Lazy Guy will do nothing<br><br>
* Max
  * Set the Maximum amount of Anonymous’ that can be in a match
* Kill Cooldown
  * Set how long the Anonymous needs to wait to use their Ability/Kill
* Ability Use Count
  * Set how many times the Anonymous can use his Ability

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The Lazy guy was very well.. Lazy so to help him get active Mr, Sloth Promoted him and well This would be interesting to say at least Chapter 1 Hi... The lazy guy felt very... Awkward among the Impostors everyone was so active and on the job all the time goin on and on killing people storing trophies of kills and having fun doing all this "Couldnt be me even if Hell freezes over" Now he went on and greeted the vindicator and the Eraser...
Nothing to do with story lol
Chapter 2 Hello Mr. Mayor Now at city hall he greeted the mayor and talked for hours honestly they became the bestest of friends and then Mr. Mayor revealed a... Secret of his The portable emergency Button... Chapter 3 Im sorry Now killing was his main quality, He could not be bothered at all with the screams of his victims but running away from bodies was entirely different He wont do that... Never! But what if he did not need to? He went over to the drunk mayor and Stabby Stabby Stabbed him Chapter 4 Help Now Genetically the button could only be used by Mr. Mayor but... Mad scientist comes in the story The Mad scientist went on and surgically removed the button and changed its locks but this made it malfunction rather than venting and pressing the button it would need even more warmth than the vents to activate The Warmth of an egg while shapeshifting?! Chapter 5 Self Report fr Now the lazy guy killed and immediately shapeshifted making the seer think this is a bait kill because instant report not knowing what the Lazy guy had done.. Over the years The lazy guy kept on doing this and winning but being named "Impostor" Was not funny "What about hmm Evil Hacker" "Already Taken" "Bard?" "That too" Anonymous" "Done done and done!" Wow... So many names already taken I guess this is another tale in the universe of among us The end? Thought the author, not knowing how to continue..
> Submitted by: champofchamps78
</details>
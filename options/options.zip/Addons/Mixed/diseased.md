---
lang: en-US
title: Diseased
prev: Bloodthirst
next: Ghoul
---

# <font color=#aaaaaa>🦠 <b>Diseased</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

When someone tries to use kill button on you, their cooldown will be increased by configurable amount of time.
* Max
  * Set the Maximum amount of Diseased that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Diseased
* <font color=red>Impostors</font> can become Diseased
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Diseased
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Diseased
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Diseased
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* Increase the cooldown by
  * Set how much the cooldown will be increased by
* Cooldown returns to normal after a meeting
  * <font color=green>ON</font>: Killer's cooldown will return to normal after a meeting 
  * <font color=red>OFF</font>: Killer's cooldown will not return to normal after a meeting

> From: TOH:TOR & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
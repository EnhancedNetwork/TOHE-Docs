---
lang: en-US
title: Veteran
prev: Sheriff
next: Vigilante
---

# <font color="#a77738">🤺 <b>Veteran</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

The Veteran can Alert by Venting. If someone tries to Interact with the Veteran, the Veteran will retaliate and Kill the player Interacting with it.
* Max
  * Set the Maximum amount of Veterans that can be in a match
* Alert Cooldown
  * Set the amount of time Veterans need to wait to Alert
* Alert Duration
  * Set how long Veterans stay Alerted for
* Max number of Alerts
  * Set how many times a Veteran can Alert
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Alerts a Veteran gains with each Task completed (0.1 increments)

> From: TOU & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Spiritualist
prev: Snitch
next: Spy
---

# <font color="#669999">🧘 <b>Spiritualist</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

You get an arrow pointing to the ghost of the body that was reported in the last meeting. If the ghost is Good, you will be lead to a Killer. If the ghost is Bad, you will be lead to a Crewmate.
* Max
  * Set the Maximum amount of Spiritualists that can be in a match
* Ghost arrow interval
  * Set how long a Spiritualist has to wait to see a Ghost arrow pop-up
* Ghost arrow duration
  * Set how long a Spiritualist's Ghost arrow pops-up for

> From: Idea & Coding: [papercut](https://github.com/lars-wu)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
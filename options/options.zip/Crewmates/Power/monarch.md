---
lang: en-US
title: Monarch
prev: Mayor
next: Overseer
---

# <font color="#ffa500">👑 <b>Monarch</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

As the Monarch, you can knight players to give them an extra vote.

You cannot knight someone who already has extra votes.

Knighted players appear with a golden name.
If a knighted player is alive, the Monarch cannot be guessed or exhiled.

* Max
  * Set the Maximum amount of Monarchs that can be in a match
* Knight Cooldown
  * Set how a Monarch needs to wait to Knight players
* Maximum Knights
  * Set the Max amount of players that the Monarch can make Knighted

> From: Town of Salem 2 & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
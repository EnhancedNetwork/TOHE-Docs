---
lang: en-US
title: Vengeful Romantic
prev: Romantic
next: Romantic
---

# <font color="#8b0000">💕 <b>Vengeful Romantic</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

You change your roles from Romantic if your partner (A crew or non neutral killer) is killed. As a Vengeful Romantic, Your goal is to avenge your partner, which means you have to kill the killer of your partner. If you succeed to do so, the Both you and your partner win with the winning team at the end. If you try to kill someone other than your partner's killer, then the you will die by misfire.
* Vengeful Romantic Kill Cooldown
  * Set the cooldown for the Vengeful Romantic's kill
* Vengeful Romantic Can Vent
  * <font color=green>ON</font>: the Vengeful Romantic can vent
  * <font color=red>OFF</font>: the Vengeful Romantic cannot vent

> From: Stellar Roles & Coding: [Gurge44](#) & [ryuk](#)
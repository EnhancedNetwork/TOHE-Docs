---
lang: en-US
title: Dictator
prev: Copycat
next: Guardian
---

# <font color="#df9b00">🫵 <b>Dictator</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

When the Dictator votes someone, the Meeting will ignore everyone else's votes and end the meeting. The moment the Meeting ends after the Dictator votes someone out, the Dictator will Suicide.
* Max
  * Set the Maximum amount of Dictators that can be in a match

> From: TOHTOR

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Guess Master
prev: Doctor
next: LazyGuy
---

# <font color="#e9c404">❔ <b>Guess Master</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

As the Guess Master, you will receive information about every attempted guess made during a meeting. You will be informed about what role the guesser tried to guess, and you will also be notified in case of a misguess.
* Max
  * Set the Maximum amount of Guess Masters that can be in a match

> Idea: [spong](#) & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
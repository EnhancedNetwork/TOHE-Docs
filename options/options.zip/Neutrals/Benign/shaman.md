---
lang: en-US
title: Shaman
prev: SchrodingersCat
next: Taskinator
---

# <font color="#50c878">🧙 <b>Shaman</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As Shaman you can use your kill button to select voodoo doll once every round. All the interactions with you using kill button will be deflected to the voodoo doll and the voodoo doll will destroy.<br><br>
Since Witch uses magic too, the effect of the voodoo doll will be nullified (voodoo doll won't be destroyed though) and will take place on Shaman itself.<br><br>
If you survive till the end, you win with the winning team.
* Max
  * Set the Maximum amount of Shamans that can be in a match
* Voodoo Cooldown
  * Set the cooldown of the voodoo doll 

> Idea & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The spirits Favorite
The Shaman used to be a doctor on the skeld a very good one too saved countless of lives cured diseases everyone Loved him even the spirits the Shaman believed in Spiritual power and claimed the spirits guided him and helped him cure the people but now that would be a short Happy ending for the doc...well the Story is Just starting The Crash Now one day the impostors called reactor...and no one fixed it because everyone was thinking "it's getting fixed anyway no need for me to come" but that was not the case no one came reactor broke down...and they also sabotaged the engines the communicaton everything Just great everything goes boom the ship Crashlands on fungle With everyone spread all across a unknown planet it's Dangerous everyone was scared everyone except the Shaman He knew exactly what plants to eat and which are good for healing He found the injured Snitch and healed him with some special herbs blessed by the spirits...the sheriff seeing this accused the Shaman of being a witch and shot him in the head but...the Snitch dropped dead instead His head blowing Off the Shamans Trust shattered and also gaining the ability to deflect attacks is scared now....the Reverie seeing this Kills the sheriff and asks the Shaman If everything is alright He Just nods A week later Most of the survivors made Camp and they all knew one Thing "It's find the impostors then escape or die" The Shaman didnt Trust Anyone each knight before He went to bed he prayed and made the spirits deflect the Attack to one person one night the shield...also called Voodoo Doll was the Task Manager then at morning Shaman wakes up finding a hammer next to His head and the Task Managers head smashed into pieces He was now Sure He can deflect attacks...and also that the Crew cant win so he decided to work together with the impostors Picking a Voodoo doll then deflecting the Attack leaving a kill without a trace this continued and the impostors won...and the Shaman joined them but He could have also joined the Crew why? Survival is what the Shaman cares about Most Not who he survives with The end
> Submitted by: Kira (Vampire)
</details>
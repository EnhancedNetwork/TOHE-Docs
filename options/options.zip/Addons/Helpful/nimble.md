---
lang: en-US
title: Nimble
prev: Necroview
next: Overclocked
---

# <font color=#fffaa6>🔋 <b>Nimble</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Nimble, you gain access to the vent ability.<br><br>
Only assigned to <font color=#8cffff>Crewmates</font> that have an <font color=red>Impostor</font> basis.
* Max
  * Set the Maximum amount of Nimbles that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Nimble

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons/)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Silent
prev: Seer
next: Sleuth
---

# <font color="#9aa6cb">😶 <b>Silent</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Silent, your vote icon won't appear on the result screen.<br>
So nobody knows who you voted for.
* Max
  * Set the Maximum amount of Silents that can be in a match
* Spawn Chance
  * Set the chance of a Silent spawning
* <font color=red>Impostors</font> can become Silent
  * <font color=green>ON</font>: Impostors can become Silent
  * <font color=red>OFF</font>: Impostors cannot become Silent
* <font color=#8cffff>Crewmates</font> can become Silent
  * <font color=green>ON</font>: Crewmates can become Silent
  * <font color=red>OFF</font>: Crewmates cannot become Silent
* <font color=#7f8c8d>Neutrals</font> can become Silent
  * <font color=green>ON</font>: Neutrals can become Silent
  * <font color=red>OFF</font>: Neutrals cannot become Silent
* <font color=#ac42f2>Coven</font> can become Silent
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become Silent
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become Silent
  
> Idea & Coding: [NikoCat223](https://github.com/NikoCat233)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
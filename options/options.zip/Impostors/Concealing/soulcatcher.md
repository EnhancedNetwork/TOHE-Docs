---
lang: en-US
title: Soul Catcher
prev: Shapemaster
next: Swooper
---

# <font color="red">👻 <b>Soul Catcher</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

The Soul Catcher will Swap places with their Shapeshift Target as long as they aren’t in an abnormal state. (Pelican stomach, Vent, Dead)
* Max
  * Set the Maximum amount of Soul Catchers that can be in a match
* Shapeshift Duration
  * Set how long the Soul Catcher stays Shapeshifted for
* Shapeshift Cooldown
  * Set long the Soul Catcher needs to wait to Shapeshift

> From: [法师](https://space.bilibili.com/511107305) & Coding: [NCSIMON](https://github.com/NCSIMON)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Soul Catcher was, at first, a sheriff. He knew all about crimes and framing people. One day, when he returned home, he saw a note, and on it was written: "We have taken your family. If you want to save them, you have to become evil, dude." He was shocked, afraid, sad, and some might even say bewildered. He knew family was more important than morals, so what did he do?

He threw the morals out the window.

He is now an Impostor—one quite smart, too.

Before giving up his career for the safety of his crew, he was a scientist gifted with teleportation and swapping.

He started experimenting with subjects, and soon enough, he could swap himself on the map with another player. Props to him, I guess.

Now, how could he use this power? For evil, of course. This isn't some Disney tale; we have to have some bloodshed and people killed, don’t we?

The Soul Catcher would kill a crew member and then swap himself with another crew, thus framing every single one.

One day, he was caught. Unfortunately, the target crew was with a friend (more than friends, I’d say), so he knew what he had to do.

He went on a rampage, using all his energy to kill the friend. In doing so, his vision decreased, and he could no longer perform any other actions. Thus, the Killing Machine was invented! But that story is for another time.
> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Detective
prev: Deputy
next: Enigma
---

# <font color="#7160e8">🕵️‍♂️ <b>Detective</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

After the Detective reports the body. They will receive a clue message, which will tell the Detective what the role of the body was.
* Max
  * Set the Maximum amount of Detectives that can be in a match.
* Can find the killer’s role
  * <font color=green>ON</font>: the Detective can find out the Role of the Killer of any body the Detective reports
  * <font color=red>OFF</font>: the Detective will not be able to find the exact killer’s role

> From: TOHR & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
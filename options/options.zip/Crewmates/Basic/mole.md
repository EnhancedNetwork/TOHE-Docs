---
lang: en-US
title: Mole
prev: Mini
next: Randomizer
---

# <font color="#2a1e1c">⛏️ <b>Mole</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

As the Mole, when you vent, you stay in the vent for 1 second. When you come out of the vent, you will spawn near a random vent in the map (Except the one you just used).
* Max
  * Set the Maximum amount of Moles that can be in a match
* Dig cooldown
  * Set how long the Mole has to wait to use their Ability

> Idea: [thewhiskas27](#) & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Innocent
prev: Executioner
next: Jester
---

# <font color="#887a59">👼 <b>Innocent</b></font> <Badge text="Evil" type="tip" vertical="middle"/>
---

The Innocent can use the kill button to plant any player, and the planted target will immediately kill the Innocent. If the target is voted out in the meeting, the Innocent wins. Note: Jester, Executioner, and Innocent can win together.
* Max
  * Set the Maximum amount of Innocents that can be in a match
* If their target was an <font color=red>Impostor</font> then they win with them
  * <font color=green>ON</font>: the Innocent and <font color=red>Impostor</font> win together if the Innocent framed an Impostor
  * <font color=red>OFF</font>: the Innocent won’t win with the Impostor


> From: SNR & Coding: [NCSIMON](https://github.com/NCSIMON)、[KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

He had a poor Family two younger Sisters and His mother was in the wheelchair their house was bad lots of leaks and cracks they could barely afford food but innocent worked hard day and night for His Family working two Jobs one during daytime and one in the night

Day Job
During the day he was a Delivery man delivering letters packages, food and alot of stuff he was going all around the town but the pay was Not enough for his entire Family but He still worked day and night it was a hard Life

Night Job
During Night time he was a Taxi Driver driving around all the people at night driving from one side of town to the other so many times the pay was terrible but He had to do it

It's getting worse
And with all that work he still had to take His Sisters to school and make food for His Family take Care of His mother, he barely had any sleep and looked tired all the time... because He was tired but Here's the sugar on the cream he got fired from His Job, what now? Money was running out he needs to provide His Family so he thought of one Last Desperate Option

I need Money....
The innocent decided to stage a accident and get money so he prepared he found someone a old man always driving the same way every sunday from home to donut Shop near the Forrest, he decided to make that old man his target the innocent went with the bicycle near the Forrest where the man will drive by he was waiting and waiting then he Came...the innocent quickly drove Infront of the car making the old man crash into him horrified he came out of the car the innocent now injured with a broken leg was lying there screaming at the old man in pain how could he be so careless...

It paid off but at what cost...
The Innocent got the old man to pay 50 thousand Dollars for his leg Treatment the old man didnt want to pay but the law decided otherwise the innocent with a broken leg counted the Money in His hands it's enough to provide for His Family for a while, the innocent Didnt get any leg Treatment and kept the broken leg but his Family had Money for a while but the cost was great

**Looking back there is a innocent counting the money in their Hands...Money that came at a high price**

> Submitted by: Kira (Vampire)
</details>
---
lang: en-US
title: Schrodingers Cat
prev: Romantic
next: Shaman
---

# <font color="#404040">🐈 <b>Schrodingers Cat</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As Schrodingers Cat, if someone attempts to use the kill button on you, you will block the action and join their team. This blocking ability works only once. By default, you don't have a victory condition, meaning you win only after switching teams.<br>
In Addition to this, you will be counted as nothing in the game.<br><br>

Note: If the killing machine attempts to use their kill button on you, the interaction is not blocked, and you will die.
* Max
  * Set the Maximum amount of Schrodinger Cats that can be in a match

> Idea & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Cat - Wait.. I'm alive?
Now the Pursuer had been through a lot 
From a follower to a pursuer and now he was Infront of a bullet thinking about his final words..
"The Knight... The one who I least expected" 
The Duel had gone south and the Pursuer was about to die and he was mindlessly babbling words trying to form a melody
"Legacy, what is a legacy?
It's planting seeds in a garden you never get to see
I wrote some notes at the beginning of a song someone will sing for me
Can leave their fingerprints and rise up
I'm running out of time, I'm running, and my time's up
Wise up, eyes up
I catch a glimpse of the other side
The Pixie leads a ghost's chorus on the other side"
He was going into shock and about to die but then he thought about the tranquility of not thinking about anything at all
And as the bullet hit him he flew off into a doze wondering if this was the end...
Psst It wasn't
As the atoms started to die... 
His didn't?
As there was wailing in the street people expected him to die.. The Knight having a beer with his friends..
But what if as an apology the Knight accepted the hut Cat?
The Cat survived through storms through diseases through a bullet he couldnt take more and now he just wanted rest and friends who would carry him to a win...
A team with gracious people
So he joined the Knight but now since the Cat was so weak one more punch or kill he would d!e
Well...
Everyone has second chances...
But if you keep loosing them you loose entirely..
Yes I used Cat cuz Im not typing Sch blah blah again and again
The End

> Submitted by: champofchamps78
</details>
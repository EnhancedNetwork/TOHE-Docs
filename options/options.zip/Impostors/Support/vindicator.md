---
lang: en-US
title: Vindicator
prev: TimeThief
next: Visionary
---

# <font color="red">🗣️ <b>Vindicator</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

The Vindicator receives extra votes, like Mayor.
* Max
  * Set the Maximum amount of Vindicators that can be in a match
* Additional Votes Count
  * Set how many extra votes the Vindicator will receive
* Hide additional vote(s)
  * <font color=green>ON</font>: the Vindicators extra votes will appear as nothing, but will still count
  * <font color=red>OFF</font>: all of the Vindicators votes will appear as normal votes

> From: TOH+

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue "Learn from your Mistakes" Said the professor "I dont make Mistakes" Said little Vindy Chapter 1 Poor Little Vindicator "We know you will be perfect" "Straight A's Again? I knew it" "Go and do it... Dont fail" STOP yelled the Vindicator I cant take it anymore... It's too Much pressure Chapter 2 No, You are wrong Accustomed to being right all the time Little Vindy Couldnt take a loss...Getting 99/100 Vindy was still upset? Pressure does that tsk tsk tsk "But Professor I- I cant be wrong, I'm Vindy" "You miscalculated! It's Fine everyone makes mistakes" Chapter 3 Die No. exclaimed Vindy as went home... No Only one thing left now.... To Prove Myself But... What if I actually was wrong? Impossible, And even If I was I could easily get it ticked... My way Chapter 4 That's Me Vindy went to Mr. Sloth told him his issues and took advice... Mr. Sloth had a plan and blue print on his desk of the working of the voting system and well... Vindy was very... Observative.. Stalling for time to observe and decode it compeletely Vindy asked to Be made an Impostor for revenge.. And well Ta da! Chapter 5 $$Hack Voting System$$ Asking his friend Gemini who was "Bard's" Son Vindy successfully hacked The voting system achieving him to get more votes.... Authors Note (Wait didnt bard also hack the ejection tube-) Chapter 6 4v1 Stuck in a bad situation on JUST the first day Vindy was stuck with 5 people and thirsty for blood he struck... Killing in front of a hole group- But... Worry not! Extra votes come into hand now Chapter 7 Wait- NO As the watcher (add on lore) Saw the 4 votes of black he knew what happened... but he didnt know what to do until he saw the roles menu "Vindicator" eh .. You aint vindicating no more Vindy.. As he guessed the Vindicator and Killed him using Shame The End Dont be sad for Vindy.. It's a lesson! Dont be stubborn
> Submitted by: champofchamps78
</details>
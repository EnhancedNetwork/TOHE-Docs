---
lang: en-US
title: Watcher
prev: Torch
next: /options/Settings/Addons.html
---

# <font color=#800080>👀 <b>Watcher</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

During the meeting, Watcher can see everyone's votes.
* Max
  * Set the Maximum amount of Watchers that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Watcher
* <font color=red>Impostors</font> can become Watcher
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Watcher
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Watcher
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Watcher
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> From: TOH & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
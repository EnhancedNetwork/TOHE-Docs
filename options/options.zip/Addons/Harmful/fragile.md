---
lang: en-US
title: Fragile
prev: Fool
next: Hurried
---

# <font color=#d3d3d3>📦 <b>Fragile</b></font> <Badge text="Harmful" type="tip" vertical="middle"/>
---

As Fragile, you will die instantly if someone tries to use kill button on you (even if the role can not directly kill)
* Max
  * Set the Maximum amount of Fragile that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Fragile
* <font color=red>Impostors</font> can become Fragile
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Fragile
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Fragile
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Fragile
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* <font color=red>Impostors</font> can force kill Fragile
  * <font color=green>ON</font>: <font color=red>Impostors</font> can kill Fragile forcefully
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot kill Fragile forcefully
* <font color=#8cffff>Crewmates</font> can force kill Fragile
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can kill Fragile forcefully
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot kill Fragile forcefully
* <font color=#7f8c8d>Neutrals</font> can force kill Fragile
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can kill Fragile forcefully
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot kill Fragile forcefully
* <font color=#ac42f2>Coven</font> can force kill Fragile
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can kill Fragile forcefully
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot kill Fragile forcefully
* Killer lunge on kill
  * <font color=green>ON</font>: Killers will lunge towards the Fragile on kill
  * <font color=red>OFF</font>: Killers will not lunge towards the Fragile on kill
  
> From: [cuboidsnow](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
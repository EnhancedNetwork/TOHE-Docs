---
lang: en-US
title: Doll Master
prev: /options/Settings/Impostors.html
next: Mastermind
---

# <font color=red>🎎 <b>Doll Master</b></font> <Badge text="Experimental" type="tip" vertical="middle"/>
---

As the Doll Master, you can temporarily take control of any player by using the Shapeshift button and to make them do your Deeds!

* Kill Cooldown
  * Set how long the Doll Master needs to wait to perform a kill
Possession Cooldown
  * Set how long the Doll Master needs to wait to possess a player
Possession Duration
  * Set how long the Doll Master will possess their target for
Can kill as main body
  * <font color=green>ON</font>: Doll Master can kill without using their ability
  * <font color=red>OFF</font>: Doll Master cannot kill unless they use their ability
Target dies after possession
  * <font color=green>ON</font>: Doll Master's target will die after the Duration of the Possession is finished
  * <font color=red>OFF</font>: Doll Master's target will not die after the Duration of the Possession is finished

> From: D1GQ

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Now the Dollmaster was quite the cook.. To be honest And he worked Godly fast He could make meals for a whole Crew in Minutes... One day the Dollmaster became Mad with himself... While cutting down a pufferfish the Dollmaster accidentally poisoned and killed a crewmate... This cant be.. He was great but blood? That of a Crewmate? He had never seen that before.. He was shaken but like any Other crew.. After killing the Dollmaster became... An Impostor (Duh Duh Duuuuuh on Drums in the background) Now... What about his ability? Butcher? Taken Chronomancer? Taken Poisoner? Taken What if he put something in the crewmates drink that could make then easy to be controlled remotely and easily be used to kill others the crewmates would act like puppets or more specifically dolls... That could work! That could work!! And it did... But it backfired.. One of the crew reported while the Dollmaster was controlling one of the crew and due to him controlling the whole crew saw the strings and the Dollmaster... Oops.. Dollmaster was ejected RIP Even the best ideas have cons... Even the best ones  The.. The End
> Submitted by: champofchamps78
</details>
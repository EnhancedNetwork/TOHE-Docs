---
lang: en-US
title: Ghoul
prev: Diseased
next: Gravestone
---

# <font color=#B22222>👻 <b>Ghoul</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

As the Ghoul, one of two outcomes can occur on task completion.<br><br>
If alive: Suicide<br>
If dead: You kill your killer if they are alive.<br><br>
Only assigned to crewmates, and not crewmates with no tasks or are task based.
* Max
  * Set the Maximum amount of Ghoul that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Ghoul

> From: TOHEX

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
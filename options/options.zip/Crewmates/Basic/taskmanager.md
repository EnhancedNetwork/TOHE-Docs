---
lang: en-US
title: Task Manager
prev: SuperStar
next: Tracefinder
---

# <font color="#01ffa5">📝 <b>Task Manager</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

You see the total number of tasks completed by everyone all together next to your role name, which updates in real time.
* Max
  * Set the Maximum amount of Task Managers that can be in a match

> From: TOHY

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
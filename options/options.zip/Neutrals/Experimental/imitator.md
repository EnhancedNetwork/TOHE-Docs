---
lang: en-US
title: Imitator
prev: /options/Settings/Neutrals.html
next: Quizmaster
---

# <font color="#b3d94c">👥 <b>Imitator</b></font> <Badge text="Experimental" type="tip" vertical="middle"/>
---

As the Imitator, use your kill button to imitate a player.<br><br>
You'll either become a Sheriff, Refugee, or some other Neutral.<br>
* Max
  * Set the Maximum amount of Imitators that can be in a match
* Imitate Cooldown
  * Set time an Imitator must wait before they can imitate another player
* If neutral is incompatible, turn into
  * Set what role the Imitator will become if they try to imitate a role that is incompatible with the Imitator, choose from:
    * Amnesiac
    * Imitator
    * Pursuer
    * Follower
    * Maverick

> From: TOHER (Old Amnesiac)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Trickster
prev: Swooper
next: Undertaker
---

# <font color="red">🎭 <b>Trickster</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

You don’t appear as <font color=red>Impostor</font> to Crewmates. (Sheriff cannot shoot you, it’s considered Misfire/Psychic does not see you as Evil. Snitch cannot find you.)
* Max
  * Set the Maximum amount of Tricksters that can be in a match

> From: TOH+

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Trickster began as an ordinary Impostor, but everything changed after scientists experimented on their "body." This experience sparked a fascination with deception and trickery. As they pondered their recent revival, the Trickster delved into dark magic, awakening a creature within—a Kitsune.

This transformation revealed their true identity and purpose. With newfound powers, the Trickster conjured a barrier around themselves, creating a deceptive facade. The Snitch, drawn by curiosity, would fall into their trap, perceiving them as innocent. Meanwhile, the Sheriff’s gun would jam just as they attempted to confront the Trickster, leading to a tragic outcome.

The Psychic, trying to discern the truth, would find their mind clouded and confused, unable to identify the real threat. The Trickster reveled in the chaos, ready to manipulate the game to their advantage.
> Submitted by: Northie
</details>
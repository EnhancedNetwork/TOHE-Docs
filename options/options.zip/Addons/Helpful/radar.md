---
lang: en-US
title: Radar
prev: Overclocked
next: Rebirth
---

# <font color=#d41e04>🧭 <b>Radar</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Radar, you have arrows pointing towards the closest person at all times.
* Max
  * Set the Maximum amount of Radars that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Radar
* <font color=red>Impostors</font> can become Radar
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Radar
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Radar
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Radar
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> From: TOU:R & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
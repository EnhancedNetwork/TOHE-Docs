---
lang: en-US
title: Minion
prev: Bloodmoon
next: Possessor
---

# <font color="red">👿 <b>Minion</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Minion, you can temporarily blind non-impostors.

* Ability Cooldown
  * Set how long the Minion has to wait to use their ability
* Ability Duration
  * Set how long the Minions target will be blind for

> Idea & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The Minion was a tiny yellow dude who would always follow his leader, He was originally a follower but as he understood the way of the impostor which he was following they converted him into… You guessed it, An Impostor Chapter 1 What to do, What to do Now the Minion was still short and had no special abilities, Since he was a follower he wouldn’t speak much and well… “Ahgisiuuuahb” Wise words, Truly, Wise words Now enough is enough lets dive into the story  Chapter 2 Seashells! Yea uhhhh That was the first word the minion spoke after being manufactured, True story! Anyways Back on topic, Today is a beautiful day, Not as beautiful as murder though thought the Minion as he went on to kill people But being a novice in Killing he was soon… Well… Ejected Damn his career was short as heck! Or… Was it Chapter 3 I’m Stuck with y’all now Now the minion had tagged along with impostors round one so well, if they won so would he and he could be reincarnated on the med table by the mad scientist But how could he help since well… he was a minion Duh Chapter 4 Pepper Spray Excellent Choice Now while eating the Minion was sure to take pepper and well… This would help Him so… So much by well Being able to blind people for a short duration and making it easier for Impostors to kill Duh Chapter 5 We win? That was easy, Since the whole crew was blind the Impostors swoop in and well…. Murder is Fun! Easy Win? No of course not the Minion had to suffer through being burned at more than 300 degree Celsius in Hot Lava Duh… But well a win is a win Happy ending For once
> Submitted by: champofchamps78
</details>
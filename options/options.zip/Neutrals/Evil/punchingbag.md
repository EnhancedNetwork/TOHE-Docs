---
lang: en-US
title: Punching Bag
prev: Jester
next: Seeker
---

# <font color="#684405">🤕 <b>Punching Bag</b></font> <Badge text="Evil" type="tip" vertical="middle"/>
---

As the Punching Bag, your goal is to get attacked a few times to win.<br><br>
You cannot be guessed, as that adds to your attack count.
* Max
  * Set the Maximum amount of Punching Bags that can be in a match
* Amount of attacks needed to win
  * Set how many times the Punching Bag needs to be attacked to win

> From: TOH+

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"You dare hurt my friend?!" Achilles exclaimed with anger as he saw Hector starve his best friend to death.
Achilles broke out from the prison cell.
He witnessed the deaths of his comrades but The death of his best friend broke him from the inside.
"Oh brilliant Achilles, Heroes have heard your tales of bravery from Kingdoms far afar. Oh brilliant Achilles, Immortal among men, We beg for your forgiveness and we offer our wine and supplies. Oh blue eyed Hero, People will sing about you in the future yet to unfold, Please grant us mercy and let us leave"

"Mercy? Mercy!? Hector I expected better from you. You killed my Hundreds of my people to take my throne, You imprisoned me in your dirty dungeons for 7 years all while I was building up my plan, Oh Hector, People think of you as great and noble but deep inside we all know what you are indeed...
You're a crooked man, Always trying to think for YOURSELF. Did YOU show mercy when I asked you? Did YOU feed my friend in the dungeons? 
Hector you devil roman king. You got this throne not because you were worthy, but because you had power and support from the other kingdoms.
Now your truth will be sang about in songs. As I end your story.. Mine begins"

As Achilles Stabbed Hector right in the heart, Hector's last words to Apollo, The god he worshipped were... "Apollo will make you suffer Achilles"

Then Achilles went on and announced that the King had died. Everyone was rejoicing as the kingdom was no longer under the control of the evil royalty but instead noble Achilles.

As the tired, Pale, blue eyed hero sat down, Apollo started raining down arrows from the heavens. 
Achilles was an Immortal among men, He easily dodged most of his arrows. 
As Apollo continued to fire Achilles' rage started to expand as he was being treated like a punching bag.
He knew Apollo was immortal as well and far stronger than Achilles and one time or the other Achilles would break and die.
His only chance was to hit where it really mattered. 

So as he was being treated like a Punching bag, Achilles went to the home of the Son of apollo and stabbed His family.
Apollo red with anger Took out the heavy artillery and hit Achilles' weak spot. His ankle
Achilles died but left a legacy behind.

He would be remembered as the saviour and vindicator.
So In reality... He won... Because he was being treated like a punching bag..

Ironic..
> Submitted by: champofchamps78
</details>
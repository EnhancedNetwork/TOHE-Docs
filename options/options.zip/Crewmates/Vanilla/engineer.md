---
lang: en-US
title: Engineer
prev: Crewmate
next: GuardianAngel
---

# <font color="#FF6A00">🛠️ <b>Engineer</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Engineer, you may access the vents while comms are not sabotaged.<br>
Vents are disabled when they are sabotaged.
* Max
  * Set the Maximum amount of Engineers that can be in a match

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Workhorse
prev: Reach
next: YouTuber
---

# <font color=#00ffff>🐎 <b>Workhorse</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

The first player to complete all the tasks will become Workhorse, Workhorse will give the player extra tasks. The amount of additional tasks are set by the host.
* Max
  * Set the Maximum amount of Workhorses that can be in a match
* Assign only to Crewmates
  * <font color=green>ON</font>: only <font color=#8cffff>Crewmates</font> can become Workhorse
  * <font color=red>OFF</font>: any Role that completes their tasks can become Workhorse
* Additional Long Tasks
  * Set how many Long Tasks a player will get if they become Workhorse
* Additional Short Tasks
  * Set how many Short Tasks a player will get if they become Workhorse
* Snitch can become Workhorse
  * <font color=green>ON</font>: the Snitch can become Workhorse if they complete their tasks before anyone else
  * <font color=red>OFF</font>: Others can still become Workhorse while the Snitch cannot

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
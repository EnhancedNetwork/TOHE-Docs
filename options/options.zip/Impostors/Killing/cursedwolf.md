---
lang: en-US
title: Cursed Wolf
prev: Councillor
next: Deathpact
---

# <font color=red>🐺 <b>Cursed Wolf</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

When the Cursed Wolf is about to be killed, the Cursed Wolf will curse the killer to death. (The maximum number of times you can counterattack is set by the host).
* Max
  * Set the Maximum amount of Cursed Wolves that can be in a match
* Amount of Cursed Shields
  * Set how many Shields the Cursed Wolf has

> From: TOHY

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue

"WORK HARDER!" yelled the martial arts instructor. The little bean sighed; today’s lesson was on counteroffense. "When will I ever use this?" he sobbed quietly.

Chapter 1: The Journey Begins

Learning martial arts is not for the faint of heart. Those words echoed in the young bean’s mind as he practiced day after day, mastering the essential techniques. He vowed to never give up, no matter how tough it got.

Chapter 2: The Day of Selection

Finally, the day arrived when the bean would be chosen to go to HQ, ready to be selected into a new group—either impostor or crewmate. Personally, he thought being an impostor sounded much more exciting. And guess what? He was selected to be an impostor! Great!

Chapter 3: Meeting the Fellow Impostors

“What’s good, kid?” asked the leader, known as the Godfather.

“All good! Who are you?” the bean replied, proud to be part of this new group.

“I am the Godfather. What about you?”

“I’m just a bean!” he exclaimed.

“Nah, that won’t work. You need a better name. How about Wolf?”

“Great!”

Chapter 4: Game #1

“Okay, now onto killing…” Slash! Shoot! Stab! “Yes! Three kills already!” But then disaster struck—the sheriff had cornered him, and he couldn’t attack due to a cooldown. Just as the sheriff lunged, the martial arts expert dodged and countered. Did he really defeat the sheriff? Oh my goodness!

Chapter 5: An Unusual Death

Even the coroner was baffled. “What kind of death is this? He was… cursed!”

Chapter 6: The Impostors Win

“So, Little Wolf, did you bite?” asked the Godfather.

“Of course! Seven kills! I think I should be called Cursed Wolf now, Godfather!”

“Very well!”
> Submitted by: champofchamps78
</details>
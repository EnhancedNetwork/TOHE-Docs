---
lang: en-US
title: Bloodmoon
prev: /options/Settings/Impostors.html
next: Minion
---

# <font color="red">🌙 <b>Bloodmoon</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Bloodmoon, attack enemies to make them drip blood, this means they will die in a time (set by host), and will be aware of it.

* Kill Cooldown
  * Set how long the Bloodmoon has to wait to kill
* Max BloodLettings
  * Set the Maximum amount of BloodLettings (kills) the Bloodmoon can make
* Time Until Death
  * Set how long targets of Bloodmoon have until they die

> From: TOH (Mafia) & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Okay okay I know what you might be thinking here… isn’t it once in a blue moon? Well yes and no…
There is a secret saying that if you are diagnosed with “Once in a Blood Moon” Then well… You will find out soon enough… No spoilers for you

Chapter 1 Hiding in the vents
The crewmates were such spoilsports! Thought the Impostor, Always and I mean ALWAYS Hiding away only They can reveal themselves… Ugh
After a few Minutes? It felt days! Of Walking
New Target 😄 Thought the Impostor as he saw a crewmate going around but little did he know…

Chapter 2 Well This is awkward
The Impostor kept on attacking the Spy but with no chance, The Gear provided by MI6 Was Unbreakable Ugh!!
And finally running towards the meeting room the spy called the meeting and well this was going to be… Awkward!

Chapter 3 You will Die, And so will you!
Now the Impostor was caught and he knew it was the end of the road and well… HE HAD A TERRIBLE RUN! It was his first game with NO KILLS! Ugh..

At this point you may think the story ends but not quite 🙂

Before being thrown out of the ship the Impostor cursed the crewmates that when The stars and planets align the person with the rune above them will die just like he was going to

Chapter 4 Oooohh I’m a ghost…
Now the Impostor was well… Dead.. May he Rest In peace but he was still with the crew, Spiritually and mentally 😄
Going around the Ghost, Called… “Blood Moon” As he named himself knew the stars will align in approximately 60 seconds so he went on and placed the rune above the spy and well… Now nothing can prevent his death… Nothing at all

Going around he found crewmates and placed runes on them and he killed so, so Many people…

Now… They won because most of the people were dead…
Chapter 5  From Down Blow
Since Mira HQ is mainly transparent people looked up to see the beautiful blue moon which was casted for that day but instead they saw well… Streams of Blood Everywhere…
It was a Blood Moon
> Submitted by: champofchamps78
</details>
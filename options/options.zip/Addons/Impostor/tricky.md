---
lang: en-US
title: Tricky
prev: Stealer
next: /options/Settings/Addons.html
---

# <font color=red>👺 <b>Tricky</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

As the Tricky, your kills will have a random death reason.
* Max
  * Set the Maximum amount of Swifts that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Swift
* Only Enabled Death Reasons
  * <font color=green>ON</font>: Trickys Kill-Reason will only randomly pull from the enabled roles
  * <font color=red>OFF</font>: Tricky's Kill-Reason will randomly pull from ALL roles

> From: [FlyFlyCat] & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
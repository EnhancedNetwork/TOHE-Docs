---
lang: en-US
title: Pacifist
prev: Oracle
next: Psychic
---

# <font color="#007fff">🛒 <b>Pacifist</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

When the Pacifist vents, they will reset the kill cooldown for everyone with a kill button, even if they technically can’t kill (like the Medic). If they become Mad Pacifist, this ability will only work on Crewmates.
* Max
  * Set the Maximum amount of Pacifists that can be in a match
* Ability Cooldown
  * Set how long a Pacifist needs to wait to Reset everyone's Kill Cooldown
* Max Number of Ability Uses
  * Set how many times a Pacifist can Reset everyone's Kill Cooldown
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Ability Uses a Pacifist gains with each Task completed (0.1 increments)

> From: [我若戏命](#) & Coding: [喜](https://space.bilibili.com/443432765)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: OIIAI
prev: Gravestone
next: Paranoia
---

# <font color=#2bdb2b>🐱 <b>OIIAI</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

As the OIIAI, you will erase your killer's main role.<br>
Additionally, OIIAI may pass on to the killer.<br>
A player can only be erased once
* Max
  * Set the Maximum amount of OIIAI that can be in a match
* Spawn Chance
  * Set the percentage players have of getting OIIAI
* <font color=red>Impostors</font> can become OIIAI
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become OIIAI
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become OIIAI
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become OIIAI
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* OIIAI can pass onto the killer
  * <font color=green>ON</font>: OIIAI's killer will gain the OIIAI addon
  * <font color=red>OFF</font>: OIIAI's killer will not gain the OIIAI addon
* Neutrals turn to
  * Set what role that a Neutral that killed an OIIAI will become, choose from:
    * Amnesiac
    * Imitator
    * Don't change the role

> Idea & Coding: [NikoCat223](https://github.com/NikoCat233)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
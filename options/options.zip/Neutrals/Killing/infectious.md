---
lang: en-US
title: Infectious
prev: Huntsman
next: Jackal
---

# <font color="#7b8968">🦠 <b>Infectious</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Infectious, your job is to infect as many players as you can.<br><br>
If you infect all the killers, you then can simply outnumber the crew and win the game.
* Infect Cooldown
  * Set how long an Infectious needs to wait to Infect a player
* Maximum Infections
  * Set how many times the Infectious can Infect people
* Know Infected Player’s Role
  * <font color=green>ON</font>: the Infectious can see the role of player’s that they’ve Infected
  * <font color=red>OFF</font>: the Infectious cannot see the Infected player’s roles.
* Infected players know each other
  * <font color=green>ON</font>: Infected players can see each other
  * <font color=red>OFF</font>: Infected players don’t know who else is an Infected player
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Infectious has <font color=red>Impostor</font> Vision
  * <font color=red>OFF</font>: the Infectious does not have <font color=red>Impostor</font> Vision
* Can Vent
  * <font color=green>ON</font>: the Infectious has the ability to Vent
  * <font color=red>OFF</font>: the Infectious cannot Vent

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
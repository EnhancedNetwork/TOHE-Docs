---
lang: en-US
title: Chief Of Police
prev: Captain
next: Copycat
---

# <font color="#f0c341">👮 <b>Chief Of Police</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

Players with swords can be recruited to join the sheriff's team to serve the crew. <br>
Note: only one recruitment opportunity Depending on settings, you may recruit non killers or non crews.<br>
You may suicide for recruiting wrong target.

Cooldown for recruiting sheriffs
  * Set the cooldown that Chief of Police has until they can recruit.
Can recruit Impostor or Neutral
  * <font color=green>ON</font>: Chief of Police can recruit Impostors or Neutrals
  * <font color=red>OFF</font>: Chief of Police cannot recruit Impostors or Neutrals
Prevent recruit players without kill button
  * <font color=green>ON</font>: Chief of Police cannot recruit players unless they have a kill button
  * <font color=red>OFF</font>: Chief of Police can recruit players unless they have a kill button
Suicides when recruit a non killer or non crewmate
  * <font color=green>ON</font>: Chief of Police will suicide upon recruiting a non-killer/non-crewmate player
  * <font color=red>OFF</font>: Chief of Police will not suicide upon recruiting a non-killer/non-crewmate player
Can pass Converted Addon to Sheriff
  * <font color=green>ON</font>: Chief of Police can recruit converted players
  * <font color=red>OFF</font>: Chief of Police cannot recruit converted players

> Idea & Coding: [NikoCat](https://github.com/NikoCat233)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Beartrap
prev: Bait
next: Bewilder
---

# <font color=#5a8fd0>🐻 <b>Beartrap</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

When Beartrap is killed, Beartrap will immobilize their killer for a configurable amount of time.
* Max
  * Set the Maximum amount of Beartraps that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Beartrap
* <font color=red>Impostors</font> can become Beartrap
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Beartrap
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Beartrap
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Beartrap
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* Freeze time
  * Set how long the killer of a Beartrap will be frozen/stuck for after killing

> From: TOH & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
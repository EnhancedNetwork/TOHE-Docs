---
lang: en-US
title: Anti Adminer
prev: /options/Settings/Impostors.html
next: Blackmailer
---

# <font color="red">🛠️ <b>Anti Adminer</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

The Anti Adminer can at any time find out if there are crewmates or <font color=#7f8c8d>Neutrals</font> near Cameras, Admin Table, Vitals, DoorLog and/or other devices.<br>
Note: Anti Adminer does not know for sure if someone is using the device while near it, they only know that someone is near the device.
* Max
  * Set the Maximum amount of Anti Adminers that can be in a match
* Can track camera usage
  * <font color=green>ON</font>: Anti Adminer knows when people are near the cameras
  * <font color=red>OFF</font>: Anti Adminer does not receive this information

> From: TOHY & Coding: [Yumenopai](https://github.com/Yumenopai)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Well, Here goes nothing as the Spy exhaled and went on to the selection arena… “I would either die or win this” Chapter 1 I am quite Impressed Said the professor as he looked down upon the new student. “You are an enigma Perimedes one of the only students who I haven’t been able to read, Be proud of that” The spy was quite well not quite Extremely skilled in well.. Everything! He had Perfect aim, Meticulous art of Striking and Oh so wonderful Technological skills but something was missing… Chapter 2 Free will? Or Fate Everyone in perimedes’ family was well a spy and they thought this was just fate and he would also just become a spy, But being a rebel and refusing to let others dictate his journey… But oh well… Chapter 3 Told you so “Shut up” said Peri to his brother as Mr.Sloth chose him to go up to Mira HQ as well…. A spy undercover due to his skills in evading attacks and technological skill but he wasn’t satisfied… Not at all… Chapter 4 Redemption Time Enraged with passion and a fire inside to prove himself the spy went on and improved his skills in… Killing. Whenever a round of games ended he would be one of the only survivors and well, He would go on and dedicate his time to the skills of murder Chapter 5 Here Goes Nothing Annoyed by the shenanigans of the spy, Mr. Sloth agreed to a one on one performance by the spy to impress him.. Failing to do so will get him executed but if he succeeded well.. He succeeded How would he win? Chapter 6 I See you The anti adminer could catch its victims off guard while they pleasantly see the security cameras and well… Slash He used this technology and set up even more sensors near Vitals and stuff and he could use his engineering wits to easily direct the signals to his.. Phone Is it the end? Never… There will always be successors in among us who carry the legacy and the anti adminer is just a pawn in this large universe
> Submitted by: champofchamps78
</details>
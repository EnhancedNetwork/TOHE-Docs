---
lang: en-US
title: Hawk
prev: Ghastly
next: Warden
---

# <font color="#606c80">🦅 <b>Hawk</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Hawk, you can kill a limited amount of players decided by the host, tough there's a chance you miss, slicing someone multiple times increases the chances.

* Kill Cooldown
  * Set how long the Hawk has to wait to kill
* Max Slices
  * Set the Maximum amount of slices (kills) a Hawk can make
* Chance to Miss
  * Set the chance that the Hawk misses their Kill
* Minimum players alive to kill
  * Set how many players have to be alive for the Hawk to kill
* Increase the Kill Count by one if a Crewmate is converted
  * <font color=green>ON</font>: the Hawk's Max Slices is increased by one if a Crewmate is converted
  * <font color=red>OFF</font>: the Hawk's Max Slices is not increased by one even if a Crewmate is converted

> From: Idea & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
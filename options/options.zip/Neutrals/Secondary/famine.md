---
lang: en-US
title: Famine
prev: Baker
next: Baker
---

# <font color=#83461c>⚰️ <b>Famine</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

Once the Baker has the set amount of people with bread alive, they will become Famine. If Famine is not voted out after the meeting they become Famine, every player without bread will starve (excluding other Apocalypse members). After this starvation of everyone without bread, Famine can use their kill button to starve any remaining players, which will kill those players right before the next meeting.<br>
<b>You are invincible and your presence is announced to everyone at the meeting after you transform.</b>

> From: Marg

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"Yummy bread²"

The Famine was once a cheerful Baker who wanted to be the very best and be the very best he did for a little while then he disobeyed what the "Wizard" said and now people are protesting outside his bakery,

But the last time we saw him was with the "Wizard" which helped him calm down the protesters and mostly fix everything back to normal

He was back on top once again with deliciously tasting bread, but one night he had a dream that warned him the further consequences that may occur with his actions, he ignored it

It was mostly smooth sailing with like 60% percent of the town buying from him and with his a 1000th customer, something happened, 

While working he started to change he turned tan to brown, his hat and outfit started to break down getting destroyed and his visor cracked a dark red

He then started to floated up and said

"THY WHO NOT BOUGHT BREAD FROM ME SHALL PERISH "

And one by one all 30% percent of the population started to fall to their knees and what's left was just their bones lying on the ground, And to those who tried to fight back what's been given can be taken back

Shouldn't had read the contract properly it was really the first sentence "After the given goal has been reached, The Famine will rides", Well it's too late now the first apocalypse has begun no other than

THE FAMINE
> Submitted by: burgerman7286
</details>
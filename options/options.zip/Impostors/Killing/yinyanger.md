---
lang: en-US
title: YinYanger
prev: Witch
next: Zombie
---

# <font color="red">☯️ <b>YinYanger</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the YinYanger, you can use your kill button one time to pick your Yin, and a second time to choose a Yang. When those 2 players meet, they'll kill each-other. When Yin & Yang have been chosen you can kill normally.
* Max
  * Set the Maximum amount of YinYangers that can be in a match
* Kill Cooldown
  * Set long the YinYanger needs to wait to kill

> Idea: TOHTOR & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

A New Philosophy

One day, while watching Discovery+, a bean with a passion for history stumbled upon a concept that would change his life: yin and yang. This ancient idea from Chinese philosophy described two opposing yet interconnected forces that perpetually interact. Intrigued by the notion of these elements balancing each other while also being in conflict, he spent days delving into the topic.

Impostor Selection

When the time came for impostor selection, the bean had a brilliant idea. He would choose two players, one representing yin and the other yang. The goal? To instigate a rivalry that would either lead them to self-destruct or eliminate each other.

Idea Number 1: Instigate Anger

“Too much work,” he thought, dismissing this option.

Idea Number 2: Deception

“Lies always work,” he mused. “Lying to yin and yang? That’s a fantastic idea!”

Game One

He selected the players. To the yin, he whispered, “The yang wants to destroy you. He claims he’s far superior. You need to eliminate him.”

Then, to the yang, he said, “It’s your destiny to take down the yin. There’s no other way to prove yourself.”

To both players, he added ominously, “The blood on your hands is a mark of your choices. You can decide whose blood it will be.”

As the beans squared off against each other, the bean who orchestrated this scheme watched with glee. “Yes! This is working perfectly!” he exclaimed.

The Conclusion

In the end, both yin and yang fell to their own rivalry, unaware that they had been manipulated. The bean, now calling himself the YinYanger, reveled in his cleverness as he claimed victory.

This was the birth of the Egoist and the YinYanger. In the aftermath, the only trace left behind was a single symbol—the Chinese yin yang image—marking the chaos that ensued.
> Submitted by: champofchamps78
</details>
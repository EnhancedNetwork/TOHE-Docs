---
lang: en-US
title: Stealer
prev: Mimic
next: Tricky
---

# <font color=red>🤑 <b>Stealer</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

Only <font color=red>Impostor</font> other than Bombers and Trapsters will become Stealer. Every time a Stealer kills a person, he gets an additional vote (the vote number is set by the host, and the decimal is rounded down). Also, extra votes from the Stealer are hidden during meeting.
* Max
  * Set the Maximum amount of Stealers that can be in a match.
* Spawn Chance
  * Set the percentage players have of getting Stealer.
* Votes Increase Amount Per Kill
  * Set how much the Stealers votes increase after a kill.

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
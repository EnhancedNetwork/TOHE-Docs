---
lang: en-US
title: Ghastly
prev: /options/Settings/Crewmates.html
next: Hawk
---

# <font color="#9ad6d4">👻 <b>Ghastly</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Ghastly, possess an unsuspecting person, thereafter choose a target for them, now they'll only be able to use their kill (or kill ability) on target until you posses someone else or possess time runs out.

* Possess Cooldown
  * Set how long the Ghastly must wait to Possess a player
* Max Possessions
  * Set how many times the Ghastly can Possess players
* Possession Duration
  * Set how long the Possession lasts on the Ghastly's target
* Ghastly Speed
  * Set how fast the Ghastly can move


> From: Idea & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
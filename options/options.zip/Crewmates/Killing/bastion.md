---
link: en-US
title: Bastion
prev: /options/Settings/Crewmates.html
next: Bodyguard
---

# <font color="#696969">💣 <b>Bastion</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Bastion, bomb vents to kill off impostors and neutrals.<br><br>
Be careful though, crewmates can also be killed with the bombs.
* Bombs clear after meetings
  * Any bombs the Bastion places will be cleared after a meeting ends
* Bomb Cooldown
  * Set how long the Bastion needs to wait before placing another bomb in a vent
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Ability Uses a Bastion gains with each Task completed (0.1 increments)
* (Initial) Maximum bombs
  *  Set the maximum initial amount of bombs a Bastion will have

> From: [Discussions](#) & Coding: [Gurge](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Seeker
prev: PunchingBag
next: /options/Settings/Neutrals.html
---

# <font color="#ffaa00">🔎 <b>Seeker</b></font> <Badge text="Evil" type="tip" vertical="middle"/>
---

As the Seeker, use your kill button to tag the target. If Seeker tags wrong player a point is deducted and if Seeker tags correct player a point will be added.<br>
Additionally, the Seeker will not be able to move for 5 seconds after every meeting and after getting a new target<br><br>
The Seeker needs to collect certain number of points set by the host to win
* Max
  * Set the Maximum amount of Seekers that can be in a match
* Number of points needed to win
  * Set how many points the Seeker needs to win
* Tag Cooldown
  * Set how long a Seeker needs to wait to tag a player

> Idea: [lily0la](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

1. The Introduction 
Seeker was a below average lad living in the slums,  eating food from the dumpster,rotten vegetables and fruits, He was desperate for money 
He was an illiterate as his family couldnt afford his education , He read books from libraries and learn how to speak, communicate with the people around him  

2. The Childhood
When Seeker was a kid  He always liked the Game Hide N Seek He liked to speedrun things as he always speedrunned his homework and went to play with his friends , He was passionate towards The Game Hide N Seek Very much 

3. Work
At work He was constantly being harassed as he weared clothes which were outfashioned,torn which heavily hit his reputation . His boss didn't give him 
Regular wages thus he had to work side hustles for a living ,

4. The Offer
When going through the train to work he met a salesman who was willing to play a game , A game of Ddakji where if he won he would get $1,000 but if he loses he gets slapped , The salesman kept on winning and winning till Seeker realised how the game works and defeated the salesman in a elegant way 
The Salesman handed him a card "Among Us.Inc" and it held a number behind the salesman told him if you ever are desperate again call this number

5. Among Us.Inc
Soon Seeker was fired from his job as his colleagues couldn't tolerate his poorness anymore , As he had lost his job the moment the salesman gave him the card came into his head, swiftly called the number , the number asked him to meet them at a location as he went there he was kidnapped and was tasked to participate in a game . A game of Hide N Seek , As Seeker was very passionate for Hide N Seek he quickly found all the hiders but he broke a law
He cheated by using unfair knowledge given by the guards, He was shot his body parts were made to use a machine , A machine purely made for the game **Hide N Seek** 

Thus the Seeker was brought into existence.
> Submitted by: notluffy
</details>
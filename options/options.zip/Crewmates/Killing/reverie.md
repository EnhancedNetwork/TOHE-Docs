---
lang: en-US
title: Reverie
prev: Retributionist
next: Sheriff
---

# <font color="#00bfff">🌌 <b>Reverie</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Reverie, you can kill but your cooldown starts high.<br><br>
It increases if you kill a crewmate and reduces otherwise.<br>
Depending on the host's settings, you may misfire on reaching max kill cooldown and your target dies with you.<br>
* Max
  * Set the Maximum amount of Reveries that can be in a match
* Starting kill cooldown
  * Set the starting cooldown the Reverie has to wait at the beginning of the game
* Reduce kill cooldown by
  * Set the amount of time the kill cooldown will go down by with each kill the Reverie makes
* Minimum Kill Cooldown
  * Set the lowest the Reverie's kill cooldown can be

> Rework Idea: [Pyro](#) & Coding: [ryuk](#), Original Idea & Coding: [TronAndRey](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
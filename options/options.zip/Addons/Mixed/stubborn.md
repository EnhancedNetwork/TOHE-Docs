---
lang: en-US
title: Stubborn
prev: Paranoia
next: Susceptible
---

# <font color=#fa5434>😖 <b>Stubborn</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

With the Stubborn add on, Eraser can’t erase your role, Cleanser can't cleanse you, Bandit can't steal from you and Monarch can't knight you.<br>
Additionally, you can’t gain any new addons from the merchant.
* Max
  * Set the Maximum amount of Stubborns that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Stubborn
* <font color=red>Impostors</font> can have Stubborn
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can have Stubborn
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can have Stubborn
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Stubborn
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> Idea: [Dailyhare](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
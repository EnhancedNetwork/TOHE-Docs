---
lang: en-US
title: Sunnyboy
prev: Jester
next: Jester
---

# <font color="#ff9902">☀️ <b>Sunnyboy</b></font> <Badge text="Hidden" type="tip" vertical="middle"/>
---

The Sunnyboy can check the life status of others through the life panel. When the Sunnyboy is alive, the game will not end due to a numerical advantage, (for example, the number of <font color=red>Impostors</font> is greater than the number of Crewmates, or there are no survivors). If the Sunnyboy dies at the end of the game, the Sunnyboy will win with the winning team
* You must have “Disable Hidden Roles” toggled <font color=red>OFF</font> for this to have a chance to appear
* Despite being listed under Evil, this role is actually Benign. It is only listed as Evil due to Jester being an Evil role.

> From: Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
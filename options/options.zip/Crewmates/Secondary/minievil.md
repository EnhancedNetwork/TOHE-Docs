---
lang: en-US
title: Evil Mini
prev: Mini
next: MiniNice
---

# <font color=red>🐁 <b>Evil Mini</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

As an Evil Mini, you are unkillable until you grow up and have a very long initial kill cooldown, which is drastically shortened as you grow up.<br><br>
(If the Evil Mini is somehow killed before they grow up, the game will not end unlike its Nice counterpart)

> Idea & Coding: [LezaiYa](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
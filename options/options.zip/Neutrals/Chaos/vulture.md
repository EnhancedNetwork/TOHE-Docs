---
lang: en-US
title: Vulture
prev: Vector
next: Workaholic
---

# <font color="#556b2f">🕊️ <b>Vulture</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

As the Vulture, you do not report bodies normally.<br>
Instead, reporting a body causes you to eat it, making it unreportable.<br>
Eat enough bodies to win!
* Max
  * Set the Maximum amount of Vultures that can be in a match
* Arrows pointing to dead bodies
  * <font color=green>ON</font>: the Vulture will receive arrows pointing to dead bodies (like a Mortician would)
  * <font color=red>OFF</font>: the Vulture will not receive any arrows
* Bodies needed to win
  * Set the Amount of Bodies a Vulture needs to Eat to Win
* Can Vent
  * <font color=green>ON</font>: the Vulture has the ability to Vent
  * <font color=red>OFF</font>: the Vulture cannot Vent

> From: TheOtherRoles & Coding: [ryuk](#) 

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The vulture always had a weird taste eating raw meat he also had a good sense of smell he even was a detective because he could smell bodies...and the Culprit on one case the vulture saw a horrible sight a couple in a park heads smashed in with rocks and their leftovers...were spread all over the playground how horrible it's disgusting everyone vomited at the sight except the vulture he started to drool he reached for the splattered brain and stuffed it into His Mouth everyone was horrified while the vulture Just ate it all up Chomp chomp munch munch gobble gobble gulp gulp Everyone ran you heard screams everywhere the vulture with His bloody Hands mouth covered in blood stood there all alone in the dark on the playground where a horrible crime took place he heard sirens and ran away into a dark alley he heard gun shots even got hit by one the He escaped but Just barely escaped into a dark corner the vulture laughed as he put his face in His hands he then said this "This place reeks of death, There's a chill in the air and i barely escaped being killed by a hair sorry to disappoint that is Not where where this ends!" He then went into hiding lurking in the dark smelling and searching for bodies whenever he is then one day he saw two people walk in a rose garden towards the Woods they stopped to smell the Roses then continued these Woods were hunting grounds popular to hunt and the two people which the vulture followed separated he followed one that Person trippped and fell his head smashed against the Rocks it was a bloody mess but the vulture saw it smiled and laughed as he devoured the body it was bitter yet so sweet but as the vulture was eating dogs barked he looked up saw hunting dogs they smelled the Meat he ran away ran for his life but the hunter shot the bullet hit straight into the vultures head he dropped dead and the wild animals ate his body...
> Submitted by: Kira (Vampire)
</details>
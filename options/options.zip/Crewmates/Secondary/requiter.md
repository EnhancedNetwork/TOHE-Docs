---
lang: en-US
title: Requiter
prev: Knight
next: Knight
---

# <font color="#e2acb5">⚔️ <b>Requiter</b></font> <Badge text="Hidden" type="tip" vertical="middle"/>
---

The Requiter has no bullets at the beginning. For each crewmate ejected, the Requiter gains one bullet. The Requiter can kill when they have bullets.

* You must have “Disable Hidden Roles” toggled <font color=red>OFF</font> for this to have a chance to appear

* Requiter Ignores Shields (Excluding Mini & Solsticer)
  * Set if Requiter ignores Shields or not

> From: Idea & Coding: [ImpyIsLazy](https://github.com/impostor4291)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
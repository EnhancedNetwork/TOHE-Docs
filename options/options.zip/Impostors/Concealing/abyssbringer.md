---
lang: en-US
title: Abyssbringer
prev: /options/Settings/Impostors.html
next: Escapist
---

# <font color="red">🌪️ <b>Abyssbringer</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

As the Abyssbringer, you can place black holes. Black holes will suck in players and kill them when colliding with them.
* Max
  * Set the Maximum amount of Abyssbringers that can be in a match
* Black Hole Place Cooldown
  * Set the Cooldown that Abyssbringer can place Black Holes
* Black Hole Despawn Mode
  * Time After Black Hole Despawns
    * Set the Time After Black Hole Despawns
* Black Hole Moves Towards Nearest Player
  * Black Hole Moving Speed
    * Set the Maximum Moving Speed of the Black Hole
* Black Hole Consuming Radius
  * Set the Maximum Consuming Radius of the Black Hole

> From: EHR & Coding: [Drakos](https://github.com/Ultradragon005)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
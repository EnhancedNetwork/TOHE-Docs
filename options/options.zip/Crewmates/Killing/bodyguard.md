---
link: en-US
title: Bodyguard
prev: Bastion
next: Crusader
---

# <font color="#185abd">🛡️ <b>Bodyguard</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

If a player is about to get killed near the Bodyguard, the Bodyguard will instead prevent it and suicide.
* Max
  * Set the Maximum amount of Bodyguards that can be in a match
* Protect Radius
  * Set how close the Bodyguard needs to be to someone in order to do their job correctly

> From: [NCSIMON](https://github.com/NCSIMON) & Coding: [NCSIMON](https://github.com/NCSIMON)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
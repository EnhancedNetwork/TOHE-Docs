---
lang: en-US
title: Vampire
prev: Undertaker
next: Warlock
---

# <font color=red>🧛 <b>Vampire</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

You kill with a delay. If you bite someone, they will die a set amount of time later. If a Meeting is called, the player you bite Dies immediately. (If you bite a Bait, you Self-Report)
* Max
  * Set the Maximum amount of Vampires that can be in a match
* Bite Kill Delay
  * Set how long it takes for a Vampires target to die after being Bit by the Vampire.
* Can Vent
  * <font color=green>ON</font>: Vampire can Vent
  * <font color=red>OFF</font>: Vampire cannot Vent

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"Ahh, where am I?" mumbled the Vampire, confused and disoriented.

-- Flashback --

Once, he was the captain of a ship bound for MiraHQ for their monthly check-up. Everything was smooth sailing until suddenly—

"Please take cover!" the ship's motherboard blared.

That was bad news.

Then the ship crashed.

-- Flashback Over--

While the rest of the crew succumbed to hallucinations from their injuries, they began singing in a delirious state:

"Some island, the first one we found,
It’s bursting with cows just roaming around,
Begging us to eat, so much meat,
And hunger is so heavy."

But where were the cows? The crew had lost their grip on reality, imagining each other as delectable feasts. Panic set in as their hunger intensified.

The captain, however, had a few tricks up his sleeve. Desperate, he found a knife and made a difficult choice, turning on his crew in a frenzy of survival.

But help was still three days away, and clean water was scarce. What he did have was a source of nourishment—blood.

Days passed, and when the rescue ship finally arrived, it found not a crew but a lone vampire. He understood one thing: he was no longer a captain; he was now the antagonist of his own story.

-- Next Destination: Polus --

"How fortunate," thought the Vampire, a wicked smile creeping across his face. No one would notice if he took a bite, would they?

On his way to the lab for the check-up, he decided to indulge his hunger. As the doctors disappeared one by one, he mused, “Who will perform my check-up now? No one!”

With each passing day, he grew bolder, savoring his newfound freedom. Out of the shadows, he awaited the next shipment of crew members, eager for more mischief.

“Why not enjoy the wait?” he thought, planning his next move.

> Submitted by: champofchamps78
</details>
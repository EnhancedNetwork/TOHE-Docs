---
lang: en-US
title: Cleaner
prev: Camouflager
next: Consigliere
---

# <font color="red">🧹 <b>Cleaner</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

Cleaner can press the Report button to clean up any dead body they see. If the cleanup is successful, the Cleaner will see a Shield animation as a reminder. The cleaned up body cannot be reported.
* Max
  * Set the Maximum amount of Cleaners that can be in a match.
* Kill Cooldown
  * Set the Cleaners Kill Cooldown
* Kill Cooldown on Clean
  * Set what the Cleaner's Kill Cooldown is after cleaning a body

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The Cleaner met the parasite but he never anticipated how this confrontation would turn out Chapter 1 Hey there The cleaner saw the loner around HQ and went on to talk to him but got a very unusual response.. Almost cleaner like but wouldn't the cleaner be able to see the role of the impostor then? Curious.. He went on to meet again with the trusty Mad scientist who leads to the development of Impostor roles and asked him about something, The report button working Chapter 2 Just take it out! The cleaner was very germophobic and would never even touch a dead body, It was just kill and kill... But the parasite? It would poke around the body but the cleaner needed to learn this art to use his ability so... Chapter 3 Teach me sensei After years (days) of learning the cleaner finally learnt how to poke around dead bodies and now finally... He could use his ability that he wanted to... Poke around dead bodies and clean them up so he could disarm their report button Chapter 4 After Killing After killing the body the cleaner pressed the report button and started to search for the button and finally he found it and dismantled it, Finally making the body unreportable Chapter 5 But I need to clean this up Thought the Cleaner as he went on to grab a mop and wipe wipe wipe as he cleaned it fully but then he was being treated like a Janitor which made him So overly angry he started to become demented and ate the bodies... Nom Nom Chapter 6 A new Villain As the Cleaner went on he started developing variants like a scavenger, Oblivious addons... And more But the cleaner was so powerful in cleaning away bodies that he kept on winning as he made the Beans incapable of reporting!! I mean- Isn't this story a bit gross
> Submitted by: champofchamps78
</details>
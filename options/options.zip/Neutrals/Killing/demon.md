---
lang: en-US
title: Demon
prev: Cultist
next: Doppelganger
---

# <font color="#68bc71">👿 <b>Demon</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

Only the Demon team and the <font color=#8cffff>Crewmate</font> team are left, and the number of Demon is greater than the number of <font color=#8cffff>Crewmate</font> members, then the Demon win. The Demon's killing rules are different from others. Everyone in the Demon's perspective has health volume. Demon kill and are killed instead consume health. Killing will take effect when the health is exhausted. Note: If other people consume the Demon's health but fail to kill the player, the murderer will see the shield-animation on the Demon as a reminder.
* Attack Cooldown
  * Set how long a Demon needs to wait in between their Attacks
* Can Vent
  * <font color=green>ON</font>: the Demon has the ability to Vent
  * <font color=red>OFF</font>: the Demon cannot vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Demon has the same vision as an Impostor
  * <font color=red>OFF</font>: the Demon has default vision
* Player max health
  * Set how much health a player appears to have to the Demon
* Damage
  * Set how much Damage the Demon does to other players
* Demon Max Health
  * Set how much health a demon appears to have to themself
* Demon damage received
  * Set how much health a Demon loses when someone tries to kill them

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
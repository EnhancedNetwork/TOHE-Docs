---
lang: en-US
title: Keeper
prev: Investigator
next: Lighter
---

# <font color="#9ad3c2">💌 <b>Keeper</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Keeper, you can vote someone to protect them from being ejected. You can only do this a configurable amount of times.
* Max
  * Set the Maximum amount of Keepers that can be in a match
* Max protections
  * Set the number of ability uses the Keeper gets
* Hide Keeper's vote
  * <font color=green>ON</font>: the Keeper's vote will be hidden
  * <font color=red>OFF</font>: the Keeper's vote will not be hidden

> Idea: [Drakos](#) & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
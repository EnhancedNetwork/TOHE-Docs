---
lang: en-US
title: Pirate
prev: God
next: Revolutionist
---

# <font color="#edc240">🏴‍☠️ <b>Pirate</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

As the Pirate, use your kill button to select a target every round.<br>
You will duel with your target in the next meeting.<br>
If both Pirate and the target chooses the name number, Pirate wins.<br>
Additionally, if Pirate wins the duel or the target doesn't participate in the duel, the Pirate kills the target.<br><br>
Dueling command:- /duel X (where X can be 0, 1 or 2)<br><br>
You win after winning a certain number of duels set by the host.
* Max
  * Set the Maximum amount of Pirates that can be in a match
* Duel Cooldown
  * Set how long a Pirate needs to wait to use their ability
* Hide Pirate's commands
  * <font color=green>ON</font>: the mod will attempt to hide the Pirate's `/duel` commands
  * <font color=red>OFF</font>: the mod will not care to hide the Pirate's commands
* Number of successful duels needed to win
  * Set how many times the Pirate needs to win a duel to win

> From: Town of Salem 1 & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“Yar har fiddle Dee Dee, being a pirate is alright to be”
 
Are you ready kids cause this is a something that you haven’t seen before, typically pirates are portrayed as bearded man that sails the seven seas for treasure and most of them are except for this one, meet our protagonist let’s just call him Pirate, rather than sailing the ocean he’s sailing space, that’s right he’s a space pirate just like a real pirate but in space. He’s goal is to have a big spaceship to travel to different Galaxies to find the perfect crew to work with
 
And there it was a ship flying off it was named the Skeld it was the biggest ship he ever saw so now he must have it, he quickly aboard the ship just like any other crewmate there and tried to blend in, he knew that he can’t take the ship all in his own and he also thought no one would ever join him so he made a plan while exploring the ship analyzing every part of it he started to picked his first victim
 
BODY REPORTED
 
They went to the meeting but something was wrong the person that was chosen by the Pirate, their mind was blank they could hear everyone but it’s like less audible, then he heard a voice choose another 0 to 2, confused he just picked two but then nothing, he can’t hear anything can’t see anything he feels like nothing like someone just switched off their brain, it was the Pirate Fun Fact about him maybe being in space for a long time and being exposed to radiation may have effects on you, but for him it greatly empowered him giving him the power to sink into peoples mind and play a game with them say the same thing and your mind is gone don’t say anything and then your mind is also gone
 
He was feeding on them every right guess it powered him up and with the last duel he won, he was now unstoppable you can’t beat him all you could do is abandon ship because this ship is not yours to keep it’s not his, no other than
 
THE PIRATE

> Submitted by: Pikmin 6(No.1TrickJestershipper)
</details>
---
lang: en-US
title: YouTuber
prev: Workhorse
next: /options/Settings/Addons.html
---

# <font color=#fb749b>📹 <b>YouTuber</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

Only <font color=#8cffff>Crewmate</font> will become YouTuber. When the YouTuber is the first player to be killed in the game, the YouTuber will win alone. If the YouTuber does not meet the win conditions, the YouTuber will follow the <font color=#8cffff>Crewmate</font> to win. Note: Indirect killing methods such as being exiled, being guessed by the Guesser, etc. will not trigger the skills of the YouTuber.
* Max
  * Set the Maximum amount of Youtubers that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Youtuber

> From: [Night_瓜](https://space.bilibili.com/1638639993) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
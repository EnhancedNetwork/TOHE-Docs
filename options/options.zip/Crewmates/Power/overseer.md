---
lang: en-US
title: Overseer
prev: Monarch
next: President
---

# <font color="#ba55d3">👁️ <b>Overseer</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

An Overseer can see the Role of the Nearest Player by using their Kill Button, but has very limited Vision.
* Max
  * Set the Maximum amount of Overseers that can be in a match
* Reveal Cooldown
  * Set how long an Overseer needs to wait to use their Ability
* Reveal Time
  * Set how long an Overseer needs to stay near their target to see the target's role
* Overseer Vision
  * Set how far the Overseer can see

> From: Idea & Coding: [papercut](https://github.com/lars-wu)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
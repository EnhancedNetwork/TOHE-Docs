---
lang: en-US
title: Reach
prev: Rainbow
next: Workhorse
---

# <font color=#74ba43>🫳 <b>Reach</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

Only roles with a kill button can get this add-on. You have the longest kill range possible in the game, unlike everyone else.
* Max
  * Set the Maximum amount of Reaches that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Reach

> From: [Gurge44](#) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
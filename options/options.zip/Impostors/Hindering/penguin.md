---
lang: en-US
title: Penguin
prev: Eraser
next: Pitfall
---

# <font color="red">🐧 <b>Penguin</b></font> <Badge text="Hindering" type="tip" vertical="middle"/>
---

As the Penguin, you can restrain target by pressing the kill button, and drag around.
While dragging, the target dies by pressing the kill button again or after a certain period of time.
Press the kill button twice for a direct kill.

* Dragging Time
  * Set how long the Penguin can drag a player for
* Kill the target if a meeting starts during dragging
  * <font color=green>ON</font>: The player that the Penguin is dragging will die if a body is reported/emergency meeting is called
  * <font color=red>OFF</font>: The player that the Penguin is dragging will not die if a body is reported/emergency meeting is called

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Penguin go waddle waddle, walk and eat fish shaped beans. Yum!
> Submitted by: crxstos
</details>
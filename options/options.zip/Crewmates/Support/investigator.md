---
lang: en-US
title: Investigator
prev: Inspector
next: Keeper
---

# <font color=#007FFF>🕵️ <b>Investigator</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Investigator, use your kill button on a player to learn something about them.<br><br>
Depending on the settings, it'll be either sus/not sus or their exact role.
* Investigate Cooldown
  * Set how long the Investigator has to wait to investigate players
* Maximum Investigations
  * Set how many times the Investigator can investigate players
* Reveal Mode
  * Role - Reveals the targets Role
  * Suspicion - Reveals if the Target has a kill button

> From: Project Lotus

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
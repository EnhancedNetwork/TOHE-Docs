---
lang: en-US
title: Witness
prev: Ventguard
next: /options/Settings/Crewmates.html
---

# <font color="#e70052">👁️‍🗨️ <b>Witness</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Witness, when you use your kill button on someone, you will know if they killed in the last X seconds or not. (X depends on the settings)
* Ability Cooldown
  * Set the amount of time Witnesses need to wait to use their ability
* Max Time after killing where killer appears red
  * Set the amount of time after a kill where the killer will appear red to the Witness

> From: ToUR (Detective) & Coding: [Gurge44](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Shroud
prev: SerialKiller
next: Spiritcaller
---

# <font color="#6697ff">👻 <b>Shroud</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Shroud, you do not kill normally.<br>
Instead, use your kill button to shroud a player.<br>
Shrouded players kill others.<br>
If the shrouded player doesn't make a kill, they'll kill themself after a meeting.<br><br>
Shroud sees shrouded players with a 「◈」 mark next to their name.<br>
Shrouded players who did not make a kill will also have the 「◈」 mark in meetings, where they'll die if the Shroud is alive by the end of the meeting.
* Shroud Cooldown
  * Set how long a Shroud needs to wait to use their Ability
* Can Vent
  * <font color=green>ON</font>: the Shroud can Vent
  * <font color=red>OFF</font>: the Shroud cannot Vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Shroud can see as far as an <font color=red>Impostor</font> can
  * <font color=red>OFF</font>: the Shroud will have <font color=#8cffff>Crewmate</font> Vision

> From: Town of Salem 2

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
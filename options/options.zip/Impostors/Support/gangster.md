---
lang: en-US
title: Gangster
prev: Fireworker
next: Godfather
---

# <font color="red">🤵 <b>Gangster</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

The Gangster can attempt to recruit a player to a Madmate by pressing the kill button. If the recruitment is Successful, The Gangster and Target will see a shield to confirm. Once the Gangster recruits his Maximum amount of people, only then can he begin killing. If the Gangster attempts to recruit an un-recruitable player, the target will be killed normally.
* Max
  * Set the Maximum amount of Gangsters that can be in a match
* Recruit cooldown
  * Set how long the Gangster needs to wait to Recruit/Convert a Madmate
* Recruit limit
  * Set how many people that the Gangster can Recruit/Convert to Madmate
* Sheriff can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Mayor can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Vigilante can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Judge can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Marshall can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Overseer can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it
* Retributionist can be converted
  * <font color=green>ON</font>: this role can become a Madmate if the Gangster interacts with it
  * <font color=red>OFF</font>: this role cannot become a Madmate from Gangster interacting with it

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Roaming around In Mira during the winters it was a very chilly night but this was the Best night for the Gangster… Chapter 1 Life Lesson Going around school The Gangster was always asked about his fear and he always said… Being forgotten rather than the obvious majority answer of “Guns” , “Knives” , “Death” All of his pears feared pain… but pain was a part of life. Chapter 2 Remember Me After School when the Gangster was roaming around Mira HQ he saw a lonely bean just hanging around… By Himself. Feeling bad The gangster went on to interact with him and made small talk… In the end when things started to get Spicy and hard for the gangster to persuade the Loner to enter the Gangsters team…. The Gangster pulled out a gun Chapter 3 Angry Sloth Mr. Sloth started raging in his office when he learned about the new changes in amongus… Earlier only 1 Impostors were allowed but now… Ever since the gangster had started his charades 3 were allowed but Mr. Sloth couldn’t allow the increasing number of Impostors so he created a new category of… Madmates Chapter 4 I Wont One of the beans became a… rebel and went on to confront the gangster and told him to his face that he wont join the gang so… The gangster had no choice except to.. Kill as his secret was known to a bean who wasn’t in his gang….. Chapter 5 I.. Killed? That’s new The Gangster was very… Moved by him killing… This changes everything, He always thought he would keep blood off my hands but when that that happened he had to.. attack He was… Not the same anymore starting to realize his true purpose… He… was new to killing but… Liked it So rather than playing with his gang he guessed all of them and… became the JUGGERNAUT This Story will never end... The End :)
> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Doppelganger
prev: Demon
next: Glitch
---

# <font color=#f1f0a1>🎭 <b>Doppelganger</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Doppelganger, use your kill button to steal a player's identity (their name and skin) and then kill your target.<br><br>
Kill everyone to win.<br><br>
Note:- You can not steal the identity of the target when Camouflage is active.
* Maximum Steals
  * Set how many times the Doppelganger can steal the identities of players
* Kill Cooldown
  * Set the Doppelgangers Kill Cooldown

> Idea: [thewhiskas27](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Nice Mini
prev: MiniEvil
next: Mini
---

# <font color="#dddddd">🐁 <b>Nice Mini</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

As a Nice Mini, you can't be killed until you grow up, and if you die somehow or are evicted from the meeting before you grow up, everyone loses.

> Idea & Coding: [LezaiYa](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Warden
prev: Hawk
next: /options/Settings/Crewmates.html
---

# <font color="#228b22">👮 <b>Warden</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Warden, alert someone of nearby danger, additionally giving them a temporary speed boost.

* Ability Cooldown
  * Set how long the Warden has to wait to use their ability
* Increase speed by
  * Set the speed increase that the Wardens target will receive when the Warden interacts with them
* Max number of alerts
  * Set the maximum ability uses that the Warden will have

> From: Idea & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
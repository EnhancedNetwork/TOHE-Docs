---
lang: en-US
title: Traitor
prev: Stalker
next: Virus
---

# <font color="#ba2e05">👺 <b>Traitor</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Traitor, you were an <font color=red>Impostor</font> that betrayed the Impostors.<br>
You know the <font color=red>Impostors</font> but they don't know you.<br>The twist? They can kill you but you can't kill them.
* Kill Cooldown
  * Set how long the Traitor needs to wait to Kill
* Can Vent
  * If toggled <font color-green>ON</font>, the Traitor can Vent
  * If toggled <font color-red>OFF</font>, the Traitor cannot Vent
* Has <font color=red>Impostor</font> Vision
  * If toggled <font color-green>ON</font>, the Traitor can see as far as an <font color=red>Impostor</font> can
  * If toggled <font color-red>OFF</font>, the Traitor will have <font color=#8cffff>Crewmate</font> Vision
* Can Sabotage
  * If toggled <font color-green>ON</font>, the Traitor can Sabotage
  * If toggled <font color-red>OFF</font>, the Traitor cannot Sabotage

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
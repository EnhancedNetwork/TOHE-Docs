---
lang: en-US
title: Lawyer   
prev: Hater
next: Maverick
---

# <font color="#008080">⚖️ <b>Lawyer</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

Lawyer has a target to defend, which will be indicated by a diamond 「♦」 next to their name.<br>
If your target wins, you win.<br>
If they lose, you lose.
* Max
  * Set the Maximum amount of Lawyers that can be in a match
<details>
<summary><b><font color=#008080>Lawyer</font> Target Settings</b></summary>

* Can Target Impostors
  * <font color=green>ON</font>: the Lawyer can target players from this team
  * <font color=red>OFF</font>: the Lawyer cannot target players from this team
* Can Target <font color=#7f8c8d>Neutral</font> Killers
  * <font color=green>ON</font>: the Lawyer can target players from this team
  * <font color=red>OFF</font>: the Lawyer cannot target players from this team
* Can Target Crewmates
  * <font color=green>ON</font>: the Lawyer can target players from this team
  * <font color=red>OFF</font>: the Lawyer cannot target players from this team
* Can Target Coven Members
  * <font color=green>ON</font>: the Lawyer can target players from this team
  * <font color=red>OFF</font>: the Lawyer cannot target players from this team
* Can Target Jester
  * <font color=green>ON</font>: the Lawyer can target this role
  * <font color=red>OFF</font>: the Lawyer cannot target this role
* Knows role of target
  * <font color=green>ON</font>: the Lawyer knows their target's role
  * <font color=red>OFF</font>: the Lawyer only knows who their target is, but not their role
* Target knows their Lawyer
  * <font color=green>ON</font>: the Lawyer's target knows who their Lawyer is
  * <font color=red>OFF</font>: the target doesn’t know their Lawyer
</details>

* When Target Dies, Lawyer becomes one of the following:
  * Crewmate
  * Jester
  * Opportunist
  * Convict
  * Celebrity
  * Bodyguard
  * Dictator
  * Mayor
  * Doctor

> From: TheOtherRolesAU + "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

 - OBJECTION!
The lawyer was always arguing with authority not giving a damn what they thought, and when he was stopped he would just start throwing around big words which confused the officer and ultimately the officer let him free..
The lawyer found  a great way to earn money...
He was the first Lawyer... Let us call him... A. Ham
Now A. Ham had a competetor A. Burr who was an Executioner who needed to earn money by getting people Voted by the jury

Now this was an ongoing battle which has not ended even YET...
Lawyer VS Executioner...

But one thing for certain if the target dies due to "Circumstances"
The lawyer's main goal is to be voted out and jester around the crewmates.. Stealing the win

Other wise... he just needed an Opportunity to win with the crewmates.. this was different for other lawyers...

But A. Ham? He was an Opportunist...

More to come :P
THE END!
Oppo.. My love, take your time
I'll see you on the other side
Raise a glass to freedom.

And... He was shot between his ribs...
Opportunist by his side...

Will the tell your story?

> Submitted by: champofchamps78
</details>
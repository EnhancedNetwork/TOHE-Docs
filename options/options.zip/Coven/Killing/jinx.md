---
lang: en-US
title: Jinx
prev: HexMaster
next: /options/Settings/Coven.html
---

# <font color="#ed2f91">🤞 <b>Jinx</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

The Jinx can use their kill button to Jinx a player. Anyone who interacts with the Jinxed player will die with the death reason Jinxed.<br><b>With the Necronomicon, the Jinx can double-kill to kill normally. Also, the Jinxed player and the player who interacted with the Jinxed person will die.</b>
* Kill Cooldown
  * Set how long the Jinx needs to wait to use their Ability
* Amount of Jinx Spells
  * Set the Amount of Jinxes that the Jinx can use
* <font color=#ac42f2>Coven</font> Can Die To Jinx
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> members can die upon interacting with a Jinxed player
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> members will not die upon interacting with a Jinxed player


> Original "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)<br>
> Reworked Idea & Coding: [Marg](https://github.com/MargaretTheFool)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
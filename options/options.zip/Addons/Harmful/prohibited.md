---
lang: en-US
title: Prohibited
prev: Oblivious
next: Rascal
---

# <font color=#6a8f8f>⛔ <b>Prohibited</b></font> <Badge text="Harmful" type="tip" vertical="middle"/>
---

As the Prohibited, you have some Vents Blocked for use.
* Max
  * Set the Maximum amount of Prohibited that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Prohibited
* <font color=red>Impostors</font> can become Prohibited
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Prohibited
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Prohibited
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Prohibited
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* Override Blocked Vents After Meeting
  * <font color=green>ON</font>: Blocked vents will be overridden after meeting
  * <font color=red>OFF</font>: Blocked vents will not be overridden after meeting
* Count Blocked Vents in The Skeld
  * Set how many vents will be blocked on this Map
* Count Blocked Vents in MIRA HQ
  * Set how many vents will be blocked on this Map
* Count Blocked Vents in Polus
  * Set how many vents will be blocked on this Map
* Count Blocked Vents in Dleks
  * Set how many vents will be blocked on this Map
* Count Blocked Vents in Airship
  * Set how many vents will be blocked on this Map
* Count Blocked Vents in The Fungle
  * Set how many vents will be blocked on this Map

> From: [TommyXL](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
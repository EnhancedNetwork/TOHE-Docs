---
lang: en-US
title: Plague Scientist
prev: Pickpocket
next: Pyromaniac
---

# <font color="#ff6633">🦠 <b>Plague Scientist</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

(Plague Doctor from TOH)
The Plague Scientist's goal is to infect every living player.
They start by choosing one player to infect, after which anyone who spends a set amount of time in range of the infected player becomes infected themselves.
Infection progress is cumulative, and does not reset with distance or after meetings.

* Infect Limit
  * Set the maximum Infects the Plague Scientist has
* Infect Killer when Killed
  * <font color=green>ON</font>: the Plague Scientist's killer will become Infected
  * <font color=red>OFF</font>: the Plague Scientist's killer will not become Infected
* Infect Time
  * Set how long a player needs to be around an Infected player before they become Infected themself
* Infect Distance
  * Set how close a player needs to be around an Infected player before they become Infected themself
* Delay Infection After Start the Game and After Meetings
  * Set the Delay for Infecting at the Start of Game/After Meetings
* Can Infect Self
  * <font color=green>ON</font>: the Plague Scientist can Infect themself
  * <font color=red>OFF</font>: the Plague Scientist cannot Infect themself
* Can Infect While in Vent
  * <font color=green>ON</font>: the Plague Scientist can Infect in a Vent
  * <font color=red>OFF</font>: the Plague Scientist cannot Infect in a Vent

> From: TOH & Coding: [Drakos]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
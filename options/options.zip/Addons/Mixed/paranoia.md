---
lang: en-US
title: Paranoia
prev: OIIAI
next: Stubborn
---

# <font color=#3a648f>🫂 <b>Paranoia</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

Madmates and <font color=#7f8c8d>Neutrals</font> can't become Paranoia. Paranoia will be considered as 2 players in the game (not applying to meeting votes). Having at least one player as Paranoia won't end the game if there are only them and the <font color=red>Impostor</font> left.
* Max
  * Set the Maximum amount of Paranoias that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Paranoia 
* <font color=red>Impostors</font> can become Paranoia
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Paranoia
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Paranoia
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
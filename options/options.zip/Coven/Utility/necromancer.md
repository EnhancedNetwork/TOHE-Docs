---
lang: en-US
title: Necromancer
prev: MoonDancer
next: PotionMaster
---

# <font color="#9c87ab">⚰️ <b>Necromancer</b></font> <Badge text="Utility" type="tip" vertical="middle"/>
---

As the Necromancer, you can shapeshift to become the role of a random dead person for a set duration. Some roles can not be used.<br>Once a role is used, it can not be used for the rest of the game.<br><b>With the Necronomicon, when someone tries to kill you, you will block the kill and be teleported to a random vent. You have a limited time to kill your killer. If the time runs out or you try to kill someone else, you die.</b>
* Kill Cooldown
  * Set how long the Necromancer has to wait to Kill
* Necronomicon Ability time
  * Set how long the Necromancer has to kill the player that attempted to kill them, or else they suicide
* Necromancy Duration
  * Set how long the Necromancer has the role of a random dead person
* Necromancy Cooldown
  * Set how long the Necromancer has to wait to activate Necromancy


> Originally From: EHR<br>
> Reworked Idea & Coding: [Marg](https://github.com/MargaretTheFool)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
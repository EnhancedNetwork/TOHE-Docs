---
lang: en-US
title: Guardian Angel
prev: Engineer
next: Scientist
---

# <font color="#6ecebe">👼 <b>Guardian Angel</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Guardian Angel, you are the first crewmate to die and can give Crewmates temporary shields.
* Max
  * Set the Maximum amount of Scientists that can be in a match
* Protect Cooldown
  * Set how long the Scientist has to wait to use Vitals
* Protect Duration
  * Set how long the Scientist can use Vitals for at a time
* Protect Visible to Impostors
  * <font color=green>ON</font>: the Impostors can see the Protection of Guardian Angel
  * <font color=red>OFF</font>: the Impostors cannot see the Protection of Guardian Angel

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Celebrity
prev: Alchemist
next: Cleanser
---

# <font color="#ee4a55">🎥 <b>Celebrity</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

All <font color=#8cffff>Crewmates</font> see the Kill-Flash when Celebrity dies. And get an Alert in the next Meeting. The <font color=red>Impostors</font> (and <font color=#7f8c8d>Neutrals</font> depending on Settings) don’t know anything about this.
* Max
  * Set the Maximum amount of Celebrities that can be in a match
* <font color=red>Impostors</font> know when the Celebrity dies
  * <font color=green>ON</font>: <font color=red>Impostors</font> can see the kill flash of when the Celebrity dies
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot tell when a Celebrity gets killed
* <font color=#7f8c8d>Neutrals</font> know when the Celebrity dies
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can see the kill flash of when the Celebrity dies
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot tell when a Celebrity gets killed.

> From: Goose Goose Duck & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
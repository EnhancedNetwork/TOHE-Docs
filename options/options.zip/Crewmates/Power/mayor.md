---
lang: en-US
title: Mayor
prev: Marshall
next: Monarch
---

# <font color="#204d42">🎖️ <b>Mayor</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

The Mayor receives extra votes. The Mayor may also get a Portable Meeting Button.
* Max
  * Set the Maximum amount of Mayors that can be in a match
* Additional Votes Count
  * Set how many extra votes a Mayor gets
* Mayor has a Mobile Emergency Button
  * <font color=green>ON</font>: the Mayor may vent to call a meeting
  * <font color=red>OFF</font>: the Mayor cannot call meetings except by calling a button normally
* Max Number of Mobile Emergency Buttons
  * Set how many Emergency Meetings a Mayor can Vent to Call
* Hide additional vote(s)
  * <font color=green>ON</font>: the Mayor's extra votes will show up as nothing
  * <font color=red>OFF</font>: the Mayor's extra votes will show up as normal votes
* Mayor is revealed to everyone on task completion
  * <font color=green>ON</font>: the Mayor will be revealed to everyone at the beginning of the game
  * <font color=red>OFF</font>: the Mayor will not be revealed to anyone at the beginning of the game
* Override Mayor's Tasks
  * <font color=green>ON</font>: you can set a different amount of Tasks that a Mayor needs to do
    * Mayor has Common Tasks
      * Set if the Mayor has Common Tasks
    * Amount of Long Tasks for Mayor
      * Set the amount of Long Tasks the Mayor will receive
    * Amount of Short Tasks for Mayor
      * Set the amount of Short Tasks the Mayor will receive
  * <font color=red>OFF</font>: the Mayor does the same amount of Tasks as anyone else

> From: Town of Us: Reactivated

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
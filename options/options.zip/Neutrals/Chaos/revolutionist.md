---
lang: en-US
title: Revolutionist
prev: Pirate
next: Solsticer
---

# <font color=#ba4d06>🚨 <b>Revolutionist</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

Revolutionist can recruit players by clicking the kill button on the player and following them for a few seconds. When they start recruiting and the recruiting is successful, a shield animation will be displayed as a reminder (only visible to the Revolutionist). Players have a chance of being killed immediately after being recruited (the host sets the probability). When the specified number of players are recruited (the number is set by the host) and they vent within the specified time, the Revolutionist and all the players who are recruited win; if not, the recruited player dies; if the Revolutionist is killed during the countdown, nothing happens; if a meeting is held, the Revolutionist dies. Note: Players who died after being recruited can still win with the Revolutionist.

If the player name displays 「○」, it means that they are being recruited;

If the player name displays 「●」, it means they have been recruited.
* Max
  * Set the Maximum amount of Revolutionists that can be in a match
* Tag Duration
  * Set how long a Revolutionist needs to stand with someone to Tag them
* Tag Cooldown
  * Set how long a Revolutionist needs to wait to Tag someone
* Amount of Players needed to Tag
  * Set how many players a Revolutionist needs to Tag to win
* Tagged player sacrifice probability
  * Set the percentage a Tagged player will Suicide once they get Tagged
* Time to Vent
  * Set how long a Revolutionist has to Vent.

> From: [波奇酱](#) & Coding: [NCSIMON](https://github.com/NCSIMON)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"For too long we have been suppressed by Mr. sloth"
"Aye"
"Aye"
"For too long have we been pushed away from the better roles"
"True"

Now it was time to plan...
The revolutionist needed allies 
How to recruit them though...

Well first of all he needed to talk to them so he would need to interact with them and follow them for a minute

But it could be too overwhelming and the recruit could die

But the dead recruit could still support because they could at least sign the petition...

But as he was doing that people started growing suspicious of him and his activities and thus he...

was thrown into lava...

Mr. Sloth is too powerful to take down...
The end

> Submitted by: champofchamps78
</details>
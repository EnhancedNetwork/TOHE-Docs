---
lang: en-US
title: Marshall
prev: Lookout
next: Mayor
---

# <font color="#5573aa">🤴 <b>Marshall</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

If the Marshall completes all of their tasks, they will be revealed to the Crew. (Including Madmates/etc). Non-Crew teams will not be able to see the Marshall.
* Max
  * Set the Maximum amount of Marshalls that can be in a match
* Override Marshall’s Tasks
  * <font color=green>ON</font>: the Marshall will not have the same tasks as everyone else
    * Marshall has Common Tasks
      * <font color=green>ON</font>: the Marshall will have to do Common Tasks like everyone else
      * <font color=red>OFF</font>: the Marshall doesn’t receive Common Tasks
    * Amount of Long Tasks for Marshall
      * Set how many Long Tasks the Marshall has to do
    * Amount of Short Tasks for Marshall
      * Set how many Short Tasks the Marshall has to do
  * <font color=red>OFF</font>: the Marshall will have the same tasks as everyone else

> From: TOH+

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
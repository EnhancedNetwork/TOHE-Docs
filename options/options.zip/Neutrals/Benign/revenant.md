---
lang: en-US
title: Revenant
prev: Pursuer
next: Romantic
---

# <font color="#a37621">👻 <b>Revenant</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As the Revenant, your goal is to be killed. If you
are killed, you will take your killer's role and kill your killer instead. You cannot win before being killed.
Note that Revenant only works when being directly killed.

* Max
  * Set the Maximum amount of Revenants that can be in a match

> Idea & Coding: LimeAU

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Nada
</details>
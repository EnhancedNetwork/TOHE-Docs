---
lang: en-US
title: Tracefinder
prev: TaskManager
next: Transporter
---

# <font color="#0066cc">👣 <b>Tracefinder</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

Access to Vitals, and receive Arrows pointing to dead bodies.
* Max
  * Set the Maximum amount of Tracefinders that can be in a match
* Vitals Cooldown
  * Set long the Tracefinder has to wait to use check their Mobile Vitals
* Vitals Duration
  * Set how long the Tracefinder can check their Mobile Vitals for
* Minimum Arrow show-up delay
  * Set how long the arrows will take to appear
* Maximum Arrow show-up delay
  * Set how long the arrows could take to appear
  
> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
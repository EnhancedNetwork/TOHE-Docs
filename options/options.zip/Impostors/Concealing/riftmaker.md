---
lang: en-US
title: Rift Maker
prev: Puppeteer
next: Scavenger
---

# <font color="red">☄️ <b>Rift Maker</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

As Rift Maker you can shapeshift to create a rift. You can teleport from one rift to another by touching the area where the rift was created. Trying to vent will kick you out and all the rifts will be destroyed.<br><br>

Note: Up to two rifts can be placed at a time, if you try to place a third, it removes the first one.

* This page is not yet completed! Sorry for the inconvience!
  * This page still needs: Settings.

> From: EHR

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

One day, Rick was tampering with one of his portals. He knew he was quite the genius, but he never expected what a rotten day was about to unfold.

Accidentally, he teleported into Among Us, where a crazy killing machine stepped over his gun. What could he do now?

One thing: disguise himself as a crewmate and then go to Mira HQ to get the materials for a rift maker.

After all that, he went to Mira HQ and acquired his ray gun. Unfortunately, there was an Imp right outside the deco chamber. Fortunately, Rick had a knife, and he wasn't afraid to kill either.

SLASH! went Rick, killing the impostor in one strike.

BUT WAIT! It wasn't an Imp... it was the Sheriff! Rick had just gone to the dark side!

Rick became addicted to killing—so addicted that he even said, "I no longer dream, only nightmares of those who've died." But he couldn't stop now.

He used his ray gun to teleport all around the map, leaving a trail of bodies.

He was never caught.
> Submitted by: champofchamps78
</details>
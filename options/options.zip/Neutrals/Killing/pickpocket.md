---
lang: en-US
title: Pickpocket
prev: Pelican
next: PlagueScientist
---

# <font color="#47008b">👤 <b>Pickpocket</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Pickpocket, you steal votes from your kills.<br>
These votes are hidden.<br>
Kill everyone to win.
* Kill Cooldown
  * Set how long a Pickpocket has to wait to Kill (and steal votes)
* Can Vent
  * <font color=green>ON</font>: the Pickpocket can Vent
  * <font color=red>OFF</font>: the Pickpocket cannot Vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Pickpocket can see as far as an <font color=red>Impostor</font> can
  * <font color=red>OFF</font>: the Pickpocket will have <font color=#8cffff>Crewmate</font> Vision
* Votes gained for each kill
  * Set how much the Pickpockets votes increase after a kill (0.1 vote increments)

> From: Project Lotus & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
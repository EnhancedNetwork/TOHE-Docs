---
lang: en-US
title: Taskinator
prev: Shaman
next: Troller
---

# <font color="#4233a2">📑 <b>Taskinator</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As the Taskinator, whenever you complete a task, the task will be bombed. When another player completes the bombed task, the bomb will detonate and the player will die.<br><br>
You win if you survive till the end and Crew doesn't win.<br><br>
Note: Taskinator bombs ignore all protection.
* Max
  * Set the Maximum amount of Taskinators that can be in a match 
* Number of tasks that can be bombed in one round
  * Set the amount of tasks that the Taskinator can bomb in one round
* Override Taskinator’s Tasks
  * <font color=green>ON</font>: you can set a different amount of Tasks that a Taskinator needs to do
  * <font color=red>OFF</font>: the Taskinator does the same amount of Tasks as anyone else
    * Taskinator has Common Tasks
      * Set if the Taskinator has Common Tasks
    * Amount of Long Tasks for Taskinator
      * Set the amount of Long Tasks the Taskinator will receive
    * Amount of Short Tasks for Taskinator 
      * Set the amount of Short Tasks the Taskinator will receive

> Idea: [Dx] & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“And boom we’re back”
 
He was just a nerd nothing more nothing less he was just used to help them so they don’t fail, he didn’t mind he just really need someone with him even if they don’t really noticed him, all he wants is just to belong
It didn’t got better for him when highschool was done now he’s deed for them is done they don’t really need his service any more and just left him, He got hired for a job and there he had almost nothing to do it always the same, wake up eat go to work repeat, he was portrayed by his co-workers as a Grinch, maybe don’t talk like that when he’s near you
While in missions he didn’t really talk to anyone he mostly just do he’s task and after that hang out in admin and while in there he began to over analyze all of the task knowing their value, how they work, his co-workers didn’t really like to their tasks so he mostly do all of them for them but after a month he snapped and wanted to take some revenge, He made them a bet if they can do just one task each before he could do 12 task he would do their task for a while year
They accepted but little did they know in each of their task there would be a surprised, either the wires electrifying them, the scan having harmful rays, or the admin table just exploding after you swipe your card
You see this wasn’t an ordinary bet he rigged all the task and he wanted to make the crewmates pay he doesn’t care if anyone else won he’s only goal is to punished the laziness of the crew, and after that day he was born

> Submitted by: Pikmin 6(No.1TrickJestershipper)
</details>
---
lang: en-US
title: Vigilante
prev: Veteran
next: /options/Settings/Crewmates.html
---

# <font color="#9304c1">🤺 <b>Vigilante</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

The Vigilante is tasked with eliminating potential threats to the crew, but if they mistakenly kill an innocent Crewmate, they become a Madmate driven by guilt and remorse. <br>
Note: Gangster can not convert Vigilante into madmate.
* Max
  * Set the Maximum amount of Vigilantes that can be in a match
* Kill Cooldown
  * Set how long the Vigilante has to wait to Kill

> From: SLE (Mercenary)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Mimic
prev: Mare
next: Stealer
---

# <font color=red>👥 <b>Mimic</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

Only <font color=red>Impostor</font> can become Mimic. When the Mimic is dead, other <font color=red>Impostors</font> will receive a message once a meeting is called, this message will include information on roles who were killed by the Mimic.
* Max
  * Set the Maximum amount of Mimics that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Mimic
* Mimic can see the roles of dead players
  * <font color=green>ON</font>: Mimic can see the roles of dead players
  * <font color=red>OFF</font>: Mimic cannot see the roles of dead players

> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
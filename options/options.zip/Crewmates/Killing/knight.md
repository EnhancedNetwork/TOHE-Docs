---
lang: en-US
title: Knight
prev: Judge
next: NiceGuesser
---

# <font color="#7a7a7a">⚔️ <b>Knight</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

The Knight has no tasks. They can kill any person but they can only do it once the whole game.
* Max
  * Set the Maximum amount of Knight that can be in a match
* Kill Cooldown
  * Set how long the Knight needs to wait to kill
* Can Vent
  * <font color=green>ON</font>: the Knight can Vent
  * <font color=red>OFF</font>: the Knight cannot Vent

<center>

[<font color="#e2acb5">Requiter</font>](./Requiter.html)
</center>

> From: Goose Goose Duck & Coding: [Commandf1](https://github.com/commandf1)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
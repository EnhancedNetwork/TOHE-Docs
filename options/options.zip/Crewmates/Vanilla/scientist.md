---
lang: en-US
title: Scientist
prev: Noisemaker
next: Tracker
---

# <font color="#8ee98e">🔬 <b>Scientist</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Scientist, you have a portable tablet with the crew's vitals on it.<br>
Use this any way you'd like.<br>
Catching self-reports, extra intel on body age, etc.
* Max
  * Set the Maximum amount of Scientists that can be in a match
* Vitals Cooldown
  * Set how long the Scientist has to wait to use Vitals
* Vitals Duration
  * Set how long the Scientist can use Vitals for at a time

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
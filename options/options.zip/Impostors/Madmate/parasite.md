---
lang: en-US
title: Parasite
prev: Crewpostor
next: Refugee
---

# <font color="red">🦠 <b>Parasite</b></font> <Badge text="Madmate" type="tip" vertical="middle"/>
---

The Parasite doesn’t know the Other Impostors, and the Other <font color=red>Impostors</font> don’t know the Parasite. However the Parasite still wins with Impostors, and acts like a normal <font color=red>Impostor</font> in every way.
* Max
  * Set the Maximum amount of Parasites that can be in a match

> From: TOH+

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The parasite was always just… Living sort of not doing anything purposeful or anything he would waste his time and keep wasting it despite several warning from his parents and his friends he just replied “Yea I’ll just Leech of one of my friends” He was heading towards being a parasite… Quite literally.. But no one was willing to help the Parasite.. Well… If you wont do it willingly do it unwillingly said the parasite as he killed and robbed him but even after killing the Impostors did not want to associate with the parasite they were too embarrassed and also… They did not want to support a do nothing person So the Impostors didn’t let the Parasite know who they were but … Neither did the crewmates.. The parasite though? He associated as an Impostor only and would leech onto the Impostors if they would win… Now killing for money will go on And it did.. The parasite kept killing and killing and he even killed.. An Impostor.. Horrible But that is the life he chose for.. The.. End?
> Submitted by: champofchamps78
</details>
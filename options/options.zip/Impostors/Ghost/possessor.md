---
lang: en-US
title: Possessor
prev: Minion
next: /options/Settings/Impostors.html
---

# <font color="red">🎭 <b>Possessor</b></font> <Badge text="Ghost" type="tip" vertical="middle"/>
---

As the Possessor, you are able to possess players when others aren't in the Alert Range. Lead the possessed player as far as possible from other players that are in the Focus Range. Once the possession duration is up, the possessed player will be killed if others aren't in the Focus Range. If you run into another player in the Alert Range while possessing, the Possessor will immediately unpossess.

* Possession Cooldown
  * Set how long the Possessor has to wait to use their ability
* Possession Duration
  * Set how long the Possessor's ability lasts for
* Alert Range
  * Set the Alert Range that will cause the Possessor to lose possession if they are within it
* Focus Range
  * Set the Focus Range that will not allow the Possessor to kill players in if they are within it

> Idea & Coding: [D1GQ]

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"It's Alive! It's Alive" "No you moron he's dead" "I knew that" Great minds think alike... One of them isnt great though .. Bro killed a crewmate and yelled it's alive like a mad scientist... Pretty cool way to begin a story though... The Bandit killed and killed all Infront of his lawyer but... He didn't know that his crimes would come back... Not at him but at his only friend... The lawyer When killing the bean the bandit was merciless making the bean Suffer and suffer and the last words of the bean were "I will make you feel pain and loss" The Bandit laughed it off like some petty joke and stabbed the heart of the bean... Now the bean knew one thing.. He needed to break up the lawyer and the Bandit's group once and for all But how? Well he knew one thing... he could hypnotize the lawyer and lead him astray from his path... Interesting and all he needed was a spiral :hmmm: And hypnotize is what he did but what he didnt know was that when he lead the lawyer so far off he was able to convince the lawyer to kill himself :joe_think: Interesting indeed... Now the possessor (This is what the bean wants to be called) killed the lawyer the bandit was caught off guard and killed by the butcher... A great fate for a merciless killer Is it not! But continuing this the possessor noticed one thing if there were crewmates around the possessed bean... They could jolt him and wake him up... Saving him Shoot I guess that strategy isnt full proof eh? But still... Winnable >:D
> Submitted by: champofchamps78
</details>
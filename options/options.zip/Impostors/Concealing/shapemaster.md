---
lang: en-US
title: Shapemaster
prev: Scavenger
next: SoulCatcher
---

# <font color="red">👥 <b>Shapemaster</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

The Shapemaster has no Shapeshift Cooldown, but they Unshift earlier than normal.
* Max
  * Set the Maximum amount of Shapemasters that can be in a match
* Shapeshift Duration
  * Set how long the Shapemaster stays Shapeshifted for

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The ShapeMaster was once a tailor—a quite good one at that.

One day, while traveling to the Airship, where there were a lot of tasks to be done as they had just discovered a new planet called Fungle, he noticed two people muttering to each other about how they were going to sabotage the crew. His interest was piqued, and he couldn’t help but ask them about their plan.

They mentioned that one person was missing and offered him the opportunity to join them.

And wouldn’t he? Yes, yes, he would. The tailor began to think of a new idea.

What if he made costumes that looked like the other crew members? These costumes would be hella fun and easy to use.

He could easily frame many people—and in the end, he could win and sabotage the crew.

The plan was successful, and the Impostors were the last ones standing.

But then the plan went horribly wrong. There was nothing in the job offer that stated “Guaranteed Death,” even in victory. Oh man, what could he do now?

The ship was crashing, and the other Impostors just closed their eyes and accepted their fate. What a gruesome death.

But the tailor wouldn’t give up so easily. Oh no. When they were about to crash, the tailor surrounded himself with protection and survived! Whoo!

He took a dead scientist's tablet and waited for the ship to crash.

When the ship did crash, he was the lone survivor. He took the dead bodies out and started drinking their blood. It was his only source of nutrition, and soon he became addicted. But that’s a story for another time.

Just know that even tailors can be the biggest of villains if they know what they are doing.
> Submitted by: champofchamps78
</details>
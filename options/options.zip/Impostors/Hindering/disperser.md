---
lang: en-US
title: Disperser
prev: Devourer
next: Eraser
---

# <font color=red>🌀 <b>Disperser</b></font> <Badge text="Hindering" type="tip" vertical="middle"/>
---

Disperser can use Shapeshift to teleport all players to random vents.<br><br>
Note: the Disperser itself will not be teleported with shapeshift and players who are in the vent cannot be teleported.
* Max
  * Set the Maximum amount of Dispersers that can be in a match
* Shapeshift Cooldown
  * Set how long the Disperser has to wait to use Shapeshift
* Shapeshift Duration
  * Set how long the Disperser can use Shapeshift for

> From: ToUR

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Every where the disperser went he saw friends, family, People united and having fun well.. The disperser was annoyed... Chapter 1 I cant even kill Due to his friendship with Mr. Sloth he was promoted from a crewmate to an Impostor but he faced many... Challenges Since everyone was in a group be it Neutral Apocalypse with their own team, Lovers, Followers or a cult People just wouldn't be solo and found off guard It was so frustrating and Maybe even Impossible to kill Unless Chapter 2 You won the battle, I win the War Now the Disperser went to his best friend the Mad scientist (Really, Him Again?) The Mad scientist was known to make ideas come to reality and this was going to be just another one of those cases The Disperser told about his plan that when he shapeshifts everyone would be randomly transported but how? Well there are many fruits found on fungus which contain Properties Of transportation The Mad scientist went on and brought those fruits now... Chapter 3 Rain down In the dropship while going to Mira HQ from Polus the Disperser poured the fruits on unsuspecting crewmates and went on to infect them with the transporter Virus... Chapter 4 Privacy Not to turn on this virus and randomly teleport people the Button was to be pressed but there was one catch, The button required the warmth of a shell of an egg mainly it required the Disperser to shapeshift But wait... what?! The Fruits were naturally made to teleport to vents... Now This was all fine and the disperser went on to break the bonds of people and kill every single crewmate in existence which was grouping with others Finally... Revenge Chapter 5 Impostor games Now the annual impostor games was going on and the disperser went there Participating the disperser randomly teleported everyone which caused confusion and chaos ensuring him to easily get the win against all Odds The New King Impostor
For Now :)
The End

> Submitted by: champofchamps78
</details>
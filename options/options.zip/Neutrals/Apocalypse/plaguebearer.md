---
lang: en-US
title: Plaguebearer
prev: Berserker
next: SoulCollector
---

# <font color="#e5f6b4">🦠 <b>Plaguebearer</b></font> <Badge text="Apocalypse" type="tip" vertical="middle"/>
---

Plague everyone using your kill button to turn into Pestilence. Once you turn into Pestilence you will become immortal and gain the ability to kill.<br>
In addition to this, after turning into Pestilence you will kill anyone who tries to kill you.<br><br>
You win by killing everyone.

* Plague Cooldown
  * Set how long the Plaguebearer has to wait to plague a player
* Pestilence Kill Cooldown
  * Set how long a Pestilence has to wait to Kill
* Pestilence Can Vent
  * <font color=green>ON</font>: Pestilence can vent
  * <font color=red>OFF</font>: Pestilence cannot vent
* Pestilence has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Pestilence can see as far as an <font color=red>Impostor</font> can
  * <font color=red>OFF</font>: the Pestilence will have <font color=#8cffff>Crewmate</font> Vision

<center>

[<font color="#343136">Pestilence</font>](./Pestilence.html)
</center>

> From: ToUR & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The plague bearer was a curious person who would even go to the extent he would experiment on his own body and it went.. Wrong..
 
The plague bearer made such a virus that only he had its cure and could even transfer by touch.. and interaction
And that made the person weak..
They couldn't kill the strong uninfected people..
 
And he went on and started interacting with people
But this went far better than he thought.. He realised that if the infected people touched/interacted with unifected too they would be infected...
 
Wow..
Curiosity got the best of everyone..
Always be curious
 
Back to story..
 
"AAAHH" He screamed in pain as after infecting everyone he drank the anti dote... It was painful recovering from the virus..
Very Painful..
 
But now he was invulnerable to infected crewmates...
Except for ejection and Space..
 
And.. In the war of 1888 this was...
The Turning wave..
 
"AAAAAAAAAAAAAH" He screamed in agony...
To be continued
Stay tuned in
> Submitted by: champofchamps78
</details>
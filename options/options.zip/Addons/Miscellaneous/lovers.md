---
lang: en-US
title: Lovers
prev: Egoist
next: Rainbow
---

# <font color=#ff9ace>💞 <b>Lovers</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

Lovers are a combination of two players. The Lovers wins when only the Lovers is left. When one of the Lovers wins, the other also wins together. Lovers can see the 「♡」 mark next to each other's name. If one of the Lovers dies, the other will die in love (may not die in love according to the host's settings). When one of the Lovers is exiled in the meeting, the other will die and become a dead body that cannot be reported.
* Spawn Chance
  * Set the percentage players have of getting Lovers
* Lovers know the roles of each other
  * <font color=green>ON</font>: Lovers can see each other's roles
  * <font color=red>OFF</font>: Lovers cannot see each other's roles
* Lovers die together
  * <font color=green>ON</font>: A Lover will Suicide if their Lover dies
  * <font color=red>OFF</font>: Each Lover has to die separately. (If a lover is alive at the end of the match, Lovers will win)
* <font color=red>Impostors</font> can be in love
  * <font color=green>ON</font>: Impostors can become Lovers
  * <font color=red>OFF</font>: Impostors cannot become Lovers
* <font color=#7f8c8d>Neutrals</font> can be in love
  * <font color=green>ON</font>: Neutrals can become Lovers
  * <font color=red>OFF</font>: Neutrals cannot become Lovers
* <font color=#8cffff>Crewmates</font> can be in love
  * <font color=green>ON</font>: Crewmates can become Lovers
  * <font color=red>OFF</font>: Crewmates cannot become Lovers
* <font color=#ac42f2>Coven</font> can be in love
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become Lovers
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become Lovers
  
> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Lookout
prev: Guardian
next: Marshall
---

# <font color="#2a52be">🔭 <b>Lookout</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

As the Lookout, you can see the IDs of every player at all times.<br>
This allows you to see through shapeshifts and camouflages.
* Max
  * Set the Maximum amount of Lookouts that can be in a match

> Idea: [Dawson](#) & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
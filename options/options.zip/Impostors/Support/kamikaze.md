---
lang: en-US
title: Kamikaze
prev: Godfather
next: Morphling
---

# <font color="red">💥 <b>Kamikaze</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Kamikaze you can single click to mark people. Double click to kill normally. When you die all marked also die, with death reason Targeted.

* This page is not yet completed! Sorry for the inconvience!
  * This page still needs: Settings.

> Idea & Coding: [Drakos](https://github.com/Ultradragon005)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The Kamikaze was a very smart engineer who was very… Gifted in making very… Specific? (If that explains it) technology but he doesn’t have the will to live… Chapter 1 School While in school the Kamikaze was often inspired by even the smallest inventions like… Door Handles, Locks, Microwaves, etc Not Atom accelerators not laptops… But he knew if he could decode these simple amenities he could easily figure out the big bombs… Chapter 2 Trusty Screwdriver Everywhere he would go he would roam with his trusty screwdriver and open any technology even televisions and try to put them back together… This was very dangerous for normal… Average humans but not for him… One day though it all will change Chapter 3 Atoms So Let me brief it.. He found that there is a specific element called Odysseusinum which can be triggered by heat and can perform chain reactions to do specific events in a specific order and well… This gave Kamikaze an Idea… Chapter 4 I’m an Impostor? No surprise Kamikaze already knew he would become an Impostor no new news there but how will he utilise this… well.. He could plant bombs on everyone’s body since he was very swift with his movement he could do it… Chapter 5 What now? Since his bombs are powered by Odysseusinum so he needed to heat at least a VERY LARGE amount of Odysseusinum but they would evaporate mid air if he dropped It into the lava so… He had to drop with them… Great!! Chapter 6 You all are fools! As the Kamikaze was thrown into the lava by the crewmates as he faked a task he started a chain reaction and all the crewmates with bombs utilizing Odysseusinum were BLOWN up and died… Mass Murder 101! The End? Of course! There's no coming back from lava Duh
> Submitted by: champofchamps78
</details>
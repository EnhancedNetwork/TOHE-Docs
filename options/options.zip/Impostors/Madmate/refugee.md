---
lang: en-US
title: Refugee
prev: Parasite
next: /options/Settings/Impostors.html
---

# <font color="red">🗡️ <b>Refugee</b></font> <Badge text="Madmate" type="tip" vertical="middle"/>
---

As the Refugee, you were either an Amnesiac who remembered an Impostor, or a killer who killed the Godfather's target.<br><br>

Now your job is to help the Impostors kill the crewmates.
* Can only appear if Godfather/Amnesiac are enabled (as the description implies).

> From: TOHER

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Not many Might remember the case Of Perimedes from The Greek Mythology… But the refugee? Well… It was a similar case Like Perimedes… The Refugee was happy and content on Fungle… Until the Flowers started to give out so much aroma that it started to choke everyone… People started dropping into Campfires… Off the Zip but well.. The Refugee had to leave… Now He took a boat and sailed to an Island.. As Frequent readers may know as The Island The one where the plane crashed or where the Butcher first came up… Yes.. The Refugee saw it all go down But didn’t have the courage to go and sneak into the ship until… He was too hungry and approached the butcher who was for obvious reasons unafraid (Reason : The Butcher was carrying a gun and a knife Himself ) Now the butcher gave him food and invited him onboard… Interesting they did not seem to murder the Refugee.. Maybe they liked him What if.. He became an Impostor So he went up to their leader the “God Father” who gave him a simple task ( Simple for the god father ) To Kill a target… There were only 2 ways to become an Impostor… To first forget then Remember… Not possible right now Or to kill the God Fathers Target… Possible And so he did Kill… And became the refugee into the god fathers mansion and the latest edition to the Impostor clan of POLUS…
What if the Volcano Erupted would the refugee need to take refuge again
> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Rainbow
prev: Lovers
next: Reach
---

# <font color=#80ffdd>🌈 <b>Rainbow</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

As the Rainbow, you change your colors like crazy.
* Max
  * Set the Maximum amount of Rainbows that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Rainbow
* <font color=red>Impostors</font> can become Rainbow
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Rainbow
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Rainbow
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Rainbow
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* Cooldown for changing colors
  * Set how often the Rainbow will change colors
* Rainbow color changes during Camouflage
  * <font color=green>ON</font>: The Rainbow will change colors even if Camouflage is active
  * <font color=red>OFF</font>: The Rainbow will not change colors if Camouflage is active

> From: [Gurge44](#) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
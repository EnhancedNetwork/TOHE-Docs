---
lang: en-US
title: War
prev: Berserker
next: Berserker
---

# <font color=#2b0804>⚔️ <b>War</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

As War, you are invincible, have a lower kill cooldown, and can kill anyone with your
previous powers.<br>
Your presence is announced to everyone at the meeting after you transform.

> From: Marg

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

"AAAAAAAAAAAH" Continuing from ⁠Berserker
What's.. Happening?
 
As a tentacle flew out from the visor.. The visor cracker.. A screech of pain and terror in the whole ship..
Blood around the Berserker..
 
And a roar filled the Lungs of the Berserker and he let it out.. The entire ship shook and tilted...
What was that? They all wondered...
 
As an announcement was revealed
 
"A war has been started take your stations"
The whole time the crewmates were divided into factions and groups for friends now? The divide grew larger
 
People manned cannons took guns and...
 
And thus The war of 1888 began.. Thousands of causalities and our berserker? He was fighting both sides.. Killing everyone as they killed each other..
 
In the end the Berserker converted to war was found and ejected saving the crew...
 
But at what cost? They all lost friends and family
They lost loved ones...
 
War... Was this what we needed?

> Submitted by: burgerman7286
</details>
---
lang: en-US
title: Dazzler
prev: Anonymous
next: Devourer
---

# <font color="red">🎇 <b>Dazzler</b></font> <Badge text="Hindering" type="tip" vertical="middle"/>
---

The Dazzler can Shapeshift into players to reduce their vision permanently, if you die their vision returns to normal.
* Max 
  * Set the Maximum amount of Dazzlers that can be in a match
* Kill Cooldown
  * Set how long the Dazzler needs to wait to Kill
* Dazzle Cooldown
  * Set how long the Dazzler needs to wait to Dazzle again
* Reduced vision
  * Set how much vision the Dazzler will reduce from the player they Dazzle
* Max number of players affected by reduced vision
  * Set the Maximum amount of players that can be affected by the Dazzlers reduced vision
* Reset vision of dazzled players on death/eject
  * <font color=green>ON</font>: the players that were Dazzled will have their vision returned to normal if the Dazzler dies or is ejected
  * <font color=red>OFF</font>: the players that were Dazzled will NOT have their vision remain reduced if the Dazzler dies or is ejected

> From: Idea & Coding: [papercut](https://github.com/lars-wu)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The Dazzler was earlier a very famous cameraman but expectedly he got extremely bored with his profession, Knowing this was the only thing he was good at he went to Mr. Sloth to express his Concerns Chapter 1 Mr. Sloth As expected with nothing better to do the Dazzler was promoted to an Impostor, A murderous ravaging Impostor... Now this would be extremely boring for a role so The Dazzler was given 2 days to decide about his ability and failing to do so will get him executed Chapter 2 Deeply thinking Now the Problem was that most of the cool aiding roles were already taken by other Impostors so he needed to be a hindering Impostor Now what ability... While thinking a customer came in for a photoshoot and well this would give him a great Idea Chapter 3 Get that camera out of my face Now during the photoshoot the Dazzler had somehow configured the Camera to shine super bright now.. This was super harmful for the eyes but could be easily fixed by some treatment but now this gave the Dazzler an Idea as soon as the customer yelled "Ey Get that camera out of me Face you Idiota" Chapter 4 Shiny Egg Now the idea was that The egg of the shapeshifter could be loaded up with Powerful cameras and lights thus blinding the intended target and this worked like a charm!! Game after game the crewmates were dropping like Ripe fruit and couldnt see anything like a Halloween event, A spooky game for them and in the end they were all gruesomely slain Chapter 5 Impressive Impressed by this Mr. Sloth made Dazzler a role and the bean an Impostor all is well that ends well eh :) From a camera man not ever recognized by others to one of the best Impostors out for blood and More blood The End

> Submitted by: champofchamps78
</details>
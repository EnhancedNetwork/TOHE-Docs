---
lang: en-US
title: Doctor
prev: Cleanser
next: GuessMaster
---

# <font color="#80ffdd">👨‍⚕️ <b>Doctor</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

Doctor can see cause of death for all players. They also have access to Mobile Vitals like a scientist.
* Max
  * Set the Maximum amount of Doctors that can be in a match
* Battery Duration
  * Set how long the Doctor can have Vitals up for
* Everyone knows who the Doctor is
  * <font color=green>ON</font>: the Doctor is revealed
  * <font color=red>OFF</font>: the Doctor will not be revealed

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
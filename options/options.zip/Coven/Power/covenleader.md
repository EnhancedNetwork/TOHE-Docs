---
lang: en-US
title: Coven Leader
prev: /options/Settings/Coven.html
next: Ritualist
---

# <font color="#ac42f2">🧙‍♀️ <b>Coven Leader</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

The Coven Leader can use their kill button on a fellow Coven member to retrain them into a random Coven role that isn’t currently in the game. During the next meeting, that Coven member will be notified that the Coven Leader wishes to retrain them. They can vote themselves to accept the retrain, or vote otherwise to deny it. Denying the retrain does not take away an ability usage.<br><b>With the Necronomicon, you cannot retrain, and can only kill other players.</b>
* Max Retrains
  * Maximum amount of times the Coven Leader can use their ability in a game
* Retrain Cooldown
  * Set how long the Coven Leader needs to wait to use their Ability

> Idea & Coding: [Marg](https://github.com/MargaretTheFool)


<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: God
prev: Collector
next: Pirate
---

# <font color=#f96464>🏺 <b>God</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

God knows everyone's role from the beginning, and God will win alone as long as he lives to the end. Note: God won't be Lovers.
* Max
  * Set the Maximum amount of Gods that can be in a match.
* Inform players at meetings that God is still alive
  * <font color=green>ON</font>: it will be announced that God is Alive, if God is alive
  * <font color=red>OFF</font>: players will have no idea about God
* Can Guess in Guesser Mode
  * <font color=green>ON</font>: God can Guess people in Guesser Mode <b>(easy way to quickly win, it’s overpowered/broken)</b>
  * <font color=red>OFF</font>: God cannot Guess, even when Guesser Mode is enabled

> From: SNR & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Now the god was not actually god…
Pretty confusing right?
Well if he was god he would just win every game..
Which he did not…
He had successful games but losses to

Now when he died by the serial killer it was his last life…
Now he saw God and he asked..
Where did I go wrong
“No where”
So how could he redeem himself?

Well by being a missionary and carrying the idea of peace and no violence to the beans..
Bu being their god..

But by doing that god also gave him powers to steal wins and know roles..
But the catch? He can’t kill
He can’t guess
Only forced to kill…

Well the crew mates found it extremely irritating for god stealing their wins
They tried to find god

Now god was very… overwhelmed by the spotlight so he kept announcing in every meeting there was a god to remove some of the blames from him
But now he was accused

And ejected
And he died

No second chances…

The end!

> Submitted by: Neptune
</details>
---
lang: en-US
title: Deputy
prev: Coroner
next: Detective
---

# <font color="#df9026">👮‍♂️ <b>Deputy</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

Reset a players kill cooldown by using your kill button on them. If target has no kill button, then the ability was a waste.
* Max
  * Set the Maximum amount of Deputies that can be in a match
* Handcuff Cooldown
  * Set the time a Deputy has to wait to use their Ability
* Kill Cooldown for handcuffed player
  * Set the Kill Cooldown that Handcuffed players have once a Deputy interacts with them
* Maximum Handcuffs
  * Set the Maximum amount of Ability Uses a Deputy has

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
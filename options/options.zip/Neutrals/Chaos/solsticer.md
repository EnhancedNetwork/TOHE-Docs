---
lang: en-US
title: Solsticer
prev: Revolutionist
next: Specter
---

# <font color=#f2f17e>🌟 <b>Solsticer</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

As the Solsticer, you won't die, and you win by finishing all your tasks in a single round. After every meeting is finished, your tasks get reset, and you need to start all over again.<br>
Votes on the Solsticer will be directly cancelled.<br>
Kill attempts on the Solsticer will teleport it out of the map like Pelican until the meeting is finished.<br>
The killer's kill cooldown will be reset to 10 seconds.
* Everyone knows who Solsticer is
  * <font color=green>ON</font>: Players will know the Solsticer
  * <font color=red>OFF</font>: Players will not know the Solsticer
* Solsticer knows the role of whom used their kill button on it
  * <font color=green>ON</font>: Solsticer will know the role of the player that attempted to use their kill button on it
  * <font color=red>OFF</font>: Solsticer will not know the role of the player that attempted to use their kill button on it
* Can Vent
  * <font color=green>ON</font>: Solsticer can vent
  * <font color=red>OFF</font>: Solsticer cannot vent
* Can Guess in Guesser Mode/as Guesser add-on
  * <font color=green>ON</font>: Solsticer can guess as Guesser or in Guesser Mode
  * <font color=red>OFF</font>: Solsticer cannot guess as Guesser or in Guesser Mode
* Movement Speed of Solsticer
 * Set the Speed of which the Solsticer will walk at
* Remaining Tasks to be known
 * Set how many tasks remaining that the Solsticer will be revealed at
* How many extra short tasks Solticer gets when a player dies
 * Set how many short tasks the Solsticer will get when a player dies
* Override Solsticer’s Tasks
  * <font color=green>ON</font>: the Solsticer will not have the same tasks as everyone else
    * Solsticer has Common Tasks
      * <font color=green>ON</font>: the Solsticer will have to do Common Tasks like everyone else
      * <font color=red>OFF</font>: the Solsticer doesn’t receive Common Tasks
    * Amount of Long Tasks for Solsticer
      * Set how many Long Tasks the Solsticer has to do
    * Amount of Short Tasks for Solsticer
      * Set how many Short Tasks the Solsticer has to do
  * <font color=red>OFF</font>: the Solsticer will have the same tasks as everyone else

> Idea & Coding: [NikoCat233](https://github.com/NikoCat233)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Are your serious?
Well the terrorist former Specter was again revived since he technically won
So Mr sloths team revived him 
Now he knew what he had to do…
Loose.
But how?
Well there was a new role released that relied upon tasks.
The solsticer.
Now his main aim is to do tasks in a certain round and win
But if he sees dead bodies his number of tasks Increase because he wants to remember the dead crew as a cherished memory
And if a meeting is called
He forgets his tasks because he has poor memory…

So he needs to do a certain amount of tasks together in a round
But the solsticer in this game just stayed still…
And the impostors can’t kill solsticer so they just ignored him

As the last round approached people were vent camping so the solsticer speedran 9 tasks..
And won

Dang it.
His competitive nature got the best of him

The End

> Submitted by: champofchamps78
</details>
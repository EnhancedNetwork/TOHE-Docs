---
lang: en-US
title: Cyber
prev: Burst
next: Eavesdropper
---

# <font color=#f46f4e>📸 <b>Cyber</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

As the Cyber, you cannot be killed while in a group.<br><br>
Additionally, your death will be known.
* Max
  * Set the Maximum amount of Cybers that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Cyber
* <font color=red>Impostors</font> can become Cyber
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Cyber
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Cyber
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Cyber
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
* <font color=red>Impostors</font> know when the Cyber dies
  * <font color=green>ON</font>: <font color=red>Impostors</font> can see the kill flash of when the Cyber dies
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot tell when a Cyber gets killed
* <font color=#8cffff>Crewmates</font> know when the Cyber dies
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can see the kill flash of when the Cyber dies
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot tell when a Cyber gets killed
* <font color=#7f8c8d>Neutrals</font> know when the Cyber dies
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can see the kill flash of when the Cyber dies
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot tell when a Cyber gets killed.
* <font color=#ac42f2>Coven</font> know when the Cyber dies
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can see the kill flash of when the Cyber dies
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot tell when a Cyber gets killed
* Everyone can see Cyber: 
  * <font color=green>ON</font>: a <font color=#f46f4e>orange</font> star will appear next to the Cyber’s name
  * <font color=red>OFF</font>: the Cyber remains secret

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons/)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Terrorist
prev: Specter
next: Vector
---

# <font color="#00e600">🧨 <b>Terrorist</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

If the Terrorist dies after completing all tasks, the Terrorist wins the game alone. (They can win by either being voted out or killed).
* Max
  * Set the Maximum amount of Terrorists that can be in a match
* Can Win By Suicide
  * <font color=green>ON</font>: the Terrorist can win if it somehow Suicides after finishing all Tasks
  * <font color=red>OFF</font>: the Terrorist will not win under this condition
* Can Guess in Guesser Mode
  * <font color=green>ON</font>: the Terrorist can Guess people in Guesser Mode (easy way to suicide too)
  * <font color=red>OFF</font>: the Terrorist cannot Guess, even when Guesser Mode is enabled
* Override Terrorist’s Tasks
  * <font color=green>ON</font>: you can set a different amount of Tasks that a Terrorist needs to do over the amount a normal <font color=#8cffff>Crewmate</font> has to do
  * <font color=red>OFF</font>: the Terrorist does the same amount of Tasks as anyone else
    * Terrorist has Common Tasks: Set if the Terrorist has Common Tasks
    * Amount of Long Tasks for Terrorist: Set the amount of Long Tasks the Terrorist will have to do to win
    * Amount of Short Tasks for Terrorist: Set the amount of Short Tasks the Terrorist will have to do to win
* <font color=yellow>(Hidden Role) Konan - Has a % chance to replace the Terrorist</font>
  * Apparently this role was abandoned, so like...yeah. It's just there...
    * You must have “Disable Hidden Roles” toggled <font color=red>OFF</font> for this to have a chance to appear

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“And we go boom, pull the lever and everything goes down (goes down)”
 
SC: Terrorist and update to the mission
Tr: Yeah just one more task and I said don’t call me that, call me something cool like Kamikaze,
SC: Sorry man, but I already told you there’s already someone with that name, just focus on the job don’t worry it would be alright
TR: If I find that Kamikaze I will finish them once and for all, and I’m not worried this will be the third success of the month and I’m sure I’ll be fine
 
Code name: Terrorist
Neutral # 020 Danger Level: hypothetically very high
 
Oh great it’s the Terrorist one of the best neutral out there just pure chaos I tell ya even as a little bean he already cause some damage, if you travel to Italy you could see the leaning tower of Pisa that was one chaotic vacation, he’s also banned in Italy now oopsy
 
Now he’s all grown up and still a menace to society with high wanted level don’t know why they just don’t investigate on his parents house, he didn’t really have a real job unless you count selling weaponized fart bombs as a real job but other done that he’s really just an adult that lives his parents house who sells bombs, until One day
 
While doing business with some elementary folks he suddenly got a piece of cloth in his mouth and got dragged into a white van, this is why you don’t sell fart bombs kids, when he woke up he was in a cell with someone, he was crying and was mentioning someone named The Trickster don’t know what that guy deal was, but then he was taken for questioning
 
He was in a room with a sheriff and scientist they said that he was kidnapped because he has gift, which includes determination, bravery and a comedically large amount of bombs, he was given an offer to work for them as a Terrorist basically he would be given a mission to plant some bombs is task and then  die so they can detonate the bombs inside the given place, they also said after the mission and he died they could just revived him with a experimental recovery center, he thought about it for about a minute and they gave him an offer of a lot of money for him and his parents, he accepted it and took a mask and now he’s better known as the amazing KAMIKAZE TERRORIST

> Submitted by: Pikmin 6(No.1TrickJestershipper)
</details>
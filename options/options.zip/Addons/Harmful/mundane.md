---
lang: en-US
title: Mundane
prev: Influenced
next: Oblivious
---

# <font color=#e49c4c>😪 <b>Mundane</b></font> <Badge text="Harmful" type="tip" vertical="middle"/>
---

As Mundane, you can only guess after all your tasks has been finished.
* Max
  * Set the Maximum amount of Mundane that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Mundane
* <font color=#8cffff>Crewmates</font> can become Mundane
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Mundane
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
  
> Idea: [TronAndRey](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Conjurer
prev: /options/Settings/Coven.html
next: HexMaster
---

# <font color="#451a61">🪨 <b>Conjurer</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

Shapeshift once to mark a location.<br>Shapeshift again to conjure a meteor at the place you marked, killing everyone in the radius.<br><b>With the Necronomicon, you can kill. You can also mark a player using the Shapeshift menu. When the Conjurer clicks the shapeshift button again, all the players in the radius of the marked player will die, including the marked player.</b>
* Conjure Cooldown
  * Set how long the Conjurer has to wait to use their ability
* Blast Radius
  * Set how big a meteor's blast radius is
* Necronomicon Blast Radius
  * Set how big a meteor's blast radius is with the Necronomicon
* <font color=#ac42f2>Coven</font> can die in blast
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> members can die if in radius of blast
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> members will not die if in radius of blast

> Idea: [Cristos](#) & Coding: [Marg](https://github.com/MargaretTheFool)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
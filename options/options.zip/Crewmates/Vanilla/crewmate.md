---
lang: en-US
title: Crewmate
prev: /options/Settings/Crewmates.html
next: Engineer
---

# <font color="#8cffff">👨‍✈️ <b>Crewmate</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Crewmate, your goal is quite simple. Find and exile the Impostors.<br><br>
Crewmates win by getting rid of all killers or by finishing all their tasks.
* Max
  * Set the Maximum amount of Crewmates that can be in a match

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
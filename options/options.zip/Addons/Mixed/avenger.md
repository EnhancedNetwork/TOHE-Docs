---
lang: en-US
title: Avenger
prev: Antidote
next: Aware

---

# <font color=#ffab1b>🔪 <b>Avenger</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

Host can set whether the <font color=red>Impostor</font> can become an Avenger. When the Avenger is killed (voted out and unconventional kills are not counted), the Avenger will revenge a random player.
* Max
  * Set the Maximum amount of Avengers that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Avenger
* An <font color=red>Impostor</font> can become an Avenger
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role

> From: TOHY & Coding: [NCSIMON](https://github.com/NCSIMON)、[KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
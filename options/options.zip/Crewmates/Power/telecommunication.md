---
lang: en-US
title: Telecommunication
prev: Swapper
next: /options/Settings/Crewmates.html
---

# <font color="#7223da">📡 <b>Telecommunication</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

As the Telecommunication, you are notified when anyone uses cameras, vitals, doorlogs, or admin.
* Max
  * Set the Maximum amount of Telecommunications that can be in a match
* Can track camera usage
  * <font color=green>ON</font>: the Telecommunication can track camera usage
  * <font color=red>OFF</font>: the Telecommunication cannot track camera usage
* Can Vent
  * <font color=green>ON</font>: the Telecommunication can vent
  * <font color=red>OFF</font>: the Telecommunication cannot vent

> From: TOHY & Coding: [Yumenopai](https://github.com/Yumenopai)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
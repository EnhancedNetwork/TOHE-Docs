---
lang: en-US
title: Wraith
prev: Werewolf
next: /options/Settings/Neutrals.html
---

# <font color="#4b0082">🩻 <b>Wraith</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Wraith, you can use vents to temporarily go invisible.<br>
Due to vents toggling your ability to go invisible, you cannot vent.<br>
Trying to vent while invisible will cause you to become visible again.<br>
Even when on cooldown, you cannot vent.<br><br>
Kill everyone to win.
* Vanish Cooldown
  * Set how long a Wraith needs to wait to Vanish
* Vanish Duration
  * Set how long a Wraith will stay Vanished

> From: TOHR & Coding：[KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Hater
prev: Follower
next: Lawyer
---

# <font color="#414b66">😠 <b>Hater</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As the Hater, you have no kill cooldown. However, you can only kill Lovers, and other recruiting roles/recruited add-ons, depending on the settings. Killing anyone else will make you suicide. You win at the end of the game with the winning team if none of the killable roles are alive. You will not be Lovers.
* Max
  * Set the Maximum amount of Haters that can be in a match 
* Hater kills target when misfire
  * <font color=green>ON</font>: The Hater will kill their target on misfire
  * <font color=red>OFF</font>: The Hater will not kill their target on misfire
* Select addons that Hater can kill
  * <font color=green>ON</font>: Choose addons that the Hater can kill without misfiring
    * Madmate
    * Charmed
    * Lovers
    * Jackal Team
    * Egoist
    * Infected Team
    * Virus Team
    * Admirer
  * <font color=red>OFF</font>: Don't choose addons that the Hater can kill without misfiring

> Idea: [thewhiskas27] & Coding: [NikoCat233](https://github.com/NikoCat233) (Originally From: SNR & Coding: [KARPED1EM](https://github.com/KARPED1EM))

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

 - Venus' Intervention
Prologue
From the clouds of Olympus, Venus wondered..
What chaos to upstart now..
And then she saw them...

Chapter 1 Love and Hate
Reading a book, The witch started muttering, She was clearly upset after being disregarded by her fellow crewmates..
She was left all alone..
She did hear rumors about a new ship coming to Polus
Sigh "More people to make fun of me" It was a usual scenario for her.. Every time new people came

But... This time? It was quite different

Chapter 2 Reuniting but.. Not quite
And there, She saw him... The warlock.. Going around greeting people.. Oh look in his eyes...
She felt Helpless...
Giving her motivation and making her feel like Penelope...
Was this just like when Eliza met Hamilton?
She had... So many emotions...
Roaring in her was the newfound crush she developed...

Chapter 3 I do
Now.. After a few days the warlock finally greeted the witch..
"Wow.." she though "He talked to me" As she became as red as a tomato...
And then... After months of working together.. She finally confessed and vented about her feelings..
"Oh, I did not know we had this mutual share of feelings"

Chapter 4 EW
Up there Venus was still watching... 
God of love?
Not quite... She got worked up seeing a pair that SHE had not made...
This was unholy, Impossible...
She needed to break this

And thus she asked "Perseverus"
One of her trust worthy guards to disguise as a Crewmate...
And look for lovers...

Chapter 5 NO...
As they sat, Holding hands sharing feelings and talking Persev saw them.. Sneaked up behind and...
Slashed the Warlock... Killing them

Persev was blinded with rage by Venus... He was as Hot as a Heater...
"NO" Cried The witch as her heart shattered into 2.. She dissolved and died...

Chapter 6 Good!
Venus gave Persev a permanent role to kill people who were lovers or recruited... And he did kill...
With rage... Never falling in love...

In the end.. He got all of them.. And won..
The End

> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Godfather
prev: Gangster
next: Kamikaze
---

# <font color="red">🤵 <b>Godfather</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Godfather, you vote someone to make them your target.<br>
In the next round, if someone kills the target, the killer will turn into a Refugee or Madmate depending on the host settings.
* Max
  * Set the Maximum amount of Godfathers that can be in a match
* Killer turns into
  * <font color=red>Refugee</font>: Killer will turn into Refugee.
  * <font color=red>Madmate</font>: Killer will turn into Madmate.

> Idea & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue The godfather was very smart and the head of a successful Mafia being` Filthy rich he had only one goal... To wreak havoc Chapter 1 Making of a legacy The Godfather wanted a legacy that everyone would remember being very clever and smart he made his fortune working hard Day an night while he did that he started to rage as only successful Impostors were remembered and not crewmates... You know what this means Chapter 2 Mr. Sloth Lo and behold Mr. Sloth gazed upon the godfather who was working endlessly with no breaks... He felt bad for him that no one was paying attention to the one person who was keeping Amongus Society run... He did EVERYTHING for everyone from smart inventions to charity Chapter 3 Yea, You there Mr. Sloth called out the godfather who responded immediately.... "Good News kid, I can help you get your revenge, but you have to be my pawn” “Anything, Everything to prove myself” “I, Mr. Sloth Change your fate and give you a life of killing, Do NOT disappoint me” “Sir Yes Sir” Chapter 4 But what if… I cant Kill The God father didn’t think of this… Ever he never knew that killing could be so hard until his first round… He just couldn’t. But. He had an Idea.. A great one too He does have a great fortune, What if he uses this fortune to… Bribe players Chapter 5 Kill Him for My respect and… Money Well, After the first meeting the god father targeted one of the players and the person who killed them? Would get a prize! A prize to be on the most powerful team and… Money from the god father. Win-Win scenario Doing this the Godfather increased his army and… Went on win, at an unprecedented speed… One day the God Father met a player who didn’t want to join and was loyal to his own team (Loyal Add on) this person had all the secrets of the godfather and could expose him so… The god father lunged and kill
Making Him the Gangster, A bribing and killing Impostor
> Submitted by: champofchamps78
</details>
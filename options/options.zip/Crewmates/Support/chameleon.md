---
lang: en-US
title: Chameleon
prev: Benefactor
next: Coroner
---

# <font color="#01c895">🦎 <b>Chameleon</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Chameleon, you can vent to disguise (invisible).<br>
While disguising, nobody can interact with you.<br>
Venting while disguised will reveal yourself.
* Max
  * Set the Maximum amount of Chameleons that can be in a match
* Disguise Cooldown
  * Set how long the Chameleon has to wait to disguise
* Disguise Duration
  * Set how long the Chameleon can stay disguised for
* <font color=#00ffff>Amount of Ability</font> <font color=#7fffd2>Use Gains</font> <font color=#00ffff>with Each Task Completed</font>
  * Set the amount of Ability Uses a Chameleon gains with each Task completed (0.1 increments)

> From: Project Lotus

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
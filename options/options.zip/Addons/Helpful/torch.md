---
lang: en-US
title: Torch
prev: Tiebreaker
next: Watcher
---

# <font color=#eee5be>🕯️ <b>Torch</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

Only <font color=#8cffff>Crewmates</font> will be Torch, they will have max vision and will not be affected by Lights sabotage.
* Max
  * Set the Maximum amount of Torches that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Torch
* Torch Vision
  * Set how far the Torch can see

::: tip Fun Fact
Torch was originally called "Lighter" in Build 3.0.0 Alpha 1 and was renamed to "Torch" in Build 3.0.0 Alpha 2!
:::

> From: TOH & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
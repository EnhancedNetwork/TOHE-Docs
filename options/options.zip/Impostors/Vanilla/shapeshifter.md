---
lang: en-US
title: Shapeshifter
prev: Phantom
next: /options/Settings/Impostors.html
---

# <font color="red">👥 <b>Shapeshifter</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Shapeshifter, you have a shapeshifting ability which you may use to frame other crewmates.<br>
Just be aware that there is an egg while shifting and the disguise is temporary.
* Max
  * Set the Maximum amount of Shapeshifters that can be in a match
* Shapeshift Duration
  * Set how long the Shapeshifter stays Shapeshifted for
* Shapeshift Cooldown
  * Set long the Shapeshifter needs to wait to Shapeshift

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“DUCK!”
Yea great way to start a story, I know
I was sitting in a pub when suddenly
“FLYING CHAIR”
Yea.. Exactly that
I was hit in the head by a flying chair.. Great
I’m used to all this at this point but why should I be? I did nothing wrong except become the first Impostor and change all of amongus history Duh
But what if.. I could make a portable shell? Or More likely an Egg!
Hmm!!
And so I did.. After years of Manufacturing I finally created my master piece a portable egg which could form around me when I pressed a button but wait!
What if… I could wear a uniform to look alike some other bean.. Like disguising.. Or..
Shapeshifting…
Yea Awesome! So I did.. Finally something to go back to killing for and Kill I did..!
And after a few kills.. Yea Time to go spectate being Game Master again This is boring but some other can take my button
And become the.. Shapeshifter!
Yea I know Cool right!
The end in any case!
> Submitted by: champofchamps78
</details>
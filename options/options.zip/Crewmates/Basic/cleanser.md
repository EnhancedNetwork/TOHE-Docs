---
lang: en-US
title: Cleanser
prev: Celebrity
next: Doctor
---

# <font color="#98ff98">🧹 <b>Cleanser</b></font> <Badge text="Basic" type="tip" vertical="middle"/>
---

Cleanser can vote for any target at the meeting to erase the target's Add-ons. The erasure will take effect after the meeting ends. Depending on the settings, cleansed players may not receive add ons after being cleansed.
* Max
  * Set the Maximum amount of Cleansers that can be in a match
* Max cleanses
  * Set the Maximum amount of cleanses a Cleanser can do
* Cleansed player can get Add-on
  * <font color=green>ON</font>: the Cleansed player can get add ons when cleansed
  * <font color=red>OFF</font>: the Cleansed player cannot get add ons when cleansed
* Hide Cleanser's vote
  * <font color=green>ON</font>: the Cleansed players vote will be hidden
  * <font color=red>OFF</font>: the Cleansed players vote will not be hidden

> Idea: [Raven](#) & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Bard
prev: Arrogance
next: Arrogance
---

# <font color=red>🎻 <b>Bard</b></font> <Badge text="Hidden" type="tip" vertical="middle"/>
---

When the Bard is alive, the ejection confirmation will display a sentence composed by the bard<br>
Whenever the Bard completes a creation, the Bard’s kill cooldown is permanently cut in half
* You must have “Disable Hidden Roles” toggled <font color=red>OFF</font> for this to have a chance to appear

> From: Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>


Here’s a refined version of your story that adheres to guidelines and enhances clarity:

A New Assignment

One day, after losing a bet to the Ludopath, The Arrogance and The Bomber found themselves assigned to clean the lab for a week. “And of course, the evil cloning machine is in there,” Arro grumbled.

“Honestly, this is your fault!” The Arrogance shot back.

“How was I supposed to know someone could eat that many pizzas in one bite?” The Bomber retorted, feigning innocence. “Well, excuse me for trying to get out of chores!”

Arro paused. “Isn’t that the evil cloning machine they were using?”

“Oh yeah! I was in that once,” The Bomber recalled, grinning. “It tasted funny. You should give it a try; it’ll be fun!”

“Hmmm… they do say curiosity killed the cat,” Arro mused. With a mix of excitement and hesitation, he stepped inside the machine.

A Surprising Outcome

Moments later, he emerged from the other side, transformed.

“Whoa! It’s literally you, but… more nerdy!” The Bomber exclaimed, barely containing his laughter.

“Let’s show it to the boss,” Arro suggested, intrigued by the potential.

An Unexpected Mission

The Mind, curious about this new development, decided to send The Arrogance and the newly acquired Bard on a mission. It started smoothly until a meeting was called, and an innocent bean was ejected. Instead of the usual role reveal, musical notes appeared on the screen: “♪ ♪ ♪”

The Arrogance observed this bizarre occurrence, realizing it kept happening.

“Hmm, interesting,” he thought.

Experiment No. 2

It became clear that the Bard could kill like any impostor, but something unique occurred when a player was ejected while the Bard was still alive: random musical notes would display instead of revealing roles. Moreover, after each ejection, the Bard’s cooldown was halved.

“This is definitely something special,” The Arrogance concluded. Thus, he became known as The Bard—a unique force within the game.
> Submitted by: burgerman7286
</details>
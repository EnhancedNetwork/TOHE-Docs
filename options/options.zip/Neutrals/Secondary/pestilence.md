---
lang: en-US
title: Pestilence
prev: Plaguebearer
next: Plaguebearer
---

# <font color=#343136>🧫 <b>Pestilence</b></font> <Badge text="Secondary" type="tip" vertical="middle"/>
---

As Pestilence, you're an unstoppable machine. Any attack towards you will be reflected towards them.<br>
Indirect kills don't even kill you.<br><br>
Only way to kill Pestilence is by vote, or by it misguessing.<br>
Your presence is announced to everyone at the meeting after you transform.

> From: ToUR & Coding: [ryuk](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Pestilence - Die.
"AAAAH" (This is repetitive I know)
The Plague bearer took the anti dote and... Ahh Finally I can be healthy.. As he took the antidote he was cured of the plague he transferred to others and the people that interacted with the infected people..
 
The Pestilence had weakened the crew who could only kill other weakened crewmates
The Pestilence was invulnerable to every threat from the beans except being ejected... And then the war of 1889 started and..
The pestilence started slashing and killing and Stabbing every crewmate in sight... And the sheriff tried to kill him but he put too much power to overpower the Pestilence and stumbled over and died
 
Win for the pestilence...
[ A curious Person who Had a plague and transferred it then killed it In a nutshell ]
 
The end... of the group of four that conquered amongus
 
They brought an Apocolypse.. And killed everyone
 
The horsemen of the Apocolypse

> Submitted by: champofchamps78
</details>
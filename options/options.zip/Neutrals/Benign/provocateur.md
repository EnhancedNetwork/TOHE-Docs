---
lang: en-US
title: Provocateur
prev: Pixie
next: Pursuer
---

# <font color=#74ba43>😏 <b>Provocateur</b></font> <Badge text="Benign" type="tip" vertical="middle"/>

The Provocateur can kill any target with the kill button. If the target loses at the end of the game, the Provocateur wins with the winning team.
* Max
  * Set the Maximum amount of Provocateur that can be in a match

> From: [法师](https://space.bilibili.com/511107305) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Lose for me
Provocateur was Always provocating people Always calling them names saying they're going to lose but because he was a crewmate no one could do anything the provocateur loved Just being annoying for everyone his main target was Luffy Always making fun of him but Luffy was the judge He called a meeting and they all decided it's time to do Something about provocateur but no one knew what Luffy couldnt do anything either because he will die If he tries to judge but the blackmailer Said "I might know someone who can Help...but we cant be sure If he will Help or do the opposite" everyone quickly agreed and the Meeting was ended
After the Meeting ended the blackmailer went to some Underground base...there was a Teleportation machine he teleported to a weird Office it had Pictures of bodies but also Pictures of Heroes who saved the Crew and villains who destroyed it there was a Chair at the end of the room and on the Chair was...none other then a big human eating a sloth he was known as Innersloth and also the one who decides the roles of every player 

The blackmailer asked for help with the provocateur he needs a purpose He's annoying everyone including me Sloth Said "I can give him a role but in Exchange i want you to Entertain me and kill everyone" Blackmailer agreed the sloth Said he should have gotten His role any moment 

Provocateur felt a Change inside him he felt that If someone loses He will win he also knew he will die...but whoever dies will be annoyed this is great the provocateur immediately looked for Luffy as He was still mad about that Meeting Luffy saw him and His good mood just hit Rock bottom in a Instant He asked "Why are you Here" the provocateur replied "Because you need to lose for me" he hit the kill button they both dropped dead they still argued as ghosts the provocateur laughed and was Just watching hoping the Crew would lose only three remain blackmailer nice Mini and super Star they knew the blackmailer was impostor and voted him... but wait that's Not the end blackmailer had stealer and ejected the super sta- wait that's the nice Mini the blackmailer Misclicked and everyone lost but the mini and provocateur won

> Submitted by: Kira (Vampire)
</details>
---
lang: en-US
title: Morphling
prev: Kamikaze
next: Nemesis
---

# <font color="red">👤 <b>Morphling</b></font> <Badge text="Support" type="tip" vertical="middle"/>
---

As the Morphling, you are a Shapeshifter but cannot kill while not shapeshift.
* Max
  * Set the Maximum amount of Morphlings that can be in a match
* Kill Cooldown
  * Set the Morphling’s Kill Cooldown
* Shapeshift Cooldown
  * Set how long the Morphling needs to wait to Shapeshift
* Shapeshift Duration
  * Set how long the Morphling will stay in their Shapeshift form until they unshift

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue Going around Hogwarts Mira HQ The little bean always was what do we say... Scared of his surroundings Very Shy and introverted he rarely interacted with people but he was sort of... Good? At killing If we can say that Chapter 1 Lights, Camera, RUN The Morphling was chosen as the lead actor in a school play but well... He just couldnt perform Infront of so many people, Rehearsals were Fine but when he saw the audience... He ran Chapter 2 Well.. Now Mr. Sloth is Known to be kind of.. Lurking and when he saw this he knew what he had to do he went on and gave the Little bean a chance to Be an impostor which would remove all his fear And this... Failed! Chapter 3 Help Wizard The Wizard was a good friend of the Bean and when he saw the little bean in distress he went on and knew He had to help so he devised a plan... The Morphling couldnt kill anyone in his normal form but what if he shape shifted... Chapter 4 This strategy Failed... Obviously In the long run only killing while being shapeshifted could NOT last so... The little bean was eventually caught in a bad situation and... Ejected as the wizard looked... The little bean had a quite good run considering he couldnt even kill Sad Honestly not his fault The End

> Submitted by: champofchamps78
</details>
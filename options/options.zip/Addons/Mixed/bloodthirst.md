---
lang: en-US
title: Bloodthirst
prev: Aware
next: Diseased
---

# <font color=#691a2e>🩸 <b>Bloodthirst</b></font> <Badge text="Mixed" type="tip" vertical="middle"/>
---

As the Bloodthirst, doing tasks allows you to kill.<br>
When you complete a task, the next player you come in contact with dies.<br><br>
Your Bloodthirst remains after a meeting.<br>
Upon making a kill, your Bloodthirst clears till the next task you complete.<br>
Bloodthirsts do not stack.<br><br>
Only assigned to crewmates with tasks.
* Max
  * Set the Maximum amount of Bloodthirst that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Bloodthirst

> From: Project Lotus

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Escapist
prev: Abyssbringer
next: Lightning
---

# <font color="red">🏃 <b>Escapist</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

Escapist can mark a location by shapeshifting, and then they can Unshift. When they Shapeshift again, they will return to their Original Shapeshift location.
* Max
  * Set the Maximum amount of Escapists that can be in a match
* Shapeshift Duration
  * Set the amount of time an Escapist can Shapeshift for
* Shapeshift Cooldown
  * Set the amount of time an Escapist has to wait before they can Shapeshift again

> From: TOU & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Escapist was once a regular Impostor, but he was cornered by a Sheriff, a Knight, and a Reviver. There was no way he could escape when his partners came from behind and brutally killed them. The Escapist was so scared that he couldn’t bring himself to kill for a long time.

At long last, he made his way to MiraHQ and met with Dr. Imp, who suggested he use a teleport gun to mark a position for easy escapes. Since then, the Escapist has not been caught once, and the crew has no idea.
> Submitted by: champofchamps78
</details>
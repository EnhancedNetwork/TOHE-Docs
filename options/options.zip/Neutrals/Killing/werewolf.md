---
lang: en-US
title: Werewolf
prev: Virus
next: Wraith
---

# <font color="#191970">🐺 <b>Werewolf</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Werewolf, you can kill much like any killer.<br>
However, when you kill, any nearby players also die.<br>
Any player who dies to this will have their death reason as Mauled.<br><br>
To balance this, you have a higher kill cooldown than anyone else.
* Kill Cooldown
  * Set the Werewolf’s kill cooldown
* Maul Radius
  * Set the Werewolf’s maul radius
* Can Vent
  * <font color=green>ON</font>: the Werewolf can vent
  * <font color=red>OFF</font>: the Werewolf cannot vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Werewolf has Impostor vision
  * <font color=red>OFF</font>: the Werewolf does not have Impostor vision

> From: ToUR

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
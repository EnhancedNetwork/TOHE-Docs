---
lang: en-US
title: Statue
prev: Sloth
next: Tired
---

# <font color=#7e9c8a>🗽 <b>Statue</b></font> <Badge text="Harmful" type="tip" vertical="middle"/>
---

Whenever many people are near Statue, the Statue is completely frozen or slowed down dependand on settings.
* Max
  * Set the Maximum amount of Statue that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Statue
* Statue Slowness
  * Set the percentage the Statue will slow down by
* People needed to Slow
  * Set the amount players of players to be around Statue for it to slow down
* <font color=red>Impostors</font> can become Statue
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=#8cffff>Crewmates</font> can become Statue
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* <font color=#7f8c8d>Neutrals</font> can become Statue
  * <font color=green>ON</font>: <font color=#7f8c8d>Neutrals</font> can become this role
  * <font color=red>OFF</font>: <font color=#7f8c8d>Neutrals</font> cannot become this role
* <font color=#ac42f2>Coven</font> can become Statue
  * <font color=green>ON</font>: <font color=#ac42f2>Coven</font> can become this role
  * <font color=red>OFF</font>: <font color=#ac42f2>Coven</font> cannot become this role
  
> From: [spong](#) & Coding: [Drakos](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
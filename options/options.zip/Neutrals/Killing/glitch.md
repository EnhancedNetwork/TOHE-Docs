---
lang: en-US
title: Glitch
prev: Doppelganger
next: Huntsman
---

# <font color="#39ff14">👾 <b>Glitch</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

As the Glitch, you are a glitch in the ship with the goal of killing everyone.<br>
You can hack players, which prevents them from killing, venting and reporting dead bodies for some time.<br><br>
Single click - Hack<br>
Double click - Kill<br>
You can use the sabotage map and call a sabotage (not doors) to disguise as a random player for a limited time. (The sabotage won't actually occur. This means you cannot disguise during and after sabotages, due to technical difficulties.)<br>
You have to kill <b>everyone</b> to win.
* Kill Cooldown
  * Set how long the Glitch needs to wait to Kill
* Hack Cooldown
  * Set how long the Glitch needs to wait to Hack a player
* Hack Duration
  * Set how long the Glitch's target is Hacked for
* Mimic Cooldown
  * Set how long the Glitch needs to wait to Mimic a player
* Mimic Duration
  * Set how long the Glitch stays Mimicked for
* Can Vent
  * <font color=green>ON</font>: the Glitch can Vent
  * <font color=red>OFF</font>: the Glitch cannot Vent
* Has Impostor Vision
  * <font color=green>ON</font>: the Glitch will have the Vision of an Impostor
  * <font color=red>OFF</font>: the Glitch doesn't have the Vision of an Impostor

> Idea & Coding: [Gurge44](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
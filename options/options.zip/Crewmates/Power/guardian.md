---
lang: en-US
title: Guardian
prev: Dictator
next: Lookout
---

# <font color="#2d8855">🛡️ <b>Guardian</b></font> <Badge text="Power" type="tip" vertical="middle"/>
---

If you complete all of your Tasks, you become immortal. This includes being Killed, Guessed, Ejected, etc.
* Max
  * Set the Maximum amount of Guardians that can be in a match.
* Override Guardians’s Tasks
  * <font color=green>ON</font>: the Guardian will not have the same tasks as everyone else
    * Guardian has Common Tasks
      * <font color=green>ON</font>: the Guardian will have to do Common Tasks like everyone else
      * <font color=red>OFF</font>: the Guardian doesn’t receive Common Tasks
    * Amount of Long Tasks for Guardian
      * Set how many Long Tasks the Guardian has to do
    * Amount of Short Tasks for Guardian
      * Set how many Short Tasks the Guardian has to do
  * <font color=red>OFF</font>: the Guardian will have the same tasks as everyone else

> From: SLE & Coding: [SolarFlare](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
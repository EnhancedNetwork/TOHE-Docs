---
lang: en-US
title: Egoist
prev: /options/Settings/Addons.html
next: Lovers
---

# <font color=#5600ff>💪 <b>Egoist</b></font> <Badge text="Miscellaneous" type="tip" vertical="middle"/>
---

Madmate and <font color=#7f8c8d>Neutrals</font> won't be Egoist. If the Egoist's team wins, the Egoist wins instead of his team.
* Max
  * Set the Maximum amount of Egoists that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Egoist
* <font color=#8cffff>Crewmates</font> can become Egoist
  * <font color=green>ON</font>: <font color=#8cffff>Crewmates</font> can become this role
  * <font color=red>OFF</font>: <font color=#8cffff>Crewmates</font> cannot become this role
* An <font color=red>Impostor</font> can become Egoist
  * <font color=green>ON</font>: <font color=red>Impostors</font> can become this role
  * <font color=red>OFF</font>: <font color=red>Impostors</font> cannot become this role
* <font color=red>Impostors</font> Can See Other Egoist Impostor
  * <font color=green>ON</font>: an <font color=red>Impostor</font> can see the Egoist, and an Egoist can see the <font color=red>Impostor</font> like normal
  * <font color=red>OFF</font>: the <font color=red>Impostor</font> has no clue of his Egoist teammate

> From: [小叨院长](https://space.bilibili.com/1998829749) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
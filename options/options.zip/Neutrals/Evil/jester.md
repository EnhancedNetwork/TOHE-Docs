---
lang: en-US
title: Jester
prev: Innocent
next: PunchingBag
---

# <font color="#ec62a5">🤡 <b>Jester</b></font> <Badge text="Evil" type="tip" vertical="middle"/>
---

If the Jester get voted out, the Jester wins the game alone. If the Jester is still alive at the end of the game, the Jester loses the game. Note: Jester, Executioner, and Innocent can win together.
* Max
  * Set the Maximum amount of Jesters that can be in a match.
* Can call emergency meetings
  * <font color=green>ON</font>: this role can call a meeting like normal
  * <font color=red>OFF</font>: this role cannot call an emergency meeting
* Can Vent
  * <font color=green>ON</font>: this role gets the ability to Vent
  * <font color=red>OFF</font>: this role cannot Vent
* * Has Impostor Vision
  * <font color=green>ON</font>: the Jester has the same vision as an Impostor
  * <font color=red>OFF</font>: the Jester has default vision
* Hide Jester's Vote
  * <font color=green>ON</font>: the Jester's vote will be hidden from other players
  * <font color=red>OFF</font>: the Jester's vote will be shown to other players
* <font color=#f46f4e>(Hidden Role) Sunnyboy - Has a % chance of replacing Jester</font>

<center>

[<font color="#ff9902">Sunnyboy</font>](./Sunnyboy.html)
</center>

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

“Have you seen my girlfriend, Have you seen my girlfriend”
 
Life was pretty tough for the jester he’s parents were teachers who got caught in the ARS Incident and sadly died, so for most of his life he was an orphan but that didn’t bother him, he just kept smiling and smiling knowing it would get better, He’s a really optimistic person without a care in the world and always looking at the bright side of things.
 
He’s dream was always to be a comedian, making people happy and laugh like he is, but sometimes he just gets horrible stage fright so he didn’t did it, until he saw her “The Trickster” they talk for a while, they have the same interest and they decided to become a comedy duo and it worked they were the best comedians for a while, but it didn’t last for long
 
After sometime after a show they decided to take a walk in the park but then they were surrounded by police and sheriff car and they explained that “The Trickster” was a wanted criminal and after that they took her away, after he became sad for the first time he finally found someone he could bond with he’s not gonna lose them again, So it became he’s mission to find her, but he needs some help
 
Opportunist: Hey feeling down why not join here they could really help
Jester: huh
 
He then joined in an organization with all neutrals that was thought to be a myth and they explained that they could use someone like him, someone that just immediately leaves then goes to the next mission, if he join this he could have a chance to find the person his looking for
 
To sweeten the deal even more they said on the way out he could rather play some silly pranks on them or detonate a bomb after thrown out of course, he would also get a new suit that would survive almost any death for being voted out, after that he agreed and took the name of Jester

> Submitted by: marker_should_win_tpot
</details>
---
lang: en-US
title: Phantom
prev: Impostor
next: Shapeshifter
---

# <font color="red">👻 <b>Phantom</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Phantom, you can press your vanish button to go invisible to escape a kill. You can click your appear button if you want to become visible before the timer runs out or not.<br>
Note: You will make a smoke cloud whenever you go invisible and become visible. So make sure you are in a safe area where no one will see you.
* Max
  * Set the Maximum amount of Phantoms that can be in a match
* Invis Cooldown
  * Set long the Phantom needs to wait to turn Invisible
* Invis Duration
  * Set how long the Phantom stays Invisible for

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

First things first What the frick is Methylenedioxymethamphetamine I mean why was it even in my school's... Library? What? shouldn't it be in the Chemistry lab? That’s messed up... Anyways back to the story.. Hey you! Yelled the guard Oh shit I thought to myself... it's past curfew... Oh no oh no I need to run... Where to tho?  The library? No that's too quiet The field? No too open The Dorm? Too far The lab? Well Ig... Lets go as I ran towards the lab and hid behind a counter... Finally safe at last.. As I got up to leave I saw some vials... Oooooh Science  Anyways Lets mix some vials for fun  Since... Science is fun to me The next day.. Cough Ah what's this pain in my chest Cough Cough Cough Well cant focus on this got a test today... Cough I coughed all the way to the test room and gave the test the teacher gave me some water to drink and it felt fine... Unusually fine :9isideeye: Still I went on studying the day... 7 Years Later I went into a vent and since there was soo much C02 The chemicals reacted with CO2... What Chemicals? The one I used on the day of the night in the above text duh... Still Cough Cough Ugh anyways... Killing... I jumped out of the vent and took my knife out Screams AAH! Where's My had?! I seem to be... i seem to be- Invi-Invisible? Interesting... Indeed... But... I need to kill.. In a moment or 2 the O2 from the air rushed in and removed the reactivity of the chemicals making me visible again and able to kill... Nice way to escape Ig  And escape I did.... Yea uhh Basically... _The Abrupt End :D
> Submitted by: champofchamps78
</details>
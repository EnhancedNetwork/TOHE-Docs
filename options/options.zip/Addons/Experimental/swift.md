---
lang: en-US
title: Swift
prev: Glow
next: /options/Settings/Addons.html
---

# <font color=red>🏃 <b>Swift</b></font> <Badge text="Experimental" type="tip" vertical="middle"/>
---

As the Swift, your kills will not cause you to lunge.
* Max
  * Set the Maximum amount of Swifts that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Swift

> From: TOHEX

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
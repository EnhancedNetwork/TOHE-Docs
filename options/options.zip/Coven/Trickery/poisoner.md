---
lang: en-US
title: Poisoner
prev: Illusionist
next: /options/Settings/Coven.html
---

# <font color="#478800">🧪 <b>Poisoner</b></font> <Badge text="Trickery" type="tip" vertical="middle"/>
---

The Poisoner can use their kill button on a player to roleblock them. The next time the roleblocked player tries to use their ability, it will do nothing, and their cooldown will be reset.<br><b>With the Necronomicon, you can double-click to kill. These kills will be delayed.</b>
* Poison Cooldown
  * Set how long a Poisoner has to wait to poison a player
* Poison Kill Delay
  * Set how long it takes for the Poisoned target to die

> Originally From: Town of Us Reactivated & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)<br>
> Reworked Idea & Coding: [Marg](https://github.com/MargaretTheFool)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
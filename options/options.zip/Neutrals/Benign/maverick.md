---
lang: en-US
title: Maverick
prev: Lawyer
next: Opportunist
---

# <font color="#781717">🤠 <b>Maverick</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

You can kill like a Serial Killer, and you win with the winning team rather than alone. If you die, you lose.
* Kill Cooldown
  * Set how long a Maverick needs to wait to use their kill
* Can Vent
  * <font color=green>ON</font>: the Maverick can Vent
  * <font color=red>OFF</font>: the Maverick cannot Vent
* Has <font color=red>Impostor</font> Vision
  * <font color=green>ON</font>: the Maverick has the same vision as an Impostor
  * <font color=red>OFF</font>: the Maverick has default vision

> From: "Idea & Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

- I imagine death so much it feels more like a memory
The Maverick was never paranoid but he always knew he would die soon, He was very prideful and would never let his friends die or be injured
He loved one of his friends the most... 
We will just call him O for now..

Now The Maverick wanted to leave behind a massive legacy but... He had very little time...
When he was young he went through lots of hardships...

And it was a miracle that he was still alive..

The Maverick was very smart, Great with the gun and brave...

After achieving a lot of his goals he just wanted to live now... That would be enough

He wanted to spend his remaining life with 'O' and be happy but...

He had a competitor in politics who he had dethroned many, Many times... and at the time of these incidents duels were considered legal and sane...

The competitor challenged The Maverick to a duel...
And Because the Maverick was very prideful...
He accepted it

But... Did he want to suffer from the guilt of someone's death?
Was it something he wanted..

So when the competitor who was really bad at shooting and was just a frustrated romantic fired...

The Maverick raised his gun into the sky which was a sign of surrender...
But the bullet still hit him...

His last words were to 'O' as he confessed his love to her...

While the bullet was flying to him... He just thought to himself

I imagine death so much it feels more like a memory
Is this where it gets me, on my feet, sev'ral feet ahead of me?
I see it coming, do I run or fire my gun or let it be?
There is no beat, no melody
Opportunist, My best friend
Maybe the last face I ever see
If I throw away my shot, is this how you'll remember me?
What if this bullet is my legacy?

Legacy, what is a legacy?
It's planting seeds in a garden you never get to see?

> Submitted by: champofchamps78
</details>
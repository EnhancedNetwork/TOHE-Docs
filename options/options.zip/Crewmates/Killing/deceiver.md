---
lang: en-US
title: Deceiver
prev: Crusader
next: Jailer
---

# <font color="#be29ec">👿 <b>Deceiver</b></font> <Badge text="Killing" type="tip" vertical="middle"/>
---

The Deceiver can pass counterfeits to other players through the kill button. If a Non-Killing role receives the Counterfeit, they will Suicide after the Meeting. If a Killing role receives the counterfeit, they will suicide after attempting to kill someone.
* Max
  * Set the Maximum amount of Deceivers that can be in a match
* Ability cooldown
  * Set how long a Deceiver needs to wait to slide someone a Counterfeit
* Max number of uses
  * Set how many times a Deceiver can give people Counterfeits
* Deceiver loses ability if it deceives player without kill button
  * <font color=green>ON</font>: Deceiver will lose their ability if they deceive a player without a kill button
  * <font color=red>OFF</font>: Deceiver will not lose their ability even if they deceive a player without a kill button

> From: [罗寄](#) & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
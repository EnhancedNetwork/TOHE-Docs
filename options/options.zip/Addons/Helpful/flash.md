---
lang: en-US
title: Flash
prev: Evader
next: Lazy
---

# <font color=#fb8404>⚡ <b>Flash</b></font> <Badge text="Helpful" type="tip" vertical="middle"/>
---

The Flash's default movement speed is faster than others. (speed depends on the setting of the host)
* Max
  * Set the Maximum amount of Flashes that can be in a match
* Spawn Chance
  * Set the percentage players have of getting Flash
* Flash Speed
  * Set how fast players with Flash will become

> From: TOH:TOR & Coding: [KARPED1EM](#)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
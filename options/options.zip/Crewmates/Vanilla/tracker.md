---
lang: en-US
title: Tracker
prev: Scientist
next: /options/Settings/Crewmates.html
---

# <font color="#19a612">📡 <b>Tracker</b></font> <Badge text="Vanilla" type="tip" vertical="middle"/>
---

As the Tracker, press your tracker button on a player to track their location via the map for a limited amount of time.
* Max
  * Set the Maximum amount of Trackers that can be in a match
* Tracking Cooldown
  * Set long the Tracker needs to wait to Track a Player
* Tracking Duration
  * Set how long the Tracker can Track a Player for
* Tracking Delay
  * Set how long the Delay for Tracking is for the Tracker

> From: Innersloth

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
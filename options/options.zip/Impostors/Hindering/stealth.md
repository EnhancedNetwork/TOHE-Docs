---
lang: en-US
title: Stealth
prev: Pitfall
next: Twister
---

# <font color="red">🥷 <b>Stealth</b></font> <Badge text="Hindering" type="tip" vertical="middle"/>
---

When the Stealth kills, players in the same room are blinded for a short time.

* Ignore Impostors while Blinding
  * <font color=green>ON</font>: Other Impostors won't be blinded when you kill
  * <font color=red>OFF</font>: Other Impostors will be blinded when you kill
* Blinding Duration
  * Set how long players are blinded for

> From: TOH

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Prologue In every single story the author used to torment, Torture, Kill The superstar... But not anymore!! Chapter 1 No, Please The Superstar curse, A new form of taboo created by the citizens of Mira HQ, always they thought about how superstars would guarantee end up dead and how every time A new superstar was there a new impostor came, The hangman, Phantom, You name it and the bodyguards were helpless against the buff Impostors Chapter 2 I dont accept this The Superstar went up to Mr. sloth and presented his case and told him about the superstar curse and well Mr. Sloth agreed to promote him to Impostor Now what? Chapter 3 Wait what Wherever the Superstar went he was recognized as an Impostor because of his super bright Light he emitted from his body while walking so he had to cover up but while killing well The cover fell off Chapter 4 AAH MY EYES Now the eyes of unsuspecting nearby Crewmates when he killed started to burn vigorously, screaming with pain the whole room was dazzled but after a bit it was all fine?! New ability? Like Smoke bombs? MAYBE!! Chapter 5 Dethroning Disperser Now again the Impostor games started and disperser vs Stealth while disperser baffled stealth by teleporting him Just by killing a person nearby every Impostor was blinded and stealth swooped in and killed EVERYONE Well... A superstar the one person most tortured in my lores became the strongest Impostor Anything is possible I guess The end? Maybe.... maybe!
> Submitted by: champofchamps78
</details>
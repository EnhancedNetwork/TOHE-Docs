---
lang: en-US
title: Clumsy
prev: Circumvent
next: LastImpostor
---

# <font color="red">🤕 <b>Clumsy</b></font> <Badge text="Impostor" type="tip" vertical="middle"/>
---

As the Clumsy, you have a chance to miss your kill.<br><br>
When you miss, your cooldown is reset and the target remains untouched.<br><br>
Only assigned to killers
* Max
  * Set the Maximum amount of Clumsys that can be in a match
* Spawn Chance
  * Set the chance of a Clumsy spawning
* Chance to miss a kill
  * Set the chance of a Clumsy missing a kill

> From: [Ciredm](#) & "Coding": [TheSkullCreeper](https://github.com/Loonie-Toons)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Placeholder: This role is a ROLE OH EM GOSH
> Submitted by: Member
</details>
---
lang: en-US
title: Vector
prev: Terrorist
next: Vulture
---

# <font color=#ff6201>💨 <b>Vector</b></font> <Badge text="Chaos" type="tip" vertical="middle"/>
---

Vector will win alone by venting a certain number of times.
* Max
  * Set the Maximum amount of Vectors that can be in a match
* Number of Vents to win
  * Set the number of vents needed to win
* Vent Cooldown
  * Set how long the Vector has to wait to Vent
  
> Idea & Coding: [KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

- And the canons went BOOM!
Disclaimer : Title has been used twice..
The vector knew one thing
He knew how to jump
And Jump...
And... Jump

Well He could also eat and walk and talk
But jumping was his passion...

And he understood one thing..
It took energy so it took time for him to jump between every jump..
Now the vents made so much sound it made others go insane....

And then the engineer turned the heat up
The Scavenger became more hyper and ate 5 Beans...

Too much for everyone and when it passes a certain limit

Everyone went Insane with the sound
Clank Clank 
"Shut it man"
"Stop"
"Is he Jester?"
"Why"

And then he did it
He made everyone end themselves
And the captain crashed the ship... All because of him....

Making people mad... sounds good..
In this case was good too

The End

> Submitted by: champofchamps78
</details>
---
lang: en-US
title: Pixie
prev: Opportunist
next: Provocateur
---

# <font color="#01ff00">🧚 <b>Pixie</b></font> <Badge text="Benign" type="tip" vertical="middle"/>
---

As the Pixie, Mark up to X amount of targets each round by using kill button on them. When the meeting starts, your job is to have one of the marked targets ejected. If unsuccessful you will suicide, except if you didn't mark any targets or all the targets are dead. The selected targets resets to 0 after the meeting ends. If you succeed you will gain a point. You see all your targets in colored names.<br><br>
You win with the winning team when you have certain amounts of points set by the host.
* Max
  * Set the Maximum amount of Pixies that can be in a match 
* Number of points required to win
  * Set how many points the Pixie must collect to win
* Maximum number of targets per round
  * Set how many people the Pixie can mark per round
* Mark cooldown
  * Set how long the Pixie has to wait to mark a player
* Pixie suicides if target is not voted out
  * <font color=green>ON</font>: the Pixie will suicide if none of their targets are voted out
  * <font color=red>OFF</font>: the Pixie will not suicide even if none of their targets are voted out

> Idea: [Azanthiel] & Coding: [ryuk](https://github.com/ryuk2098)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

Description: Very Anti Social, Introverted, Seen as a Grinch by other neutrals, pretty sure going more and more insane after each day, Have little wings which she can use to hover, Would beat you up if you say she’s a fairy
 
Status: In her cell, gave her dolls so she can shut up and she seems quiet now
 
FILE THE PIXIE
 
Do you believe in magical creatures, Unicorns fairies well what about Pixies they were said to be A small, mischievous fairy-like creature from British folklore. Pixies are said to have pointed ears and hats, and are often depicted in green. They are said to enjoy leading people astray, the worst thing mentioned here is that they’re British
 
But something you may not know about them is they enjoy negative energy mostly they enjoy misfortune on others because they feast on it, that’s their energy source and when they found something that can produce this much of misfortune of course they will take advantage of it, Well this is where our protagonist came into place they travelled to distant land to find ways of this disguised as one of them
 
They interviewed a lot of people asking what would be the most misfortunate situation they could be in and 80% answered is getting voted out and executed, you see there has been an increased of impostors in some of the jobs they had have and they said that their punishments is literally the worst thing that can happen on someone
 
Now she had a sneaky little plan she applied in a job inside the Mira HQ where they said some impostors may occur in some days it’s just a boring there were still some misfortune here and there but it wasn’t really strong but when there are impostors now she formed a plan, first she would pick a target like tagging them in some sort and now when there is a meeting she has to get em out most of the times if not voted out nothing would happen to her but when the odds are not in her favor and she really need the energy if they are not voted out she’ll unfortunately die
 
But that didn’t happen to her it was a successful day and she was stuffed too bad she got arrested by the NPMD

> Submitted by: Pikmin 6(No.1TrickJestershipper)
</details>
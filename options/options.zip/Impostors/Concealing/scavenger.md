---
lang: en-US
title: Scavenger
prev: RiftMaker
next: Shapemaster
---

# <font color="red">🧺 <b>Scavenger</b></font> <Badge text="Concealing" type="tip" vertical="middle"/>
---

When a Scavenger kills, it will not leave a dead body, (Like Hangman if they are Shapeshifted). If they kill a bait, No self report will be made.
* Max
  * Set the Maximum amount of Scavengers that can be in a match
* Kill Cooldown
  * Set how long the Scavenger needs to wait to use his Ability

> From: [喜](https://space.bilibili.com/443432765) & Coding: [喜](https://space.bilibili.com/443432765)、[KARPED1EM](https://github.com/KARPED1EM)

<details>
<summary><b><font color=gray>Unofficial Lore</font></b></summary>

The Scavenger had once been a regular crew member, peacefully completing tasks when disaster struck: a critical sabotage left the crew unable to respond in time. Unfortunately, the ship crashed. Fortunately, he survived, alongside a scientist and a noisemaker. With all the Impostors gone, he noticed a knife lying in the wreckage. Seizing the opportunity, he grabbed it and hid it away.

The scientist managed to contact MiraHQ, promising that help would arrive soon, but as time dragged on, their situation grew desperate. In a moment of panic, the Scavenger made a drastic choice and eliminated the noisemaker, who let out a surprised gasp before collapsing. When the scientist arrived at the scene, he was stunned—he had never imagined a crew member could take such action.

Driven by desperation, the Scavenger felt a strange hunger take over. He realized he had crossed a line he never expected to. Checking the scientist's device, he saw that a rescue ship was finally on its way. But when the ship arrived on Polus for inspection, the Scavenger saw his chance to break free into the unknown, leaving everything behind.
> Submitted by: champofchamps78
</details>